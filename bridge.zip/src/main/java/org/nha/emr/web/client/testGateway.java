package org.nha.emr.web.client;

import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.util.UUID;

import org.nha.emr.web.client.api.GatewayApi;
import org.nha.emr.web.hip.model.AuthenticationMode;
import org.nha.emr.web.hip.model.Error;
import org.nha.emr.web.hip.model.PatientAuthInitRequest;
import org.nha.emr.web.hip.model.PatientAuthInitRequestQuery;
import org.nha.emr.web.hip.model.PatientAuthInitRequestQueryRequester;
import org.nha.emr.web.hip.model.PatientAuthModeQueryRequest;
import org.nha.emr.web.hip.model.PatientAuthModeQueryRequestQuery;
import org.nha.emr.web.hip.model.PatientAuthModeQueryRequestQueryRequester;
import org.nha.emr.web.hip.model.PatientAuthPurpose;
import org.nha.emr.web.hip.model.RequestReference;
import org.nha.emr.web.hip.model.SessionRequest;
import org.nha.emr.web.hip.model.SessionResponse;
import org.nha.emr.web.hip.model.ShareProfileAcknowledgement;
import org.nha.emr.web.hip.model.ShareProfileResult;
import org.nha.emr.web.hip.model.PatientAuthModeQueryRequestQueryRequester.TypeEnum;

public class testGateway {

	public static void main(String[] args) {
		GatewayApi gatewayApi = new  GatewayApi();
			
		// TODO Auto-generated method stub
		try {
			 SessionRequest sessReq = new SessionRequest();
	 			sessReq.clientId(AuthKeys.X_CLIENT_ID);
	         	sessReq.clientSecret(AuthKeys.AUTHORIZATION_TOKEN);
	         	SessionResponse sessResp = gatewayApi.v05SessionsPost(sessReq);
	         	String accessToken = sessResp.getAccessToken();
	         	
	         	System.out.println("Session  "+accessToken);
	         // Starting to build  on-share async call 
	            ShareProfileResult patientShareResult =  new ShareProfileResult();
	            UUID resultRequestId = UUID.randomUUID();
				patientShareResult.setRequestId(resultRequestId);
				LocalDateTime ldt = LocalDateTime.now(ZoneOffset.UTC);
				patientShareResult.setTimestamp(ldt + "");
				ShareProfileAcknowledgement acknowledgement = new ShareProfileAcknowledgement();
				acknowledgement.setStatus(ShareProfileAcknowledgement.StatusEnum.SUCCESS);
				acknowledgement.setHealthId("55-4400-0441-6378");
				patientShareResult.setAcknowledgement(acknowledgement);	
				
				Error err = new Error();
				
	        	RequestReference respRef = new RequestReference();
	      		respRef.setRequestId(UUID.fromString("f9a18a9d-522a-42be-866a-7a778e49b2b8"));
	      		patientShareResult.setResp(respRef);
	      		
				 gatewayApi.v05PatientsProfileOnSharePost(patientShareResult, "bearer "+accessToken, AuthKeys.X_CM_ID);
				 
				 
	        }catch(Exception e){
	        	e.printStackTrace();
	        }
	}

}
