package org.nha.emr.web.hip.model;

import java.util.Objects;

import org.springframework.validation.annotation.Validated;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonValue;

import io.swagger.annotations.ApiModelProperty;

/**
 * PermissionFrequency
 */
@Validated



public class PermissionFrequency   {
  /**
   * Gets or Sets unit
   */
  public enum UnitEnum {
    HOUR("HOUR"),
    
    WEEK("WEEK"),
    
    DAY("DAY"),
    
    MONTH("MONTH"),
    
    YEAR("YEAR");

    private String value;

    UnitEnum(String value) {
      this.value = value;
    }

    @Override
    @JsonValue
    public String toString() {
      return String.valueOf(value);
    }

    @JsonCreator
    public static UnitEnum fromValue(String text) {
      for (UnitEnum b : UnitEnum.values()) {
        if (String.valueOf(b.value).equals(text)) {
          return b;
        }
      }
      return null;
    }
  }
  @JsonProperty("unit")
  private UnitEnum unit = null;

  @JsonProperty("value")
  private Integer value = null;

  @JsonProperty("repeats")
  private Integer repeats = null;

  public PermissionFrequency unit(UnitEnum unit) {
    this.unit = unit;
    return this;
  }

  /**
   * Get unit
   * @return unit
  **/
  @ApiModelProperty(value = "")
  
    public UnitEnum getUnit() {
    return unit;
  }

  public void setUnit(UnitEnum unit) {
    this.unit = unit;
  }

  public PermissionFrequency value(Integer value) {
    this.value = value;
    return this;
  }

  /**
   * Get value
   * @return value
  **/
  @ApiModelProperty(value = "")
  
    public Integer getValue() {
    return value;
  }

  public void setValue(Integer value) {
    this.value = value;
  }

  public PermissionFrequency repeats(Integer repeats) {
    this.repeats = repeats;
    return this;
  }

  /**
   * Get repeats
   * @return repeats
  **/
  @ApiModelProperty(value = "")
  
    public Integer getRepeats() {
    return repeats;
  }

  public void setRepeats(Integer repeats) {
    this.repeats = repeats;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    PermissionFrequency permissionFrequency = (PermissionFrequency) o;
    return Objects.equals(this.unit, permissionFrequency.unit) &&
        Objects.equals(this.value, permissionFrequency.value) &&
        Objects.equals(this.repeats, permissionFrequency.repeats);
  }

  @Override
  public int hashCode() {
    return Objects.hash(unit, value, repeats);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class PermissionFrequency {\n");
    
    sb.append("    unit: ").append(toIndentedString(unit)).append("\n");
    sb.append("    value: ").append(toIndentedString(value)).append("\n");
    sb.append("    repeats: ").append(toIndentedString(repeats)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
