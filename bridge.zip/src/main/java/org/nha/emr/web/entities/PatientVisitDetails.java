package org.nha.emr.web.entities;

import java.util.Date;
import java.util.List;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;

import org.hibernate.annotations.OnDelete;
import org.hibernate.annotations.OnDeleteAction;

import com.fasterxml.jackson.annotation.JsonIgnore;


	@Entity
	@Table(name = "patient_visit_dtls")
	public class PatientVisitDetails extends AuditModel {
	    
		private static final long serialVersionUID = 1L;

		@Id
	    @GeneratedValue(generator = "visit_id_generator")
	    @SequenceGenerator(
	            name = "visit_id_generator",
	            sequenceName = "visit_id_sequence",
	            initialValue = 1
	    )
	    private Long visitId;
		
		@NotBlank
	    @Size(min = 1, max = 10)
	    @Column(name = "visit_type")
	    private String visitType;
	    
	    
	    @Temporal(TemporalType.TIMESTAMP)
	    @Column(name = "visit_dt", nullable = false)
	    private Date visitDt;

	    @Size(min = 0, max = 100)
	    @Column(name = "facility_cd")
	    private String facilityCd;
	    
	    @Size(min = 0, max = 100)
	    @Column(name = "facility_name")
	    private String facilityName;
	    
	    
	    @Size(min = 0, max = 100)
	    @Column(name = "practitioner_cd")
	    private String practitionerCd;
	    
	    @Size(min = 0, max = 100)
	    @Column(name = "practitioner_name")
	    private String practitionerName;
	    
	    @Size(min = 0, max = 1)
	    @Column(name = "prescription_yn")
	    private String prescriptionYn;

	    @Size(min = 0, max = 1)
	    @Column(name = "clinical_notes_yn")
	    private String clinicalNotesYn;
	    
	    @Size(min = 0, max = 1)
	    @Column(name = "diagnostic_report_yn")
	    private String diagnosticReportYn;
	    
	    @Size(min = 0, max = 1)
	    @Column(name = "discharge_summary_yn")
	    private String dischargeSummaryYn;
	    
	    @Column(name = "fhirObject",columnDefinition = "TEXT",nullable = true)
	    private String fhirObject;
	    
	    @Column(name = "fhirPractitionerObject",columnDefinition = "TEXT",nullable = true)
	    private String fhirPractitionerObject;
	    
	    
	    @ManyToOne(fetch = FetchType.LAZY, optional = false)
	    @JoinColumn(name = "patient_id", nullable = false)
	    @OnDelete(action = OnDeleteAction.CASCADE)
	    @JsonIgnore
	    private Patient patient;
		
		@OneToMany(mappedBy="patientVisitDetails")
	    private List<PatientPrescriptionDetails>  patientPrescriptionDetails;
		
		@OneToMany(mappedBy="patientVisitDetails")
	    private List<PatientClinicalNotesDetails> patientClinicalNotesDetails;
		
		@OneToMany(mappedBy="patientVisitDetails")
	    private List<PatientDiagnosticReportDetails> patientDiagnosticReportDetails;
		
		@OneToMany(mappedBy="patientVisitDetails")
	    private List<PatientDischargeDetails> patientDischargeDetails;
		
			    
		public PatientVisitDetails() {
			
		}


		public Long getVisitId() {
			return visitId;
		}


		public void setVisit_id(Long visitId) {
			this.visitId = visitId;
		}


		public String getVisitType() {
			return visitType;
		}


		public void setVisitType(String visitType) {
			this.visitType = visitType;
		}


		
		public Date getVisitDt() {
			return visitDt;
		}


		public void setVisitDt(Date visitDt) {
			this.visitDt = visitDt;
		}


		public String getFacilityCd() {
			return facilityCd;
		}


		public void setFacilityCd(String facilityCd) {
			this.facilityCd = facilityCd;
		}


		public String getFacilityName() {
			return facilityName;
		}


		public void setFacilityName(String facilityName) {
			this.facilityName = facilityName;
		}


		public String getPractitionerCd() {
			return practitionerCd;
		}


		public void setPractitionerCd(String practitionerCd) {
			this.practitionerCd = practitionerCd;
		}


		public String getPractitionerName() {
			return practitionerName;
		}


		public void setPractitionerName(String practitionerName) {
			this.practitionerName = practitionerName;
		}


		public String getPrescriptionYn() {
			return prescriptionYn;
		}


		public void setPrescriptionYn(String prescriptionYn) {
			this.prescriptionYn = prescriptionYn;
		}


		public String getClinicalNotesYn() {
			return clinicalNotesYn;
		}


		public void setClinicalNotesYn(String clinicalNotesYn) {
			this.clinicalNotesYn = clinicalNotesYn;
		}


		public String getDiagnosticReportYn() {
			return diagnosticReportYn;
		}


		public void setDiagnosticReportYn(String diagnosticReportYn) {
			this.diagnosticReportYn = diagnosticReportYn;
		}


		public String getDischargeSummaryYn() {
			return dischargeSummaryYn;
		}


		public void setDischargeSummaryYn(String dischargeSummaryYn) {
			this.dischargeSummaryYn = dischargeSummaryYn;
		}


		
		public String getFhirObject() {
			return fhirObject;
		}


		public void setFhirObject(String fhirObject) {
			this.fhirObject = fhirObject;
		}


		public String getFhirPractitionerObject() {
			return fhirPractitionerObject;
		}


		public void setFhirPractitionerObject(String fhirPractitionerObject) {
			this.fhirPractitionerObject = fhirPractitionerObject;
		}


		public void setVisitId(Long visitId) {
			this.visitId = visitId;
		}


		public Patient getPatient() {
			return patient;
		}


		public void setPatient(Patient patient) {
			this.patient = patient;
		}


		public List<PatientPrescriptionDetails> getPatientPrescriptionDetails() {
			return patientPrescriptionDetails;
		}


		public void setPatientPrescriptionDetails(List<PatientPrescriptionDetails> patientPrescriptionDetails) {
			this.patientPrescriptionDetails = patientPrescriptionDetails;
		}


		public List<PatientClinicalNotesDetails> getPatientClinicalNotesDetails() {
			return patientClinicalNotesDetails;
		}


		public void setPatientClinicalNotesDetails(List<PatientClinicalNotesDetails> patientClinicalNotesDetails) {
			this.patientClinicalNotesDetails = patientClinicalNotesDetails;
		}


		public List<PatientDiagnosticReportDetails> getPatientDiagnosticReportDetails() {
			return patientDiagnosticReportDetails;
		}


		public void setPatientDiagnosticReportDetails(List<PatientDiagnosticReportDetails> patientDiagnosticReportDetails) {
			this.patientDiagnosticReportDetails = patientDiagnosticReportDetails;
		}


		public List<PatientDischargeDetails> getPatientDischargeDetails() {
			return patientDischargeDetails;
		}


		public void setPatientDischargeDetails(List<PatientDischargeDetails> patientDischargeDetails) {
			this.patientDischargeDetails = patientDischargeDetails;
		}

				
	}
