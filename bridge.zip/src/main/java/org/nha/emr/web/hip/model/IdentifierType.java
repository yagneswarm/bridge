package org.nha.emr.web.hip.model;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;

/**
 * Gets or Sets IdentifierType
 */
public enum IdentifierType {
  MOBILE("MOBILE"),
    MR("MR"),
    NDHM_HEALTH_NUMBER("NDHM_HEALTH_NUMBER"),
    HEALTH_ID("HEALTH_ID");

  private String value;

  IdentifierType(String value) {
    this.value = value;
  }

  @Override
  @JsonValue
  public String toString() {
    return String.valueOf(value);
  }

  @JsonCreator
  public static IdentifierType fromValue(String text) {
    for (IdentifierType b : IdentifierType.values()) {
      if (String.valueOf(b.value).equals(text)) {
        return b;
      }
    }
    return null;
  }
}
