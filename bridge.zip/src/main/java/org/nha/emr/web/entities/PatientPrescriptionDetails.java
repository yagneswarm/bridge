package org.nha.emr.web.entities;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.Size;

import org.hibernate.annotations.OnDelete;
import org.hibernate.annotations.OnDeleteAction;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name = "patient_prescription_dtls")
public class PatientPrescriptionDetails extends AuditModel {
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
    @GeneratedValue(generator = "prescription_generator")
    @SequenceGenerator(
            name = "prescription_generator",
            sequenceName = "prescription_sequence",
            initialValue = 1
    )
    private Long id;
   
    @Size(min = 0, max = 100)
    @Column(name = "prescribed_by")
    private String prescribedBy;
    
    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "presciption_dt", nullable = false)
    private Date prescriptionDt;
    
    @Size(min = 0, max = 100000	)
    @Column(name = "presciption_notes", nullable = false)
    private String prescriptionNotes;
    
    @Size(min = 0, max = 100000	)
    @Column(name = "instruction", nullable = true)
    private String instruction;
    
    @Size(min = 0, max = 10	)
    @Column(name = "quantity", nullable = true)
    private String quantity;
    
    @Size(min = 0, max = 100	)
    @Column(name = "duration", nullable = true)
    private String duration;
    
    @Size(min = 0, max = 100	)
    @Column(name = "drug_name", nullable = true)
    private String drugName;
    
    
    @Size(min = 0, max = 200	)
    @Column(name = "condition", nullable = true)
    private String condition;
    
    @Size(min = 0, max = 1	)
    @Column(name = "repeats_allowed_yn", nullable = true)
    private String repeatsAllowedYn;
    
    @Size(min = 0, max = 50	)
    @Column(name = "duration_unit", nullable = true)
    private String durationUnit;
    
    @Column(name = "attach_path")
	private String attachPath;
	
	@Column(name = "notes")
	private String notes;
	
	@Column(name="report_type")
	private String reportType;
	
	@Column(name="drug_id")
	private String drugId;
	
	@Column(name="drug_instruction_id")
	private Long drugInstructionId;
    
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "visit_id", nullable = false)
    @OnDelete(action = OnDeleteAction.CASCADE)
    @JsonIgnore
    private PatientVisitDetails patientVisitDetails;

    
    
	public PatientPrescriptionDetails() {
		// TODO Auto-generated constructor stub
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	
	public String getPrescribedBy() {
		return prescribedBy;
	}

	public void setPrescribedBy(String prescribedBy) {
		this.prescribedBy = prescribedBy;
	}

	public Date getPrescriptionDt() {
		return prescriptionDt;
	}

	public void setPrescriptionDt(Date prescriptionDt) {
		this.prescriptionDt = prescriptionDt;
	}

	public String getPrescriptionNotes() {
		return prescriptionNotes;
	}

	public void setPrescriptionNotes(String prescriptionNotes) {
		this.prescriptionNotes = prescriptionNotes;
	}

	public PatientVisitDetails getPatientVisitDetails() {
		return patientVisitDetails;
	}

	public void setPatientVisitDetails(PatientVisitDetails patientVisitDetails) {
		this.patientVisitDetails = patientVisitDetails;
	}

	public String getInstruction() {
		return instruction;
	}

	public void setInstruction(String instruction) {
		this.instruction = instruction;
	}

	public String getQuantity() {
		return quantity;
	}

	public void setQuantity(String quantity) {
		this.quantity = quantity;
	}

	public String getDuration() {
		return duration;
	}

	public void setDuration(String duration) {
		this.duration = duration;
	}

	public String getRepeatsAllowedYn() {
		return repeatsAllowedYn;
	}

	public void setRepeatsAllowedYn(String repeatsAllowedYn) {
		this.repeatsAllowedYn = repeatsAllowedYn;
	}

	public String getDrugName() {
		return drugName;
	}

	public void setDrugName(String drugName) {
		this.drugName = drugName;
	}

	public String getDurationUnit() {
		return durationUnit;
	}

	public void setDurationUnit(String durationUnit) {
		this.durationUnit = durationUnit;
	}

	public String getCondition() {
		return condition;
	}

	public void setCondition(String condition) {
		this.condition = condition;
	}

	public String getAttachPath() {
		return attachPath;
	}

	public void setAttachPath(String attachPath) {
		this.attachPath = attachPath;
	}

	public String getNotes() {
		return notes;
	}

	public void setNotes(String notes) {
		this.notes = notes;
	}

	public String getReportType() {
		return reportType;
	}

	public void setReportType(String reportType) {
		this.reportType = reportType;
	}

	public String getDrugId() {
		return drugId;
	}

	public void setDrugId(String drugId) {
		this.drugId = drugId;
	}

	public Long getDrugInstructionId() {
		return drugInstructionId;
	}

	public void setDrugInstructionId(Long drugInstructionId) {
		this.drugInstructionId = drugInstructionId;
	}


    
	
        
    }
