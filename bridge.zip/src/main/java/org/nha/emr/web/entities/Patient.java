package org.nha.emr.web.entities;

import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;


	@Entity
	@Table(name = "patient")
	public class Patient extends AuditModel {
	    /**
		 * 
		 */
		private static final long serialVersionUID = 1L;

		@Id
	    @GeneratedValue(generator = "patient_generator")
	    @SequenceGenerator(
	            name = "patient_generator",
	            sequenceName = "patient_sequence",
	            initialValue = 1000
	    )
	    private Long patientId;

	    @NotBlank
	    @Size(min = 3, max = 100)
	    @Column(name = "first_name")
	    private String firstName;
	    
	    
	    @Size(min = 0, max = 100)
	    @Column(name = "middle_name")
	    private String middleName;

	    @Size(min = 0, max = 100)
	    @Column(name = "last_name")
	    private String lastName;

	    @Temporal(TemporalType.TIMESTAMP)
	    @Column(name = "birth_dt", nullable = false)
	    private Date birthDt;
	    
	    @Size(min = 1, max = 10)
	    @Column(name = "gender")
	    private String gender;

	    @Size(min = 1, max = 2)
	    @Column(name = "age")
	    private String age;

	    

	    @Size(min = 1, max = 10)
	    @Column(name = "state_lgd_cd")
	    private String stateLgdCd;
	    
	    @Size(min = 1, max = 10)
	    @Column(name = "dist_lgd_cd")
	    private String distLgdCd;
	    
	    @Size(min = 0, max = 100)
	    @Column(name = "village_lgd_cd")
	    private String villageLgdCd;
	    
	    @Size(min = 0, max = 100)
	    @Column(name = "town_lgd_cd")
	    private String towngdCd;
	    
	    @Size(min = 0, max = 10)
	    @Column(name = "pincode")
	    private String pincode;
	    
	    @Size(min = 0, max = 100)
	    @Column(name = "swasthya_id")
	    private String swasthyaId;
	    
	    @Size(min = 0, max = 12)
	    @Column(name = "contact_number")
	    private String contactNumber;
	    
	    
	    @Size(min = 1, max = 10)
	    @Column(name = "last_visit_type")
	    private String lastVisitType;
	    
	    @Temporal(TemporalType.TIMESTAMP)
	    @Column(name = "last_visit_dt", nullable = false)
	    private Date lastVisitDt;
	    
	    @Column(name = "fhirObject",columnDefinition = "TEXT",nullable = true)
	    private String fhirObject;
	    	    
	    
	    @OneToMany(mappedBy="patient",cascade = CascadeType.PERSIST)
	    private List<PatientVisitDetails> patientVisitDetails;
	    
	    	        
		public Patient() {
			// TODO Auto-generated constructor stub
		}

		
		public Long getPatientId() {
			return patientId;
		}

		public void setPatientId(Long patientId) {
			this.patientId = patientId;
		}

		public String getFirstName() {
			return firstName;
		}

		public void setFirstName(String firstName) {
			this.firstName = firstName;
		}

		public String getMiddleName() {
			return middleName;
		}

		public void setMiddleName(String middleName) {
			this.middleName = middleName;
		}

		public String getLastName() {
			return lastName;
		}

		public void setLastName(String lastName) {
			this.lastName = lastName;
		}

		public Date getBirthDt() {
			return birthDt;
		}

		public void setBirthDt(Date birthDt) {
			this.birthDt = birthDt;
		}

		public String getStateLgdCd() {
			return stateLgdCd;
		}

		public void setStateLgdCd(String stateLgdCd) {
			this.stateLgdCd = stateLgdCd;
		}

		public String getDistLgdCd() {
			return distLgdCd;
		}

		public void setDistLgdCd(String distLgdCd) {
			this.distLgdCd = distLgdCd;
		}

		public String getVillageLgdCd() {
			return villageLgdCd;
		}

		public void setVillageLgdCd(String villageLgdCd) {
			this.villageLgdCd = villageLgdCd;
		}

		public String getTowngdCd() {
			return towngdCd;
		}

		public void setTowngdCd(String towngdCd) {
			this.towngdCd = towngdCd;
		}

		public String getPincode() {
			return pincode;
		}

		public void setPincode(String pincode) {
			this.pincode = pincode;
		}

		public String getSwasthyaId() {
			return swasthyaId;
		}

		public void setSwasthyaId(String swasthyaId) {
			this.swasthyaId = swasthyaId;
		}

		public String getLastVisitType() {
			return lastVisitType;
		}

		public void setLastVisitType(String lastVisitType) {
			this.lastVisitType = lastVisitType;
		}

		public Date getLastVisitDt() {
			return lastVisitDt;
		}

		public void setLastVisitDt(Date lastVisitDt) {
			this.lastVisitDt = lastVisitDt;
		}
	    
	
		public String getContactNumber() {
			return contactNumber;
		}

		public void setContactNumber(String contactNumber) {
			this.contactNumber = contactNumber;
		}


		public List<PatientVisitDetails> getPatientVisitDetails() {
			return patientVisitDetails;
		}

		public void setPatientVisitDetails(List<PatientVisitDetails> patientVisitDetails) {
			this.patientVisitDetails = patientVisitDetails;
		}


		public String getGender() {
			return gender;
		}


		public void setGender(String gender) {
			this.gender = gender;
		}


		public String getAge() {
			return age;
		}


		public void setAge(String age) {
			this.age = age;
		}


		public String getFhirObject() {
			return fhirObject;
		}


		public void setFhirObject(String fhirObject) {
			this.fhirObject = fhirObject;
		}
       
	    
	}
