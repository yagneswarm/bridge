package org.nha.emr.web.vo;

public class ConsentVO {

	private String name;
	private String healthId;
	private String reqDate;
	private String docType;
	private String infoFrmDt;
	private String infoToDt;
	private String expiryFrmDt;
	private String expiryToDt;
	private String reqStatus;
	private String consentGrant;
	private String consentExpiry;
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getHealthId() {
		return healthId;
	}
	public void setHealthId(String healthId) {
		this.healthId = healthId;
	}
	public String getReqDate() {
		return reqDate;
	}
	public void setReqDate(String reqDate) {
		this.reqDate = reqDate;
	}
	public String getDocType() {
		return docType;
	}
	public void setDocType(String docType) {
		this.docType = docType;
	}
	public String getInfoFrmDt() {
		return infoFrmDt;
	}
	public void setInfoFrmDt(String infoFrmDt) {
		this.infoFrmDt = infoFrmDt;
	}
	public String getInfoToDt() {
		return infoToDt;
	}
	public void setInfoToDt(String infoToDt) {
		this.infoToDt = infoToDt;
	}
	public String getExpiryFrmDt() {
		return expiryFrmDt;
	}
	public void setExpiryFrmDt(String expiryFrmDt) {
		this.expiryFrmDt = expiryFrmDt;
	}
	public String getExpiryToDt() {
		return expiryToDt;
	}
	public void setExpiryToDt(String expiryToDt) {
		this.expiryToDt = expiryToDt;
	}
	public String getReqStatus() {
		return reqStatus;
	}
	public void setReqStatus(String reqStatus) {
		this.reqStatus = reqStatus;
	}
	public String getConsentGrant() {
		return consentGrant;
	}
	public void setConsentGrant(String consentGrant) {
		this.consentGrant = consentGrant;
	}
	public String getConsentExpiry() {
		return consentExpiry;
	}
	public void setConsentExpiry(String consentExpiry) {
		this.consentExpiry = consentExpiry;
	}
	
	
	
	
}
