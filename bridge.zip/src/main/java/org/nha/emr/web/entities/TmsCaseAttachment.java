package org.nha.emr.web.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.sql.Timestamp;


/**
 * The persistent class for the tms_case_attachments database table.
 * 
 */
@Entity
@Table(name="tms_case_attachments")
@NamedQuery(name="TmsCaseAttachment.findAll", query="SELECT t FROM TmsCaseAttachment t")
public class TmsCaseAttachment implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	private Long sno;

	@Column(name="attach_total_path")
	private String attachTotalPath;

	@Column(name="attachment_name")
	private String attachmentName;

	@Column(name="case_id")
	private String caseId;

	@Column(name="crt_dt")
	private Timestamp crtDt;

	@Column(name="file_name")
	private String fileName;

	@Column(name="pre_post")
	private String prePost;

	@Column(name="state_id")
	private String stateId;

	public TmsCaseAttachment() {
	}

	public Long getSno() {
		return this.sno;
	}

	public void setSno(Long sno) {
		this.sno = sno;
	}

	public String getAttachTotalPath() {
		return this.attachTotalPath;
	}

	public void setAttachTotalPath(String attachTotalPath) {
		this.attachTotalPath = attachTotalPath;
	}

	public String getAttachmentName() {
		return this.attachmentName;
	}

	public void setAttachmentName(String attachmentName) {
		this.attachmentName = attachmentName;
	}

	public String getCaseId() {
		return this.caseId;
	}

	public void setCaseId(String caseId) {
		this.caseId = caseId;
	}

	public Timestamp getCrtDt() {
		return this.crtDt;
	}

	public void setCrtDt(Timestamp crtDt) {
		this.crtDt = crtDt;
	}

	public String getFileName() {
		return this.fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	public String getPrePost() {
		return this.prePost;
	}

	public void setPrePost(String prePost) {
		this.prePost = prePost;
	}

	public String getStateId() {
		return this.stateId;
	}

	public void setStateId(String stateId) {
		this.stateId = stateId;
	}

}