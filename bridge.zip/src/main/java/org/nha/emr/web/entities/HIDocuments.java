package org.nha.emr.web.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.constraints.Size;


	@Entity
	@Table(name = "hi_documents")
	public class HIDocuments extends AuditModel {
	    /**
		 * 
		 */
		private static final long serialVersionUID = 1L;

		@Id
	    @GeneratedValue(generator = "document_generator")
	    @SequenceGenerator(
	            name = "document_generator",
	            sequenceName = "document_sequence",
	            initialValue = 1000
	    )
	    private Long docId;

	    @Size(min = 0, max = 256)
	    @Column(name = "consent_txn_num")
	    private String consentTxnNum;
	    
	    @Size(min = 0, max = 256)
	    @Column(name = "care_context_display")
	    private String careContextDisplay;
	    
	    	    
	    @Column(name = "fhirObject",columnDefinition = "TEXT",nullable = true)
	    private String fhirObject;

	    
		public Long getDocId() {
			return docId;
		}
		public void setDocId(Long docId) {
			this.docId = docId;
		}
		public String getConsentTxnNum() {
			return consentTxnNum;
		}
		public void setConsentTxnNum(String consentTxnNum) {
			this.consentTxnNum = consentTxnNum;
		}
		public String getCareContextDisplay() {
			return careContextDisplay;
		}
		public void setCareContextDisplay(String careContextDisplay) {
			this.careContextDisplay = careContextDisplay;
		}
		public String getFhirObject() {
			return fhirObject;
		}
		public void setFhirObject(String fhirObject) {
			this.fhirObject = fhirObject;
		}
       
	    
	}
