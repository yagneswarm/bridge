package org.nha.emr.web.repositories;

import java.util.List;

import org.nha.emr.web.entities.LocationMaster;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;

@Repository
@Component
public interface LocationRepository extends JpaRepository<LocationMaster, Long>{
	@Query(value="select distinct stateCode ,stateName  from LocationMaster  where activeYn='Y' order by stateName ")
	List<Object> findAllStates();
	
	 @Query(value="select distinct districtCode ,districtName  from LocationMaster lm where lm.activeYn='Y' and lm.stateCode=?1 order by districtName")
	List<Object> findWithDistrictId(String stateCode);

	@Query(value="select distinct sub_districtCode ,sub_districtName  from LocationMaster  where activeYn='Y' and districtCode=?1 order by sub_districtName" )
	List<Object> findWithSubDistrictId(String districtCode);
	
	@Query(value="select distinct villageCode ,villageName  from LocationMaster  where activeYn='Y' and sub_districtCode=?1 order by villageName" )
	List<Object> findWithTownId(String districtCode);

}
