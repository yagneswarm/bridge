package org.nha.emr.web.hip.model;

import java.util.Objects;

import javax.validation.Valid;

import org.springframework.validation.annotation.Validated;

import com.fasterxml.jackson.annotation.JsonProperty;

import io.swagger.annotations.ApiModelProperty;

/**
 * PatientLinkResponse
 */
@Validated

public class PatientLinkResponse   {
  @JsonProperty("patient")
  private PatientLinkResponsePatient patient = null;

  public PatientLinkResponse patient(PatientLinkResponsePatient patient) {
    this.patient = patient;
    return this;
  }

  /**
   * Get patient
   * @return patient
  **/
  @ApiModelProperty(value = "")
  
    @Valid
    public PatientLinkResponsePatient getPatient() {
    return patient;
  }

  public void setPatient(PatientLinkResponsePatient patient) {
    this.patient = patient;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    PatientLinkResponse patientLinkResponse = (PatientLinkResponse) o;
    return Objects.equals(this.patient, patientLinkResponse.patient);
  }

  @Override
  public int hashCode() {
    return Objects.hash(patient);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class PatientLinkResponse {\n");
    
    sb.append("    patient: ").append(toIndentedString(patient)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
