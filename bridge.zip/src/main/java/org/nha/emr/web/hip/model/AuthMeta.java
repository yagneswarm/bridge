package org.nha.emr.web.hip.model;

import java.util.Objects;

import org.springframework.validation.annotation.Validated;

import com.fasterxml.jackson.annotation.JsonProperty;

import io.swagger.annotations.ApiModelProperty;

/**
 * AuthMeta
 */
@Validated

public class AuthMeta   {
  @JsonProperty("hint")
  private String hint = null;

  @JsonProperty("expiry")
  private String expiry = null;

  public AuthMeta hint(String hint) {
    this.hint = hint;
    return this;
  }

  /**
   * Get hint
   * @return hint
  **/
 
    public String getHint() {
    return hint;
  }

  public void setHint(String hint) {
    this.hint = hint;
  }

  public AuthMeta expiry(String expiry) {
    this.expiry = expiry;
    return this;
  }

  /**
   * Get expiry
   * @return expiry
  **/
  @ApiModelProperty(example = "2019-12-30T12:01:55Z", value = "")
  
    public String getExpiry() {
    return expiry;
  }

  public void setExpiry(String expiry) {
    this.expiry = expiry;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    AuthMeta authMeta = (AuthMeta) o;
    return Objects.equals(this.hint, authMeta.hint) &&
        Objects.equals(this.expiry, authMeta.expiry);
  }

  @Override
  public int hashCode() {
    return Objects.hash(hint, expiry);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class AuthMeta {\n");
    
    sb.append("    hint: ").append(toIndentedString(hint)).append("\n");
    sb.append("    expiry: ").append(toIndentedString(expiry)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
