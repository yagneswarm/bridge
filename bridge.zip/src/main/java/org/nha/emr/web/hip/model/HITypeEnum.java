package org.nha.emr.web.hip.model;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;

/**
 * Gets or Sets HITypeEnum
 */
public enum HITypeEnum {
    DISCHARGESUMMARY("DischargeSummary"),
    OPCONSULTATION("OPConsultation"),
    MEDICATIONREQUEST("Prescription"),
    DIAGNOSTICREPORT("DiagnosticReport");
	
  private String value;

  HITypeEnum(String value) {
    this.value = value;
  }

  @Override
  @JsonValue
  public String toString() {
    return String.valueOf(value);
  }

  @JsonCreator
  public static HITypeEnum fromValue(String text) {
    for (HITypeEnum b : HITypeEnum.values()) {
      if (String.valueOf(b.value).equals(text)) {
        return b;
      }
    }
    return null;
  }
}
