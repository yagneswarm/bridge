package org.nha.emr.web.hip.model;

import java.util.Objects;
import java.util.UUID;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;

import org.springframework.validation.annotation.Validated;

import com.fasterxml.jackson.annotation.JsonProperty;

import io.swagger.annotations.ApiModelProperty;

/**
 * HIPConsentNotificationNotification
 */
@Validated



public class HIPConsentNotificationNotification   {
  @JsonProperty("status")
  private ConsentStatus status = null;

  @JsonProperty("consentId")
  private UUID consentId = null;

  @JsonProperty("consentDetail")
  private HIPConsentNotificationNotificationConsentDetail consentDetail = null;

  @JsonProperty("signature")
  private String signature = null;

  public HIPConsentNotificationNotification status(ConsentStatus status) {
    this.status = status;
    return this;
  }

  /**
   * Get status
   * @return status
  **/
  @ApiModelProperty(required = true, value = "")
      @NotNull

    @Valid
    public ConsentStatus getStatus() {
    return status;
  }

  public void setStatus(ConsentStatus status) {
    this.status = status;
  }

  public HIPConsentNotificationNotification consentId(UUID consentId) {
    this.consentId = consentId;
    return this;
  }

  /**
   * Get consentId
   * @return consentId
  **/
  @ApiModelProperty(required = true, value = "")
      @NotNull

    @Valid
    public UUID getConsentId() {
    return consentId;
  }

  public void setConsentId(UUID consentId) {
    this.consentId = consentId;
  }

  public HIPConsentNotificationNotification consentDetail(HIPConsentNotificationNotificationConsentDetail consentDetail) {
    this.consentDetail = consentDetail;
    return this;
  }

  /**
   * Get consentDetail
   * @return consentDetail
  **/
  @ApiModelProperty(value = "")
  
    @Valid
    public HIPConsentNotificationNotificationConsentDetail getConsentDetail() {
    return consentDetail;
  }

  public void setConsentDetail(HIPConsentNotificationNotificationConsentDetail consentDetail) {
    this.consentDetail = consentDetail;
  }

  public HIPConsentNotificationNotification signature(String signature) {
    this.signature = signature;
    return this;
  }

  /**
   * Get signature
   * @return signature
  **/
  @ApiModelProperty(example = "Signature of CM as defined in W3C standards; Base64 encoded", value = "")
  
    public String getSignature() {
    return signature;
  }

  public void setSignature(String signature) {
    this.signature = signature;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    HIPConsentNotificationNotification hiPConsentNotificationNotification = (HIPConsentNotificationNotification) o;
    return Objects.equals(this.status, hiPConsentNotificationNotification.status) &&
        Objects.equals(this.consentId, hiPConsentNotificationNotification.consentId) &&
        Objects.equals(this.consentDetail, hiPConsentNotificationNotification.consentDetail) &&
        Objects.equals(this.signature, hiPConsentNotificationNotification.signature);
  }

  @Override
  public int hashCode() {
    return Objects.hash(status, consentId, consentDetail, signature);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class HIPConsentNotificationNotification {\n");
    
    sb.append("    status: ").append(toIndentedString(status)).append("\n");
    sb.append("    consentId: ").append(toIndentedString(consentId)).append("\n");
    sb.append("    consentDetail: ").append(toIndentedString(consentDetail)).append("\n");
    sb.append("    signature: ").append(toIndentedString(signature)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
