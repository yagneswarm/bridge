package org.nha.emr.web.hip.model;

import java.util.Objects;

import com.fasterxml.jackson.annotation.JsonProperty;

import io.swagger.annotations.ApiModelProperty;

public class ShareAcknowledgement {
	
	 @JsonProperty("status")
	  private String status = null;

	  @JsonProperty("healthId")
	  private String healthId = null;
	  
	  public ShareAcknowledgement status(String status) {
		    this.status = status;
		    return this;
		  }

	/**
	 * @return the status
	 */
	  
	  @ApiModelProperty(value = "")  
	public String getStatus() {
		return status;
	}

	/**
	 * @param status the status to set
	 */
	public void setStatus(String status) {
		this.status = status;
	}

	
	  public ShareAcknowledgement healthId(String healthId) {
		    this.healthId = healthId;
		    return this;
		  }
	/**
	 * @return the healthId
	 */
	  
	  @ApiModelProperty(value = "")  
	public String getHealthId() {
		return healthId;
	}

	/**
	 * @param healthId the healthId to set
	 */
	public void setHealthId(String healthId) {
		this.healthId = healthId;
	}
	
	  @Override
	  public boolean equals(java.lang.Object o) {
	    if (this == o) {
	      return true;
	    }
	    if (o == null || getClass() != o.getClass()) {
	      return false;
	    }
	    ShareAcknowledgement shareAcknowledgement = (ShareAcknowledgement) o;
	    return Objects.equals(this.status, shareAcknowledgement.status) &&
	        Objects.equals(this.healthId, shareAcknowledgement.healthId);
	  }

	  @Override
	  public int hashCode() {
	    return Objects.hash(status, healthId);
	  }

	  @Override
	  public String toString() {
	    StringBuilder sb = new StringBuilder();
	    sb.append("class ShareAcknowledgement {\n");
	    
	    sb.append("    status: ").append(toIndentedString(status)).append("\n");
	    sb.append("    healthId: ").append(toIndentedString(healthId)).append("\n");
	    sb.append("}");
	    return sb.toString();
	  }

	  /**
	   * Convert the given object to string with each line indented by 4 spaces
	   * (except the first line).
	   */
	  private String toIndentedString(java.lang.Object o) {
	    if (o == null) {
	      return "null";
	    }
	    return o.toString().replace("\n", "\n    ");
	  }
	  
	  

}
