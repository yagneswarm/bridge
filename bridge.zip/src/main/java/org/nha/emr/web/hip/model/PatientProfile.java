package org.nha.emr.web.hip.model;

import java.util.List;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;

import org.springframework.validation.annotation.Validated;

import com.fasterxml.jackson.annotation.JsonProperty;

import io.swagger.annotations.ApiModelProperty;

/**
 * Patient profile part in share api callbacks . 
 */
@Validated
public class PatientProfile {

	  @JsonProperty("healthId")
	  private String healthId = null;
	
	  @JsonProperty("healthIdNumber")
	  private String healthIdNumber = null;
	
	  @JsonProperty("name")
	  private String name = null;

	  @JsonProperty("gender")
	  private PatientGender gender = null;

	  @JsonProperty("address")
	  private PatientAddress address = null;
	  
	  @JsonProperty("yearOfBirth")
	  private String yearOfBirth = null;
	  
	  @JsonProperty("dayOfBirth")
	  private String dayOfBirth = null;
	  
	  @JsonProperty("monthOfBirth")
	  private String monthOfBirth = null;
	  
	  @JsonProperty("identifiers")
	  private List<Identifier> identifiers = null;
	  
	  @ApiModelProperty(example = "<username>@<suffix>", required = true, value = "")
      @NotNull
	  public PatientProfile healthId(String healthId) {
		    this.healthId = healthId;
		    return this;
		  }
	
	  
	  public String getHealthId() {
			return healthId;
		}

		public void setHealthId(String healthId) {
			this.healthId = healthId;
		}

		  @ApiModelProperty(example = "1111-1111-1111-11", required = true, value = "")
	      @NotNull
	  public PatientProfile healthIdNumber(String healthIdNumber) {
		    this.healthIdNumber = healthIdNumber;
		    return this;
		  }
	
	  
	public String getHealthIdNumber() {
		return healthIdNumber;
	}

	public void setHealthIdNumber(String healthIdNumber) {
		this.healthIdNumber = healthIdNumber;
	}



	public PatientProfile name(String name) {
	    this.name = name;
	    return this;
	  }

	  /**
	   * Get name
	   * @return name
	  **/
	  @ApiModelProperty(example = "janki das", required = true, value = "")
	      @NotNull

	    public String getName() {
	    return name;
	  }

	  public void setName(String name) {
	    this.name = name;
	  }

	  public PatientProfile gender(PatientGender gender) {
	    this.gender = gender;
	    return this;
	  }

	  /**
	   * Get gender
	   * @return gender
	  **/
	  @ApiModelProperty(required = true, value = "")
	      @NotNull

	    @Valid
	    public PatientGender getGender() {
	    return gender;
	  }

	  public void setGender(PatientGender gender) {
	    this.gender = gender;
	  }
	  
	  public PatientProfile address(PatientAddress address) {
		    this.address = address;
		    return this;
		  }

		  /**
		   * Get address
		   * @return address
		  **/
		  @ApiModelProperty(value = "")
		  
		    @Valid
		    public PatientAddress getAddress() {
		    return address;
		  }

		  public void setAddress(PatientAddress address) {
		    this.address = address;
		  }
		  
		  public PatientProfile yearOfBirth(String yearOfBirth) {
			    this.yearOfBirth = yearOfBirth;
			    return this;
			  }

			  /**
			   * yearOfBirth in YYYY.
			   * @return dateOfBirth
			  **/
			  @ApiModelProperty(example = "1972", required = true, value = "year of birth in YYYY format.")
			      @NotNull

			    public String getYearOfBirth() {
			    return yearOfBirth;
			  }

			  public void setYearOfBirth(String yearOfBirth) {
			    this.yearOfBirth = yearOfBirth;
			  }

	  public PatientProfile dayOfBirth(String dayOfBirth) {
	    this.dayOfBirth = dayOfBirth;
	    return this;
	  }

	  /**
	   * day of birth in DD format.
	   * @return dayOfBirth
	  **/
	  @ApiModelProperty(example = "29", required = true, value = "date of birth in DD format.")
	

	    public String getDayOfBirth() {
	    return dayOfBirth;
	  }

	  public void setDayOfBirth(String dayOfBirth) {
	    this.dayOfBirth = dayOfBirth;
	  }
	  
	  public PatientProfile monthOfBirth(String monthOfBirth) {
		    this.monthOfBirth = monthOfBirth;
		    return this;
		  }

		  /**
		   * month of birth in MM format.
		   * @return dateOfBirth
		  **/
		  @ApiModelProperty(example = "02", required = true, value = "month of birth in MM format.")
		  

		    public String getMonthOfBirth() {
		    return monthOfBirth;
		  }

		  public void setMonthOfBirth(String monthOfBirth) {
		    this.monthOfBirth = monthOfBirth;
		  }

	 

	  /**
	   * Get identifier
	   * @return identifier
	  **/
	 


	  

	  /**
	   * Convert the given object to string with each line indented by 4 spaces
	   * (except the first line).
	   */
	  private String toIndentedString(java.lang.Object o) {
	    if (o == null) {
	      return "null";
	    }
	    return o.toString().replace("\n", "\n    ");
	  }


	  public PatientProfile identifiers(List<Identifier> identifiers) {
		    this.identifiers = identifiers;
		    return this;
		  }
	  
	public List<Identifier> getIdentifiers() {
		return identifiers;
	}


	public void setIdentifiers(List<Identifier> identifiers) {
		this.identifiers = identifiers;
	}


	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((address == null) ? 0 : address.hashCode());
		result = prime * result + ((dayOfBirth == null) ? 0 : dayOfBirth.hashCode());
		result = prime * result + ((gender == null) ? 0 : gender.hashCode());
		result = prime * result + ((healthId == null) ? 0 : healthId.hashCode());
		result = prime * result + ((healthIdNumber == null) ? 0 : healthIdNumber.hashCode());
		result = prime * result + ((identifiers == null) ? 0 : identifiers.hashCode());
		result = prime * result + ((monthOfBirth == null) ? 0 : monthOfBirth.hashCode());
		result = prime * result + ((name == null) ? 0 : name.hashCode());
		result = prime * result + ((yearOfBirth == null) ? 0 : yearOfBirth.hashCode());
		return result;
	}


	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		PatientProfile other = (PatientProfile) obj;
		if (address == null) {
			if (other.address != null)
				return false;
		} else if (!address.equals(other.address))
			return false;
		if (dayOfBirth == null) {
			if (other.dayOfBirth != null)
				return false;
		} else if (!dayOfBirth.equals(other.dayOfBirth))
			return false;
		if (gender != other.gender)
			return false;
		if (healthId == null) {
			if (other.healthId != null)
				return false;
		} else if (!healthId.equals(other.healthId))
			return false;
		if (healthIdNumber == null) {
			if (other.healthIdNumber != null)
				return false;
		} else if (!healthIdNumber.equals(other.healthIdNumber))
			return false;
		if (identifiers == null) {
			if (other.identifiers != null)
				return false;
		} else if (!identifiers.equals(other.identifiers))
			return false;
		if (monthOfBirth == null) {
			if (other.monthOfBirth != null)
				return false;
		} else if (!monthOfBirth.equals(other.monthOfBirth))
			return false;
		if (name == null) {
			if (other.name != null)
				return false;
		} else if (!name.equals(other.name))
			return false;
		if (yearOfBirth == null) {
			if (other.yearOfBirth != null)
				return false;
		} else if (!yearOfBirth.equals(other.yearOfBirth))
			return false;
		return true;
	}


	@Override
	public String toString() {
		return "PatientProfile [healthId=" + healthId + ", healthIdNumber=" + healthIdNumber + ", name=" + name
				+ ", gender=" + gender + ", address=" + address + ", yearOfBirth=" + yearOfBirth + ", dayOfBirth="
				+ dayOfBirth + ", monthOfBirth=" + monthOfBirth + ", identifiers=" + identifiers + "]";
	}
	  

}
