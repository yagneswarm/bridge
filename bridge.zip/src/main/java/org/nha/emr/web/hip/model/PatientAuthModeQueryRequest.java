package org.nha.emr.web.hip.model;

import java.util.Objects;
import java.util.UUID;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;

import org.springframework.validation.annotation.Validated;

import com.fasterxml.jackson.annotation.JsonProperty;

import io.swagger.annotations.ApiModelProperty;

/**
 * PatientAuthModeQueryRequest
 */
@Validated

public class PatientAuthModeQueryRequest   {
  @JsonProperty("requestId")
  private UUID requestId = null;

  @JsonProperty("timestamp")
  private String timestamp = null;

  @JsonProperty("query")
  private PatientAuthModeQueryRequestQuery query = null;

  public PatientAuthModeQueryRequest requestId(UUID requestId) {
    this.requestId = requestId;
    return this;
  }

  /**
   * a nonce, unique for each HTTP request
   * @return requestId
  **/
  @ApiModelProperty(example = "5f7a535d-a3fd-416b-b069-c97d021fbacd", required = true, value = "a nonce, unique for each HTTP request")
      @NotNull

    @Valid
    public UUID getRequestId() {
    return requestId;
  }

  public void setRequestId(UUID requestId) {
    this.requestId = requestId;
  }

  public PatientAuthModeQueryRequest timestamp(String timestamp) {
    this.timestamp = timestamp;
    return this;
  }

  /**
   * Get timestamp
   * @return timestamp
  **/
  @ApiModelProperty(required = true, value = "")
      @NotNull

    @Valid
    public String getTimestamp() {
    return timestamp;
  }

  public void setTimestamp(String timestamp) {
    this.timestamp = timestamp;
  }

  public PatientAuthModeQueryRequest query(PatientAuthModeQueryRequestQuery query) {
    this.query = query;
    return this;
  }

  /**
   * Get query
   * @return query
  **/
  @ApiModelProperty(required = true, value = "")
      @NotNull

    @Valid
    public PatientAuthModeQueryRequestQuery getQuery() {
    return query;
  }

  public void setQuery(PatientAuthModeQueryRequestQuery query) {
    this.query = query;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    PatientAuthModeQueryRequest patientAuthModeQueryRequest = (PatientAuthModeQueryRequest) o;
    return Objects.equals(this.requestId, patientAuthModeQueryRequest.requestId) &&
        Objects.equals(this.timestamp, patientAuthModeQueryRequest.timestamp) &&
        Objects.equals(this.query, patientAuthModeQueryRequest.query);
  }

  @Override
  public int hashCode() {
    return Objects.hash(requestId, timestamp, query);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class PatientAuthModeQueryRequest {\n");
    
    sb.append("    requestId: ").append(toIndentedString(requestId)).append("\n");
    sb.append("    timestamp: ").append(toIndentedString(timestamp)).append("\n");
    sb.append("    query: ").append(toIndentedString(query)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
