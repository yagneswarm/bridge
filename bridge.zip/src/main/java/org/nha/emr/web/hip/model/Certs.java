package org.nha.emr.web.hip.model;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import javax.validation.Valid;

import org.springframework.validation.annotation.Validated;

import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * Certs
 */
@Validated



public class Certs   {
  @JsonProperty("keys")
  @Valid
  private List<CertificateOrKeyGetSchema> keys = null;

  public Certs keys(List<CertificateOrKeyGetSchema> keys) {
    this.keys = keys;
    return this;
  }

  public Certs addKeysItem(CertificateOrKeyGetSchema keysItem) {
    if (this.keys == null) {
      this.keys = new ArrayList<CertificateOrKeyGetSchema>();
    }
    this.keys.add(keysItem);
    return this;
  }

  /**
   * Get keys
   * @return keys
  **/
      @Valid
    public List<CertificateOrKeyGetSchema> getKeys() {
    return keys;
  }

  public void setKeys(List<CertificateOrKeyGetSchema> keys) {
    this.keys = keys;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    Certs certs = (Certs) o;
    return Objects.equals(this.keys, certs.keys);
  }

  @Override
  public int hashCode() {
    return Objects.hash(keys);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class Certs {\n");
    
    sb.append("    keys: ").append(toIndentedString(keys)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
