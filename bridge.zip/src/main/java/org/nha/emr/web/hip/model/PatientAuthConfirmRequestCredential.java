package org.nha.emr.web.hip.model;

import java.util.Objects;

import javax.validation.Valid;

import org.springframework.validation.annotation.Validated;

import com.fasterxml.jackson.annotation.JsonProperty;

import io.swagger.annotations.ApiModelProperty;

/**
 * note, demographic details are only required for demographic auth at this point.
 */
@Validated
public class PatientAuthConfirmRequestCredential   {
  @JsonProperty("authCode")
  private String authCode = null;

  @JsonProperty("demographic")
  private PatientDemographic demographic = null;

  public PatientAuthConfirmRequestCredential authCode(String authCode) {
    this.authCode = authCode;
    return this;
  }

  /**
   * Get authCode
   * @return authCode
  **/
  @ApiModelProperty(value = "")
  
    public String getAuthCode() {
    return authCode;
  }

  public void setAuthCode(String authCode) {
    this.authCode = authCode;
  }

  public PatientAuthConfirmRequestCredential demographic(PatientDemographic demographic) {
    this.demographic = demographic;
    return this;
  }

  /**
   * Get demographic
   * @return demographic
  **/
  @ApiModelProperty(value = "")
  
    @Valid
    public PatientDemographic getDemographic() {
    return demographic;
  }

  public void setDemographic(PatientDemographic demographic) {
    this.demographic = demographic;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    PatientAuthConfirmRequestCredential patientAuthConfirmRequestCredential = (PatientAuthConfirmRequestCredential) o;
    return Objects.equals(this.authCode, patientAuthConfirmRequestCredential.authCode) &&
        Objects.equals(this.demographic, patientAuthConfirmRequestCredential.demographic);
  }

  @Override
  public int hashCode() {
    return Objects.hash(authCode, demographic);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class PatientAuthConfirmRequestCredential {\n");
    
    sb.append("    authCode: ").append(toIndentedString(authCode)).append("\n");
    sb.append("    demographic: ").append(toIndentedString(demographic)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
