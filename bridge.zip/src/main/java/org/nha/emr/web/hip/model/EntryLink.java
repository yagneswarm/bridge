package org.nha.emr.web.hip.model;

import java.util.Objects;

import javax.validation.constraints.NotNull;

import org.springframework.validation.annotation.Validated;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonValue;

import io.swagger.annotations.ApiModelProperty;

/**
 * EntryLink
 */
@Validated



public class EntryLink  implements AnyOfDataNotificationEntriesItems {
  @JsonProperty("link")
  private String link = null;

  /**
   * mimetype of the content.
   */
  public enum MediaEnum {
    JSON("application/fhir+json");

    private String value;

    MediaEnum(String value) {
      this.value = value;
    }

    @Override
    @JsonValue
    public String toString() {
      return String.valueOf(value);
    }

    @JsonCreator
    public static MediaEnum fromValue(String text) {
      for (MediaEnum b : MediaEnum.values()) {
        if (String.valueOf(b.value).equals(text)) {
          return b;
        }
      }
      return null;
    }
  }
  @JsonProperty("media")
  private MediaEnum media = null;

  @JsonProperty("checksum")
  private String checksum = null;

  @JsonProperty("careContextReference")
  private String careContextReference = null;

  public EntryLink link(String link) {
    this.link = link;
    return this;
  }

  /**
   * Encrypted content
   * @return link
  **/
  @ApiModelProperty(example = "https://data-from.net/sa2321afaf12e13", required = true, value = "Encrypted content")
      @NotNull

    public String getLink() {
    return link;
  }

  public void setLink(String link) {
    this.link = link;
  }

  public EntryLink media(MediaEnum media) {
    this.media = media;
    return this;
  }

  /**
   * mimetype of the content.
   * @return media
  **/
  @ApiModelProperty(required = true, value = "mimetype of the content.")
      @NotNull

    public MediaEnum getMedia() {
    return media;
  }

  public void setMedia(MediaEnum media) {
    this.media = media;
  }

  public EntryLink checksum(String checksum) {
    this.checksum = checksum;
    return this;
  }

  /**
   * Md5 checksum of the content before encryption
   * @return checksum
  **/
  @ApiModelProperty(required = true, value = "Md5 checksum of the content before encryption")
      @NotNull

    public String getChecksum() {
    return checksum;
  }

  public void setChecksum(String checksum) {
    this.checksum = checksum;
  }

  public EntryLink careContextReference(String careContextReference) {
    this.careContextReference = careContextReference;
    return this;
  }

  /**
   * care context reference number.
   * @return careContextReference
  **/
  @ApiModelProperty(example = "NCC1701", required = true, value = "care context reference number.")
      @NotNull

    public String getCareContextReference() {
    return careContextReference;
  }

  public void setCareContextReference(String careContextReference) {
    this.careContextReference = careContextReference;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    EntryLink entryLink = (EntryLink) o;
    return Objects.equals(this.link, entryLink.link) &&
        Objects.equals(this.media, entryLink.media) &&
        Objects.equals(this.checksum, entryLink.checksum) &&
        Objects.equals(this.careContextReference, entryLink.careContextReference);
  }

  @Override
  public int hashCode() {
    return Objects.hash(link, media, checksum, careContextReference);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class EntryLink {\n");
    
    sb.append("    link: ").append(toIndentedString(link)).append("\n");
    sb.append("    media: ").append(toIndentedString(media)).append("\n");
    sb.append("    checksum: ").append(toIndentedString(checksum)).append("\n");
    sb.append("    careContextReference: ").append(toIndentedString(careContextReference)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
