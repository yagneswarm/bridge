package org.nha.emr.web.repositories;

import java.util.Date;
import java.util.List;

import org.nha.emr.web.entities.PatientClinicalNotesDetails;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

@Repository
public interface PatientClinicalNotesRepository extends JpaRepository<PatientClinicalNotesDetails, Long> {
    //List<PatientClinicalNotesDetails> findByVisitId(Long visitId);
	@Query(value="select * from patient_clinical_notes_dtls pc where pc.visit_id=?",nativeQuery = true )
	PatientClinicalNotesDetails findWithVisitId(Long visitId);
	
	@Query(value="select * from patient_clinical_notes_dtls pc where pc.visit_id=?1 and updated_at between ?2 and ?3 ",nativeQuery = true )
	List<PatientClinicalNotesDetails> findWithVisitIdWithDateRange(Long visitId,Date fromDt,Date toDt);
	
}
