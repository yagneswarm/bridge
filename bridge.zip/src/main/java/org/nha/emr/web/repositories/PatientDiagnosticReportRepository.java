package org.nha.emr.web.repositories;

import java.util.Date;
import java.util.List;

import org.nha.emr.web.entities.PatientDiagnosticReportDetails;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

@Repository
public interface PatientDiagnosticReportRepository extends JpaRepository<PatientDiagnosticReportDetails, Long> {
    //List<PatientDiagnosticReportDetails> findByVisitId(Long visitId);
	@Query(value="select * from patient_diagnostic_report_dtls pd where pd.visit_id=?",nativeQuery = true )
	PatientDiagnosticReportDetails findWithVisitId(Long visitId);
	
	@Query(value="select * from patient_diagnostic_report_dtls pd where pd.visit_id=?1 and updated_at between ?2 and ?3 ",nativeQuery = true )
	List<PatientDiagnosticReportDetails> findWithVisitIdDateRange(Long visitId,Date fromDt,Date toDt);
	
	
}
