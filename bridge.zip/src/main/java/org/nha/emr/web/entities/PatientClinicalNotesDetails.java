package org.nha.emr.web.entities;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.Size;

import org.hibernate.annotations.OnDelete;
import org.hibernate.annotations.OnDeleteAction;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name = "patient_clinical_notes_dtls")
public class PatientClinicalNotesDetails extends AuditModel {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(generator = "clinical_notes_generator")
	@SequenceGenerator(name = "clinical_notes_generator", sequenceName = "clinical_notes_sequence", initialValue = 1)
	private Long id;

	@Column(name = "allergy")
	private String allergy;

	@Column(name = "history")
	private String history;

	@Column(name = "symptoms")
	private String symptoms;

	@Column(name = "vitals")
	private String vitals;

	@Column(name = "diagnosis")
	private String diagnosis;
	
	@Column(name = "treatment_plan")
	private String treatmentPlan;
	
	@Column(name = "prescription")
	private String prescription;
	
	@Column(name = "follow_up_dt")
	private Date followUpDate;
	
	@Column(name = "attach_path")
	private String attachPath;
	
	@Column(name = "notes")
	private String notes;
	
	@Column(name="report_type")
	private String reportType;

	@Size(min = 0, max = 100)
	@Column(name = "document_status")
	private String documentStatus;

	@Size(min = 0, max = 100)
	@Column(name = "document_category")
	private String documentCategory;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "document_created_dt", nullable = false)
	private Date documentCreatedDt;

	@Size(min = 0, max = 100)
	@Column(name = "document_by", nullable = false)
	private String documentBy;

	@Size(min = 0, max = 100)
	@Column(name = "document_source", nullable = false)
	private String documentSource;

	@Size(min = 0, max = 100)
	@Column(name = "document_created_at", nullable = false)
	private String documentCreatedAt;

	@ManyToOne(fetch = FetchType.LAZY, optional = false)
	@JoinColumn(name = "visit_id", nullable = false)
	@OnDelete(action = OnDeleteAction.CASCADE)
	@JsonIgnore
	private PatientVisitDetails patientVisitDetails;

	public PatientClinicalNotesDetails() {
		// TODO Auto-generated constructor stub
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getDocumentStatus() {
		return documentStatus;
	}

	public void setDocumentStatus(String documentStatus) {
		this.documentStatus = documentStatus;
	}

	public String getDocumentCategory() {
		return documentCategory;
	}

	public void setDocumentCategory(String documentCategory) {
		this.documentCategory = documentCategory;
	}

	public Date getDocumentCreatedDt() {
		return documentCreatedDt;
	}

	public void setDocumentCreatedDt(Date documentCreatedDt) {
		this.documentCreatedDt = documentCreatedDt;
	}

	public String getDocumentBy() {
		return documentBy;
	}

	public void setDocumentBy(String documentBy) {
		this.documentBy = documentBy;
	}

	public String getDocumentSource() {
		return documentSource;
	}

	public void setDocumentSource(String documentSource) {
		this.documentSource = documentSource;
	}

	public String getDocumentCreatedAt() {
		return documentCreatedAt;
	}

	public void setDocumentCreatedAt(String documentCreatedAt) {
		this.documentCreatedAt = documentCreatedAt;
	}

	public PatientVisitDetails getPatientVisitDetails() {
		return patientVisitDetails;
	}

	public void setPatientVisitDetails(PatientVisitDetails patientVisitDetails) {
		this.patientVisitDetails = patientVisitDetails;
	}

	public String getAllergy() {
		return allergy;
	}

	public void setAllergy(String allergy) {
		this.allergy = allergy;
	}

	public String getHistory() {
		return history;
	}

	public void setHistory(String history) {
		this.history = history;
	}

	public String getSymptoms() {
		return symptoms;
	}

	public void setSymptoms(String symptoms) {
		this.symptoms = symptoms;
	}

	public String getVitals() {
		return vitals;
	}

	public void setVitals(String vitals) {
		this.vitals = vitals;
	}

	public String getDiagnosis() {
		return diagnosis;
	}

	public void setDiagnosis(String diagnosis) {
		this.diagnosis = diagnosis;
	}

	public String getTreatmentPlan() {
		return treatmentPlan;
	}

	public void setTreatmentPlan(String treatmentPlan) {
		this.treatmentPlan = treatmentPlan;
	}

	public String getPrescription() {
		return prescription;
	}

	public void setPrescription(String prescription) {
		this.prescription = prescription;
	}

	public Date getFollowUpDate() {
		return followUpDate;
	}

	public void setFollowUpDate(Date followUpDate) {
		this.followUpDate = followUpDate;
	}

	public String getAttachPath() {
		return attachPath;
	}

	public void setAttachPath(String attachPath) {
		this.attachPath = attachPath;
	}

	public String getNotes() {
		return notes;
	}

	public void setNotes(String notes) {
		this.notes = notes;
	}

	public String getReportType() {
		return reportType;
	}

	public void setReportType(String reportType) {
		this.reportType = reportType;
	}
	
	
	

}
