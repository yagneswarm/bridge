package org.nha.emr.web.hip.model;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import javax.validation.Valid;

import org.springframework.validation.annotation.Validated;

import com.fasterxml.jackson.annotation.JsonProperty;

import io.swagger.annotations.ApiModelProperty;

/**
 * PatientLinkResponsePatient
 */
@Validated

public class PatientLinkResponsePatient   {
  @JsonProperty("referenceNumber")
  private String referenceNumber = null;

  @JsonProperty("display")
  private String display = null;

  @JsonProperty("careContexts")
  @Valid
  private List<CareContextRepresentation> careContexts = null;

  public PatientLinkResponsePatient referenceNumber(String referenceNumber) {
    this.referenceNumber = referenceNumber;
    return this;
  }

  /**
   * Get referenceNumber
   * @return referenceNumber
  **/
  @ApiModelProperty(value = "")
  
    public String getReferenceNumber() {
    return referenceNumber;
  }

  public void setReferenceNumber(String referenceNumber) {
    this.referenceNumber = referenceNumber;
  }

  public PatientLinkResponsePatient display(String display) {
    this.display = display;
    return this;
  }

  /**
   * Get display
   * @return display
  **/
  @ApiModelProperty(value = "")
  
    public String getDisplay() {
    return display;
  }

  public void setDisplay(String display) {
    this.display = display;
  }

  public PatientLinkResponsePatient careContexts(List<CareContextRepresentation> careContexts) {
    this.careContexts = careContexts;
    return this;
  }

  public PatientLinkResponsePatient addCareContextsItem(CareContextRepresentation careContextsItem) {
    if (this.careContexts == null) {
      this.careContexts = new ArrayList<CareContextRepresentation>();
    }
    this.careContexts.add(careContextsItem);
    return this;
  }

  /**
   * Get careContexts
   * @return careContexts
  **/
  @ApiModelProperty(value = "")
      @Valid
    public List<CareContextRepresentation> getCareContexts() {
    return careContexts;
  }

  public void setCareContexts(List<CareContextRepresentation> careContexts) {
    this.careContexts = careContexts;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    PatientLinkResponsePatient patientLinkResponsePatient = (PatientLinkResponsePatient) o;
    return Objects.equals(this.referenceNumber, patientLinkResponsePatient.referenceNumber) &&
        Objects.equals(this.display, patientLinkResponsePatient.display) &&
        Objects.equals(this.careContexts, patientLinkResponsePatient.careContexts);
  }

  @Override
  public int hashCode() {
    return Objects.hash(referenceNumber, display, careContexts);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class PatientLinkResponsePatient {\n");
    
    sb.append("    referenceNumber: ").append(toIndentedString(referenceNumber)).append("\n");
    sb.append("    display: ").append(toIndentedString(display)).append("\n");
    sb.append("    careContexts: ").append(toIndentedString(careContexts)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
