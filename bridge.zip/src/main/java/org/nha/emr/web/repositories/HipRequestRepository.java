package org.nha.emr.web.repositories;

import org.nha.emr.web.entities.HipRequest;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface HipRequestRepository extends JpaRepository<HipRequest, String> {
	
}
