package org.nha.emr.web.repositories;

import java.util.List;

import org.nha.emr.web.entities.HIDocuments;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;

@Repository
@Component
public interface HiDocumentsRepository extends JpaRepository<HIDocuments, Long> {
	@Query("select a from HIDocuments a where a.consentTxnNum =?1")
	List<HIDocuments>  findByConsentRefId(String consentTxnNum);
}
