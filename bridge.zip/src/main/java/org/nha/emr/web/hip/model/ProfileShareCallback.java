package org.nha.emr.web.hip.model;

import java.util.Objects;
import java.util.UUID;

import javax.validation.Valid;

import org.springframework.validation.annotation.Validated;

import com.fasterxml.jackson.annotation.JsonProperty;

import io.swagger.annotations.ApiModelProperty;

@Validated
public class ProfileShareCallback {
	
	 @JsonProperty("requestId")
	  private UUID requestId = null;

	  @JsonProperty("timestamp")
	  private String timestamp = null;
	  

	  @JsonProperty("profile")
	  private ProfileDtls profile = null;
	  
	  public ProfileShareCallback requestId(UUID requestId) {
		    this.requestId = requestId;
		    return this;
		  }
	  
	  /**
	   * a nonce, unique for each HTTP request.
	   * @return requestId
	  **/
	  @ApiModelProperty(example = "499a5a4a-7dda-4f20-9b67-e24589627061", value = "a nonce, unique for each HTTP request.")
	   @Valid
	    public UUID getRequestId() {
	    return requestId;
	  }

	  public void setRequestId(UUID requestId) {
	    this.requestId = requestId;
	  }
	  
	  public ProfileShareCallback timestamp(String timestamp) {
		    this.timestamp = timestamp;
		    return this;
		  }

		  /**
		   * Get timestamp
		   * @return timestamp
		  **/
		  @ApiModelProperty(value = "")
		  
		    @Valid
		    public String getTimestamp() {
		    return timestamp;
		  }

		  public void setTimestamp(String timestamp) {
		    this.timestamp = timestamp;
		  }

		  public ProfileShareCallback patient(ProfileDtls profile) {
			    this.profile = profile;
			    return this;
			  }

			  /**
			   * Get patient
			   * @return patient
			  **/
			  @ApiModelProperty(value = "")
			  
			    @Valid
			    public ProfileDtls getProfile() {
			    return profile;
			  }

			  public void setProfile(ProfileDtls profile) {
			    this.profile = profile;
			  }
			  
			  
			  @Override
			  public boolean equals(java.lang.Object o) {
			    if (this == o) {
			      return true;
			    }
			    if (o == null || getClass() != o.getClass()) {
			      return false;
			    }
			    ProfileShareCallback profileShareCallback = (ProfileShareCallback) o;
			    return Objects.equals(this.requestId, profileShareCallback.requestId) &&
			        Objects.equals(this.timestamp, profileShareCallback.timestamp) &&
			        Objects.equals(this.profile, profileShareCallback.profile);
			  }
			  
			  @Override
			  public int hashCode() {
			    return Objects.hash(requestId, timestamp, profile);
			  }

			  @Override
			  public String toString() {
			    StringBuilder sb = new StringBuilder();
			    sb.append("class ProfileShareCallback {\n");
			    
			    sb.append("    requestId: ").append(toIndentedString(requestId)).append("\n");
			    sb.append("    timestamp: ").append(toIndentedString(timestamp)).append("\n");
			    sb.append("    profile: ").append(toIndentedString(profile)).append("\n");
			    sb.append("}");
			    return sb.toString();
			  }

			  /**
			   * Convert the given object to string with each line indented by 4 spaces
			   * (except the first line).
			   */
			  private String toIndentedString(java.lang.Object o) {
			    if (o == null) {
			      return "null";
			    }
			    return o.toString().replace("\n", "\n    ");
			  }
}
