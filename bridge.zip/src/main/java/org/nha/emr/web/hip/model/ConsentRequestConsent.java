package org.nha.emr.web.hip.model;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;

import org.springframework.validation.annotation.Validated;

import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * ConsentRequestConsent
 */
@Validated

public class ConsentRequestConsent   {
  @JsonProperty("purpose")
  private UsePurpose purpose = null;

  @JsonProperty("patient")
  private AllOfConsentRequestConsentPatient patient = null;

  @JsonProperty("hip")
  private AllOfConsentRequestConsentHip hip = null;

  @JsonProperty("hiu")
  private AllOfConsentRequestConsentHiu hiu = null;

  @JsonProperty("requester")
  private Requester requester = null;

  @JsonProperty("hiTypes")
  @Valid
  private List<HITypeEnum> hiTypes = new ArrayList<HITypeEnum>();

  @JsonProperty("permission")
  private Permission permission = null;

  public ConsentRequestConsent purpose(UsePurpose purpose) {
    this.purpose = purpose;
    return this;
  }

  /**
   * Get purpose
   * @return purpose
  **/
      @NotNull

    @Valid
    public UsePurpose getPurpose() {
    return purpose;
  }

  public void setPurpose(UsePurpose purpose) {
    this.purpose = purpose;
  }

  public ConsentRequestConsent patient(AllOfConsentRequestConsentPatient patient) {
    this.patient = patient;
    return this;
  }

  /**
   * Get patient
   * @return patient
  **/
      @NotNull

    public AllOfConsentRequestConsentPatient getPatient() {
    return patient;
  }

  public void setPatient(AllOfConsentRequestConsentPatient patient) {
    this.patient = patient;
  }

  public ConsentRequestConsent hip(AllOfConsentRequestConsentHip hip) {
    this.hip = hip;
    return this;
  }

  /**
   * Get hip
   * @return hip
  **/
  
    public AllOfConsentRequestConsentHip getHip() {
    return hip;
  }

  public void setHip(AllOfConsentRequestConsentHip hip) {
    this.hip = hip;
  }

  public ConsentRequestConsent hiu(AllOfConsentRequestConsentHiu hiu) {
    this.hiu = hiu;
    return this;
  }

  /**
   * Get hiu
   * @return hiu
  **/
      @NotNull

    public AllOfConsentRequestConsentHiu getHiu() {
    return hiu;
  }

  public void setHiu(AllOfConsentRequestConsentHiu hiu) {
    this.hiu = hiu;
  }

  public ConsentRequestConsent requester(Requester requester) {
    this.requester = requester;
    return this;
  }

  /**
   * Get requester
   * @return requester
  **/
      @NotNull

    @Valid
    public Requester getRequester() {
    return requester;
  }

  public void setRequester(Requester requester) {
    this.requester = requester;
  }

  public ConsentRequestConsent hiTypes(List<HITypeEnum> hiTypes) {
    this.hiTypes = hiTypes;
    return this;
  }

  public ConsentRequestConsent addHiTypesItem(HITypeEnum hiTypesItem) {
    this.hiTypes.add(hiTypesItem);
    return this;
  }

  /**
   * Get hiTypes
   * @return hiTypes
  **/
      @NotNull
    @Valid
    public List<HITypeEnum> getHiTypes() {
    return hiTypes;
  }

  public void setHiTypes(List<HITypeEnum> hiTypes) {
    this.hiTypes = hiTypes;
  }

  public ConsentRequestConsent permission(Permission permission) {
    this.permission = permission;
    return this;
  }

  /**
   * Get permission
   * @return permission
  **/
      @NotNull

    @Valid
    public Permission getPermission() {
    return permission;
  }

  public void setPermission(Permission permission) {
    this.permission = permission;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    ConsentRequestConsent consentRequestConsent = (ConsentRequestConsent) o;
    return Objects.equals(this.purpose, consentRequestConsent.purpose) &&
        Objects.equals(this.patient, consentRequestConsent.patient) &&
        Objects.equals(this.hip, consentRequestConsent.hip) &&
        Objects.equals(this.hiu, consentRequestConsent.hiu) &&
        Objects.equals(this.requester, consentRequestConsent.requester) &&
        Objects.equals(this.hiTypes, consentRequestConsent.hiTypes) &&
        Objects.equals(this.permission, consentRequestConsent.permission);
  }

  @Override
  public int hashCode() {
    return Objects.hash(purpose, patient, hip, hiu, requester, hiTypes, permission);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ConsentRequestConsent {\n");
    
    sb.append("    purpose: ").append(toIndentedString(purpose)).append("\n");
    sb.append("    patient: ").append(toIndentedString(patient)).append("\n");
    sb.append("    hip: ").append(toIndentedString(hip)).append("\n");
    sb.append("    hiu: ").append(toIndentedString(hiu)).append("\n");
    sb.append("    requester: ").append(toIndentedString(requester)).append("\n");
    sb.append("    hiTypes: ").append(toIndentedString(hiTypes)).append("\n");
    sb.append("    permission: ").append(toIndentedString(permission)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
