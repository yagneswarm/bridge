package org.nha.emr.web.hip.model;

import java.time.LocalDateTime;
import java.util.Objects;
import java.util.UUID;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;

import org.springframework.validation.annotation.Validated;

import com.fasterxml.jackson.annotation.JsonProperty;


/**
 * PatientIdentificationRequest
 */
@Validated

public class PatientIdentificationRequest   {
  @JsonProperty("requestId")
  private UUID requestId = null;

  @JsonProperty("timestamp")
  private LocalDateTime timestamp = null;

  @JsonProperty("query")
  private PatientIdentificationRequestQuery query = null;

  public PatientIdentificationRequest requestId(UUID requestId) {
    this.requestId = requestId;
    return this;
  }

  /**
   * a nonce, unique for each HTTP request
   * @return requestId
  **/
      @NotNull

    @Valid
    public UUID getRequestId() {
    return requestId;
  }

  public void setRequestId(UUID requestId) {
    this.requestId = requestId;
  }

  public PatientIdentificationRequest timestamp(LocalDateTime timestamp) {
    this.timestamp = timestamp;
    return this;
  }

  /**
   * Get timestamp
   * @return timestamp
  **/
      @NotNull

    @Valid
    public LocalDateTime getTimestamp() {
    return timestamp;
  }

  public void setTimestamp(LocalDateTime timestamp) {
    this.timestamp = timestamp;
  }

  public PatientIdentificationRequest query(PatientIdentificationRequestQuery query) {
    this.query = query;
    return this;
  }

  /**
   * Get query
   * @return query
  **/
      @NotNull

    @Valid
    public PatientIdentificationRequestQuery getQuery() {
    return query;
  }

  public void setQuery(PatientIdentificationRequestQuery query) {
    this.query = query;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    PatientIdentificationRequest patientIdentificationRequest = (PatientIdentificationRequest) o;
    return Objects.equals(this.requestId, patientIdentificationRequest.requestId) &&
        Objects.equals(this.timestamp, patientIdentificationRequest.timestamp) &&
        Objects.equals(this.query, patientIdentificationRequest.query);
  }

  @Override
  public int hashCode() {
    return Objects.hash(requestId, timestamp, query);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class PatientIdentificationRequest {\n");
    
    sb.append("    requestId: ").append(toIndentedString(requestId)).append("\n");
    sb.append("    timestamp: ").append(toIndentedString(timestamp)).append("\n");
    sb.append("    query: ").append(toIndentedString(query)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
