package org.nha.emr.web.repositories;

import java.util.List;

import org.nha.emr.web.entities.DiagnosticAttachment;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

@Repository
public interface DiagnosticAttachmentRepository extends JpaRepository<DiagnosticAttachment, Long>{
	@Query(value="select * from diagnostic_report_attachments pv where pv.visit_id=?1",nativeQuery = true )
	List<DiagnosticAttachment>  findWithVisitId(Long visitId);
}
