package org.nha.emr.web.hip.model;

import java.util.Objects;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;

import org.springframework.validation.annotation.Validated;

import com.fasterxml.jackson.annotation.JsonProperty;

import io.swagger.annotations.ApiModelProperty;

/**
 * PatientAuthInitRequestQuery
 */
@Validated

public class PatientAuthInitRequestQuery   {
  @JsonProperty("id")
  private String id = null;

  @JsonProperty("purpose")
  private PatientAuthPurpose purpose = null;

  @JsonProperty("authMode")
  private AuthenticationMode authMode = null;

  @JsonProperty("requester")
  private PatientAuthInitRequestQueryRequester requester = null;

  public PatientAuthInitRequestQuery id(String id) {
    this.id = id;
    return this;
  }

  /**
   * id  of the patient understood by the CM
   * @return id
  **/
  @ApiModelProperty(example = "hinapatel@ndhm", required = true, value = "id  of the patient understood by the CM")
      @NotNull

    public String getId() {
    return id;
  }

  public void setId(String id) {
    this.id = id;
  }

  public PatientAuthInitRequestQuery purpose(PatientAuthPurpose purpose) {
    this.purpose = purpose;
    return this;
  }

  /**
   * Get purpose
   * @return purpose
  **/
  @ApiModelProperty(required = true, value = "")
      @NotNull

    @Valid
    public PatientAuthPurpose getPurpose() {
    return purpose;
  }

  public void setPurpose(PatientAuthPurpose purpose) {
    this.purpose = purpose;
  }

  public PatientAuthInitRequestQuery authMode(AuthenticationMode authMode) {
    this.authMode = authMode;
    return this;
  }

  /**
   * Get authMode
   * @return authMode
  **/
  @ApiModelProperty(value = "")
  
    @Valid
    public AuthenticationMode getAuthMode() {
    return authMode;
  }

  public void setAuthMode(AuthenticationMode authMode) {
    this.authMode = authMode;
  }

  public PatientAuthInitRequestQuery requester(PatientAuthInitRequestQueryRequester requester) {
    this.requester = requester;
    return this;
  }

  /**
   * Get requester
   * @return requester
  **/
  @ApiModelProperty(required = true, value = "")
      @NotNull

    @Valid
    public PatientAuthInitRequestQueryRequester getRequester() {
    return requester;
  }

  public void setRequester(PatientAuthInitRequestQueryRequester requester) {
    this.requester = requester;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    PatientAuthInitRequestQuery patientAuthInitRequestQuery = (PatientAuthInitRequestQuery) o;
    return Objects.equals(this.id, patientAuthInitRequestQuery.id) &&
        Objects.equals(this.purpose, patientAuthInitRequestQuery.purpose) &&
        Objects.equals(this.authMode, patientAuthInitRequestQuery.authMode) &&
        Objects.equals(this.requester, patientAuthInitRequestQuery.requester);
  }

  @Override
  public int hashCode() {
    return Objects.hash(id, purpose, authMode, requester);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class PatientAuthInitRequestQuery {\n");
    
    sb.append("    id: ").append(toIndentedString(id)).append("\n");
    sb.append("    purpose: ").append(toIndentedString(purpose)).append("\n");
    sb.append("    authMode: ").append(toIndentedString(authMode)).append("\n");
    sb.append("    requester: ").append(toIndentedString(requester)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
