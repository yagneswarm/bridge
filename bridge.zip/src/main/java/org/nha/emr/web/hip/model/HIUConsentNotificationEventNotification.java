package org.nha.emr.web.hip.model;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;

import org.springframework.validation.annotation.Validated;

import com.fasterxml.jackson.annotation.JsonProperty;

import io.swagger.annotations.ApiModelProperty;

/**
 * HIUConsentNotificationEventNotification
 */
@Validated


public class HIUConsentNotificationEventNotification   {
  @JsonProperty("consentRequestId")
  private String consentRequestId = null;

  @JsonProperty("status")
  private ConsentStatus status = null;

  @JsonProperty("consentArtefacts")
  @Valid
  private List<ConsentArtefactReference> consentArtefacts = null;

  public HIUConsentNotificationEventNotification consentRequestId(String consentRequestId) {
    this.consentRequestId = consentRequestId;
    return this;
  }

  /**
   * Get consentRequestId
   * @return consentRequestId
  **/
  @ApiModelProperty(example = "<consent-request-id>", required = true, value = "")
      @NotNull

    public String getConsentRequestId() {
    return consentRequestId;
  }

  public void setConsentRequestId(String consentRequestId) {
    this.consentRequestId = consentRequestId;
  }

  public HIUConsentNotificationEventNotification status(ConsentStatus status) {
    this.status = status;
    return this;
  }

  /**
   * Get status
   * @return status
  **/
  @ApiModelProperty(required = true, value = "")
      @NotNull

    @Valid
    public ConsentStatus getStatus() {
    return status;
  }

  public void setStatus(ConsentStatus status) {
    this.status = status;
  }

  public HIUConsentNotificationEventNotification consentArtefacts(List<ConsentArtefactReference> consentArtefacts) {
    this.consentArtefacts = consentArtefacts;
    return this;
  }

  public HIUConsentNotificationEventNotification addConsentArtefactsItem(ConsentArtefactReference consentArtefactsItem) {
    if (this.consentArtefacts == null) {
      this.consentArtefacts = new ArrayList<ConsentArtefactReference>();
    }
    this.consentArtefacts.add(consentArtefactsItem);
    return this;
  }

  /**
   * if the status is GRANTED or REVOKED, then the consentArtefact references (Ids) must be specified.
   * @return consentArtefacts
  **/
  @ApiModelProperty(value = "if the status is GRANTED or REVOKED, then the consentArtefact references (Ids) must be specified.")
      @Valid
    public List<ConsentArtefactReference> getConsentArtefacts() {
    return consentArtefacts;
  }

  public void setConsentArtefacts(List<ConsentArtefactReference> consentArtefacts) {
    this.consentArtefacts = consentArtefacts;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    HIUConsentNotificationEventNotification hiUConsentNotificationEventNotification = (HIUConsentNotificationEventNotification) o;
    return Objects.equals(this.consentRequestId, hiUConsentNotificationEventNotification.consentRequestId) &&
        Objects.equals(this.status, hiUConsentNotificationEventNotification.status) &&
        Objects.equals(this.consentArtefacts, hiUConsentNotificationEventNotification.consentArtefacts);
  }

  @Override
  public int hashCode() {
    return Objects.hash(consentRequestId, status, consentArtefacts);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class HIUConsentNotificationEventNotification {\n");
    
    sb.append("    consentRequestId: ").append(toIndentedString(consentRequestId)).append("\n");
    sb.append("    status: ").append(toIndentedString(status)).append("\n");
    sb.append("    consentArtefacts: ").append(toIndentedString(consentArtefacts)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
