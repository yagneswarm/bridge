package org.nha.emr.web.hip.model;

import java.util.Objects;

import org.springframework.validation.annotation.Validated;

import com.fasterxml.jackson.annotation.JsonProperty;

import io.swagger.annotations.ApiModelProperty;

/**
 * OpenIdConfiguration
 */
@Validated



public class OpenIdConfiguration   {
  @JsonProperty("jwks_uri")
  private String jwksUri = null;

  public OpenIdConfiguration jwksUri(String jwksUri) {
    this.jwksUri = jwksUri;
    return this;
  }

  /**
   * Get jwksUri
   * @return jwksUri
  **/
  @ApiModelProperty(example = "https://ncg-gateway/certs", value = "")
  
    public String getJwksUri() {
    return jwksUri;
  }

  public void setJwksUri(String jwksUri) {
    this.jwksUri = jwksUri;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    OpenIdConfiguration openIdConfiguration = (OpenIdConfiguration) o;
    return Objects.equals(this.jwksUri, openIdConfiguration.jwksUri);
  }

  @Override
  public int hashCode() {
    return Objects.hash(jwksUri);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class OpenIdConfiguration {\n");
    
    sb.append("    jwksUri: ").append(toIndentedString(jwksUri)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
