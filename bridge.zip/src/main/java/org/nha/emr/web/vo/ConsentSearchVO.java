package org.nha.emr.web.vo;

import java.io.Serializable;

public class ConsentSearchVO implements Serializable {

	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private String patName;
	private String regDate;
	private String patId;
	private String facilityId;
	
	private String name;
	private String healthId;
	private String reqDate;
	private String reqStatus;
	private String consentGrantDt;
	private String consentExpiryDt;
	
	
	public String getPatName() {
		return patName;
	}

	public void setPatName(String patName) {
		this.patName = patName;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getHealthId() {
		return healthId;
	}

	public void setHealthId(String healthId) {
		this.healthId = healthId;
	}

	public String getReqDate() {
		return reqDate;
	}

	public void setReqDate(String reqDate) {
		this.reqDate = reqDate;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	public String getFacilityId() {
		return facilityId;
	}

	public void setFacilityId(String facilityId) {
		this.facilityId = facilityId;
	}

	public String getRegDate() {
		return regDate;
	}

	public void setRegDate(String regDate) {
		this.regDate = regDate;
	}

	public String getPatId() {
		return patId;
	}

	public void setPatId(String patId) {
		this.patId = patId;
	}
	public String getReqStatus() {
		return reqStatus;
	}

	public void setReqStatus(String reqStatus) {
		this.reqStatus = reqStatus;
	}

	public String getConsentGrantDt() {
		return consentGrantDt;
	}

	public void setConsentGrantDt(String consentGrantDt) {
		this.consentGrantDt = consentGrantDt;
	}

	public String getConsentExpiryDt() {
		return consentExpiryDt;
	}

	public void setConsentExpiryDt(String consentExpiryDt) {
		this.consentExpiryDt = consentExpiryDt;
	}
	
}
