package org.nha.emr.web.hip.model;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.UUID;

import javax.validation.Valid;

import org.springframework.validation.annotation.Validated;

import com.fasterxml.jackson.annotation.JsonProperty;

import io.swagger.annotations.ApiModelProperty;

/**
 * HIUConsentNotification
 */
@Validated

public class HIUConsentNotification   {
  @JsonProperty("requestId")
  private UUID requestId = null;

  @JsonProperty("timestamp")
  private String timestamp = null;

  @JsonProperty("consentRequestId")
  private String consentRequestId = null;

  @JsonProperty("status")
  private ConsentStatus status = null;

  @JsonProperty("consentArtefacts")
  @Valid
  private List<ConsentArtefactReference> consentArtefacts = null;

  public HIUConsentNotification requestId(UUID requestId) {
    this.requestId = requestId;
    return this;
  }

  /**
   * a nonce, unique for each HTTP request
   * @return requestId
  **/
  @ApiModelProperty(example = "5f7a535d-a3fd-416b-b069-c97d021fbacd", value = "a nonce, unique for each HTTP request")
  
    @Valid
    public UUID getRequestId() {
    return requestId;
  }

  public void setRequestId(UUID requestId) {
    this.requestId = requestId;
  }

  public HIUConsentNotification timestamp(String timestamp) {
    this.timestamp = timestamp;
    return this;
  }

  /**
   * Get timestamp
   * @return timestamp
  **/
  @ApiModelProperty(value = "")
  
    @Valid
    public String getTimestamp() {
    return timestamp;
  }

  public void setTimestamp(String timestamp) {
    this.timestamp = timestamp;
  }

  public HIUConsentNotification consentRequestId(String consentRequestId) {
    this.consentRequestId = consentRequestId;
    return this;
  }

  /**
   * Get consentRequestId
   * @return consentRequestId
  **/
  @ApiModelProperty(example = "<consent-request-id>", value = "")
  
    public String getConsentRequestId() {
    return consentRequestId;
  }

  public void setConsentRequestId(String consentRequestId) {
    this.consentRequestId = consentRequestId;
  }

  public HIUConsentNotification status(ConsentStatus status) {
    this.status = status;
    return this;
  }

  /**
   * Get status
   * @return status
  **/
  @ApiModelProperty(value = "")
  
    @Valid
    public ConsentStatus getStatus() {
    return status;
  }

  public void setStatus(ConsentStatus status) {
    this.status = status;
  }

  public HIUConsentNotification consentArtefacts(List<ConsentArtefactReference> consentArtefacts) {
    this.consentArtefacts = consentArtefacts;
    return this;
  }

  public HIUConsentNotification addConsentArtefactsItem(ConsentArtefactReference consentArtefactsItem) {
    if (this.consentArtefacts == null) {
      this.consentArtefacts = new ArrayList<ConsentArtefactReference>();
    }
    this.consentArtefacts.add(consentArtefactsItem);
    return this;
  }

  /**
   * Get consentArtefacts
   * @return consentArtefacts
  **/
  @ApiModelProperty(value = "")
      @Valid
    public List<ConsentArtefactReference> getConsentArtefacts() {
    return consentArtefacts;
  }

  public void setConsentArtefacts(List<ConsentArtefactReference> consentArtefacts) {
    this.consentArtefacts = consentArtefacts;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    HIUConsentNotification hiUConsentNotification = (HIUConsentNotification) o;
    return Objects.equals(this.requestId, hiUConsentNotification.requestId) &&
        Objects.equals(this.timestamp, hiUConsentNotification.timestamp) &&
        Objects.equals(this.consentRequestId, hiUConsentNotification.consentRequestId) &&
        Objects.equals(this.status, hiUConsentNotification.status) &&
        Objects.equals(this.consentArtefacts, hiUConsentNotification.consentArtefacts);
  }

  @Override
  public int hashCode() {
    return Objects.hash(requestId, timestamp, consentRequestId, status, consentArtefacts);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class HIUConsentNotification {\n");
    
    sb.append("    requestId: ").append(toIndentedString(requestId)).append("\n");
    sb.append("    timestamp: ").append(toIndentedString(timestamp)).append("\n");
    sb.append("    consentRequestId: ").append(toIndentedString(consentRequestId)).append("\n");
    sb.append("    status: ").append(toIndentedString(status)).append("\n");
    sb.append("    consentArtefacts: ").append(toIndentedString(consentArtefacts)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
