package org.nha.emr.web.hip.model;

import java.util.Objects;
import java.util.UUID;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonProperty;

import io.swagger.annotations.ApiModelProperty;

/**
 * PatientAuthConfirmResponse
 */


public class PatientAuthConfirmResponse   {
  @JsonProperty("requestId")
  private UUID requestId = null;

  @JsonProperty("timestamp")
  private String timestamp = null;

  @JsonProperty("auth")
  private PatientAuthConfirmResponseAuth auth = null;

  @JsonProperty("error")
  private Error error = null;

  @JsonProperty("resp")
  private RequestReference resp = null;

  public PatientAuthConfirmResponse requestId(UUID requestId) {
    this.requestId = requestId;
    return this;
  }

  /**
   * a nonce, unique for each HTTP request
   * @return requestId
  **/
  @ApiModelProperty(example = "5f7a535d-a3fd-416b-b069-c97d021fbacd", required = true, value = "a nonce, unique for each HTTP request")
      @NotNull

    @Valid
    public UUID getRequestId() {
    return requestId;
  }

  public void setRequestId(UUID requestId) {
    this.requestId = requestId;
  }

  public PatientAuthConfirmResponse timestamp(String timestamp) {
    this.timestamp = timestamp;
    return this;
  }

  /**
   * Get timestamp
   * @return timestamp
  **/
  @ApiModelProperty(required = true, value = "")
    @Valid
    public String getTimestamp() {
    return timestamp;
  }

  public void setTimestamp(String timestamp) {
    this.timestamp = timestamp;
  }

  public PatientAuthConfirmResponse auth(PatientAuthConfirmResponseAuth auth) {
    this.auth = auth;
    return this;
  }

  /**
   * Get auth
   * @return auth
  **/
  @ApiModelProperty(value = "")
  
    @Valid
    public PatientAuthConfirmResponseAuth getAuth() {
    return auth;
  }

  public void setAuth(PatientAuthConfirmResponseAuth auth) {
    this.auth = auth;
  }

  public PatientAuthConfirmResponse error(Error error) {
    this.error = error;
    return this;
  }

  /**
   * Get error
   * @return error
  **/
  @ApiModelProperty(value = "")
  
    @Valid
    public Error getError() {
    return error;
  }

  public void setError(Error error) {
    this.error = error;
  }

  public PatientAuthConfirmResponse resp(RequestReference resp) {
    this.resp = resp;
    return this;
  }

  /**
   * Get resp
   * @return resp
  **/
  @ApiModelProperty(required = true, value = "")
      @NotNull

    @Valid
    public RequestReference getResp() {
    return resp;
  }

  public void setResp(RequestReference resp) {
    this.resp = resp;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    PatientAuthConfirmResponse patientAuthConfirmResponse = (PatientAuthConfirmResponse) o;
    return Objects.equals(this.requestId, patientAuthConfirmResponse.requestId) &&
        Objects.equals(this.timestamp, patientAuthConfirmResponse.timestamp) &&
        Objects.equals(this.auth, patientAuthConfirmResponse.auth) &&
        Objects.equals(this.error, patientAuthConfirmResponse.error) &&
        Objects.equals(this.resp, patientAuthConfirmResponse.resp);
  }

  @Override
  public int hashCode() {
    return Objects.hash(requestId, timestamp, auth, error, resp);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class PatientAuthConfirmResponse {\n");
    
    sb.append("    requestId: ").append(toIndentedString(requestId)).append("\n");
    sb.append("    timestamp: ").append(toIndentedString(timestamp)).append("\n");
    sb.append("    auth: ").append(toIndentedString(auth)).append("\n");
    sb.append("    error: ").append(toIndentedString(error)).append("\n");
    sb.append("    resp: ").append(toIndentedString(resp)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
