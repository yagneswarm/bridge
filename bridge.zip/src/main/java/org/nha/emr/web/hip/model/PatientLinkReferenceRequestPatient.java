package org.nha.emr.web.hip.model;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import javax.validation.Valid;

import org.springframework.validation.annotation.Validated;

import com.fasterxml.jackson.annotation.JsonProperty;

import io.swagger.annotations.ApiModelProperty;

/**
 * PatientLinkReferenceRequestPatient
 */
@Validated



public class PatientLinkReferenceRequestPatient   {
  @JsonProperty("id")
  private String id = null;

  @JsonProperty("referenceNumber")
  private String referenceNumber = null;

  @JsonProperty("careContexts")
  @Valid
  private List<CareContext> careContexts = null;

  public PatientLinkReferenceRequestPatient id(String id) {
    this.id = id;
    return this;
  }

  /**
   * Get id
   * @return id
  **/
  @ApiModelProperty(example = "hinapatel79@ncg", value = "")
  
    public String getId() {
    return id;
  }

  public void setId(String id) {
    this.id = id;
  }

  public PatientLinkReferenceRequestPatient referenceNumber(String referenceNumber) {
    this.referenceNumber = referenceNumber;
    return this;
  }

  /**
   * Get referenceNumber
   * @return referenceNumber
  **/
  @ApiModelProperty(example = "TMH-PUID-001", value = "")
  
    public String getReferenceNumber() {
    return referenceNumber;
  }

  public void setReferenceNumber(String referenceNumber) {
    this.referenceNumber = referenceNumber;
  }

  public PatientLinkReferenceRequestPatient careContexts(List<CareContext> careContexts) {
    this.careContexts = careContexts;
    return this;
  }

  public PatientLinkReferenceRequestPatient addCareContextsItem(CareContext careContextsItem) {
    if (this.careContexts == null) {
      this.careContexts = new ArrayList<CareContext>();
    }
    this.careContexts.add(careContextsItem);
    return this;
  }

  /**
   * Get careContexts
   * @return careContexts
  **/
  @ApiModelProperty(value = "")
      @Valid
    public List<CareContext> getCareContexts() {
    return careContexts;
  }

  public void setCareContexts(List<CareContext> careContexts) {
    this.careContexts = careContexts;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    PatientLinkReferenceRequestPatient patientLinkReferenceRequestPatient = (PatientLinkReferenceRequestPatient) o;
    return Objects.equals(this.id, patientLinkReferenceRequestPatient.id) &&
        Objects.equals(this.referenceNumber, patientLinkReferenceRequestPatient.referenceNumber) &&
        Objects.equals(this.careContexts, patientLinkReferenceRequestPatient.careContexts);
  }

  @Override
  public int hashCode() {
    return Objects.hash(id, referenceNumber, careContexts);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class PatientLinkReferenceRequestPatient {\n");
    
    sb.append("    id: ").append(toIndentedString(id)).append("\n");
    sb.append("    referenceNumber: ").append(toIndentedString(referenceNumber)).append("\n");
    sb.append("    careContexts: ").append(toIndentedString(careContexts)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
