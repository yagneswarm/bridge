package org.nha.emr.web.hip.model;

import java.util.Objects;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;

import org.springframework.validation.annotation.Validated;

import com.fasterxml.jackson.annotation.JsonProperty;

import io.swagger.annotations.ApiModelProperty;

/**
 * HIPHealthInformationRequestHiRequest
 */
@Validated



public class HIPHealthInformationRequestHiRequest   {
  @JsonProperty("consent")
  private Consent consent = null;

  @JsonProperty("dateRange")
  private DateRange dateRange = null;

  @JsonProperty("dataPushUrl")
  private String dataPushUrl = null;

  @JsonProperty("keyMaterial")
  private KeyMaterial keyMaterial = null;

  public HIPHealthInformationRequestHiRequest consent(Consent consent) {
    this.consent = consent;
    return this;
  }

  /**
   * Get consent
   * @return consent
  **/
  @ApiModelProperty(required = true, value = "")
      @NotNull

    @Valid
    public Consent getConsent() {
    return consent;
  }

  public void setConsent(Consent consent) {
    this.consent = consent;
  }

  public HIPHealthInformationRequestHiRequest dateRange(DateRange dateRange) {
    this.dateRange = dateRange;
    return this;
  }

  /**
   * Get dateRange
   * @return dateRange
  **/
  @ApiModelProperty(required = true, value = "")
      @NotNull

    @Valid
    public DateRange getDateRange() {
    return dateRange;
  }

  public void setDateRange(DateRange dateRange) {
    this.dateRange = dateRange;
  }

  public HIPHealthInformationRequestHiRequest dataPushUrl(String dataPushUrl) {
    this.dataPushUrl = dataPushUrl;
    return this;
  }

  /**
   * Get dataPushUrl
   * @return dataPushUrl
  **/
  @ApiModelProperty(required = true, value = "")
      @NotNull

    public String getDataPushUrl() {
    return dataPushUrl;
  }

  public void setDataPushUrl(String dataPushUrl) {
    this.dataPushUrl = dataPushUrl;
  }

  public HIPHealthInformationRequestHiRequest keyMaterial(KeyMaterial keyMaterial) {
    this.keyMaterial = keyMaterial;
    return this;
  }

  /**
   * Get keyMaterial
   * @return keyMaterial
  **/
  @ApiModelProperty(required = true, value = "")
      @NotNull

    @Valid
    public KeyMaterial getKeyMaterial() {
    return keyMaterial;
  }

  public void setKeyMaterial(KeyMaterial keyMaterial) {
    this.keyMaterial = keyMaterial;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    HIPHealthInformationRequestHiRequest hiPHealthInformationRequestHiRequest = (HIPHealthInformationRequestHiRequest) o;
    return Objects.equals(this.consent, hiPHealthInformationRequestHiRequest.consent) &&
        Objects.equals(this.dateRange, hiPHealthInformationRequestHiRequest.dateRange) &&
        Objects.equals(this.dataPushUrl, hiPHealthInformationRequestHiRequest.dataPushUrl) &&
        Objects.equals(this.keyMaterial, hiPHealthInformationRequestHiRequest.keyMaterial);
  }

  @Override
  public int hashCode() {
    return Objects.hash(consent, dateRange, dataPushUrl, keyMaterial);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class HIPHealthInformationRequestHiRequest {\n");
    
    sb.append("    consent: ").append(toIndentedString(consent)).append("\n");
    sb.append("    dateRange: ").append(toIndentedString(dateRange)).append("\n");
    sb.append("    dataPushUrl: ").append(toIndentedString(dataPushUrl)).append("\n");
    sb.append("    keyMaterial: ").append(toIndentedString(keyMaterial)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
