package org.nha.emr.web.hip.model;

import java.util.Objects;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;

import org.springframework.validation.annotation.Validated;

import com.fasterxml.jackson.annotation.JsonProperty;

import io.swagger.annotations.ApiModelProperty;

/**
 * PatientAuthInitResponseAuth
 */
@Validated

public class PatientAuthInitResponseAuth   {
  @JsonProperty("transactionId")
  private String transactionId = null;

  @JsonProperty("mode")
  private AuthenticationMode mode = null;

  @JsonProperty("meta")
  private AuthMeta meta = null;

  public PatientAuthInitResponseAuth transactionId(String transactionId) {
    this.transactionId = transactionId;
    return this;
  }

  /**
   * Get transactionId
   * @return transactionId
  **/
  @ApiModelProperty(required = true, value = "")
      @NotNull

    public String getTransactionId() {
    return transactionId;
  }

  public void setTransactionId(String transactionId) {
    this.transactionId = transactionId;
  }

  public PatientAuthInitResponseAuth mode(AuthenticationMode mode) {
    this.mode = mode;
    return this;
  }

  /**
   * Get mode
   * @return mode
  **/
  @ApiModelProperty(required = true, value = "")
      @NotNull

    @Valid
    public AuthenticationMode getMode() {
    return mode;
  }

  public void setMode(AuthenticationMode mode) {
    this.mode = mode;
  }

  public PatientAuthInitResponseAuth meta(AuthMeta meta) {
    this.meta = meta;
    return this;
  }

  /**
   * Get meta
   * @return meta
  **/
  @ApiModelProperty(value = "")
  
    @Valid
    public AuthMeta getMeta() {
    return meta;
  }

  public void setMeta(AuthMeta meta) {
    this.meta = meta;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    PatientAuthInitResponseAuth patientAuthInitResponseAuth = (PatientAuthInitResponseAuth) o;
    return Objects.equals(this.transactionId, patientAuthInitResponseAuth.transactionId) &&
        Objects.equals(this.mode, patientAuthInitResponseAuth.mode) &&
        Objects.equals(this.meta, patientAuthInitResponseAuth.meta);
  }

  @Override
  public int hashCode() {
    return Objects.hash(transactionId, mode, meta);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class PatientAuthInitResponseAuth {\n");
    
    sb.append("    transactionId: ").append(toIndentedString(transactionId)).append("\n");
    sb.append("    mode: ").append(toIndentedString(mode)).append("\n");
    sb.append("    meta: ").append(toIndentedString(meta)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
