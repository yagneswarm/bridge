package org.nha.emr.web.hip.model;

import java.util.Objects;

import javax.validation.Valid;

import org.springframework.validation.annotation.Validated;

import com.fasterxml.jackson.annotation.JsonProperty;

import io.swagger.annotations.ApiModelProperty;

@Validated
public class ProfileDtls {
	

	
	 @JsonProperty("hipCode")
	  private String hipCode = null;
	  

	  @JsonProperty("patient")
	  private @Valid PatientProfile patient = null;
	  
	  public ProfileDtls hipCode(String hipCode) {
		    this.hipCode = hipCode;
		    return this;
		  }
	  
	  /**
	   * a nonce, unique for each HTTP request.
	   * @return hipCode
	  **/
	  @ApiModelProperty(example = "499a5a4a-7dda-4f20-9b67-e24589627061", value = "a nonce, unique for each HTTP request.")
	   @Valid
	    public String getHipCode() {
	    return hipCode;
	  }

	  public void setHipCode(String hipCode) {
	    this.hipCode = hipCode;
	  }
	  
		 
	  public ProfileDtls patient(PatientProfile patient) {
			    this.patient = patient;
			    return this;
			  }

			  /**
			   * Get patient
			   * @return patient
			  **/
			  @ApiModelProperty(value = "")
			  
			   @Valid
			    public PatientProfile getPatient() {
			    return patient;
			  }

			  public void setPatient(PatientProfile patient) {
			    this.patient = patient;
			  }
			  
			  
			  @Override
			  public boolean equals(java.lang.Object o) {
			    if (this == o) {
			      return true;
			    }
			    if (o == null || getClass() != o.getClass()) {
			      return false;
			    }
			    ProfileDtls profileDtls = (ProfileDtls) o;
			    return Objects.equals(this.hipCode, profileDtls.hipCode) &&
			        Objects.equals(this.patient, profileDtls.patient);
			  }
			  
			  @Override
			  public int hashCode() {
			    return Objects.hash(hipCode, patient);
			  }

			  @Override
			  public String toString() {
			    StringBuilder sb = new StringBuilder();
			    sb.append("class ProfileDtls {\n");
			    
			    sb.append("    hipCode: ").append(toIndentedString(hipCode)).append("\n");
			    sb.append("    patient: ").append(toIndentedString(patient)).append("\n");
			    sb.append("}");
			    return sb.toString();
			  }

			  /**
			   * Convert the given object to string with each line indented by 4 spaces
			   * (except the first line).
			   */
			  private String toIndentedString(java.lang.Object o) {
			    if (o == null) {
			      return "null";
			    }
			    return o.toString().replace("\n", "\n    ");
			  }


}
