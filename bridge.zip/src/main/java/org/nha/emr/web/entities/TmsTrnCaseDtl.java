package org.nha.emr.web.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.sql.Timestamp;


/**
 * The persistent class for the tms_trn_case_dtls database table.
 * 
 */
@Entity
@Table(name="tms_trn_case_dtls")
@NamedQuery(name="TmsTrnCaseDtl.findAll", query="SELECT t FROM TmsTrnCaseDtl t")
public class TmsTrnCaseDtl implements Serializable {
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private TmsTrnCaseDtlPK id;

	private Integer age;

	@Column(name="card_no")
	private String cardNo;

	@Column(name="case_no")
	private String caseNo;

	@Column(name="contact_no")
	private String contactNo;

	@Column(name="crt_dt")
	private Timestamp crtDt;

	@Column(name="cs_adm_dt")
	private Timestamp csAdmDt;

	@Column(name="hosp_disp_code")
	private String hospDispCode;

	@Column(name="hosp_name")
	private String hospName;

	@Column(name="lst_upd_dt")
	private Timestamp lstUpdDt;

	private String name;

	@Column(name="preauth_aprv_dt")
	private Timestamp preauthAprvDt;

	@Column(name="procedure_disp_id")
	private String procedureDispId;

	@Column(name="procedure_name")
	private String procedureName;

	@Column(name="scheme_id")
	private String schemeId;

	@Column(name="surgeon_name")
	private String surgeonName;

	@Column(name="surgeon_regno")
	private String surgeonRegno;

	public TmsTrnCaseDtl() {
	}

	public TmsTrnCaseDtlPK getId() {
		return this.id;
	}

	public void setId(TmsTrnCaseDtlPK id) {
		this.id = id;
	}

	public Integer getAge() {
		return this.age;
	}

	public void setAge(Integer age) {
		this.age = age;
	}

	public String getCardNo() {
		return this.cardNo;
	}

	public void setCardNo(String cardNo) {
		this.cardNo = cardNo;
	}

	public String getCaseNo() {
		return this.caseNo;
	}

	public void setCaseNo(String caseNo) {
		this.caseNo = caseNo;
	}

	public String getContactNo() {
		return this.contactNo;
	}

	public void setContactNo(String contactNo) {
		this.contactNo = contactNo;
	}

	public Timestamp getCrtDt() {
		return this.crtDt;
	}

	public void setCrtDt(Timestamp crtDt) {
		this.crtDt = crtDt;
	}

	public Timestamp getCsAdmDt() {
		return this.csAdmDt;
	}

	public void setCsAdmDt(Timestamp csAdmDt) {
		this.csAdmDt = csAdmDt;
	}

	public String getHospDispCode() {
		return this.hospDispCode;
	}

	public void setHospDispCode(String hospDispCode) {
		this.hospDispCode = hospDispCode;
	}

	public String getHospName() {
		return this.hospName;
	}

	public void setHospName(String hospName) {
		this.hospName = hospName;
	}

	public Timestamp getLstUpdDt() {
		return this.lstUpdDt;
	}

	public void setLstUpdDt(Timestamp lstUpdDt) {
		this.lstUpdDt = lstUpdDt;
	}

	public String getName() {
		return this.name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Timestamp getPreauthAprvDt() {
		return this.preauthAprvDt;
	}

	public void setPreauthAprvDt(Timestamp preauthAprvDt) {
		this.preauthAprvDt = preauthAprvDt;
	}

	public String getProcedureDispId() {
		return this.procedureDispId;
	}

	public void setProcedureDispId(String procedureDispId) {
		this.procedureDispId = procedureDispId;
	}

	public String getProcedureName() {
		return this.procedureName;
	}

	public void setProcedureName(String procedureName) {
		this.procedureName = procedureName;
	}

	public String getSchemeId() {
		return this.schemeId;
	}

	public void setSchemeId(String schemeId) {
		this.schemeId = schemeId;
	}

	public String getSurgeonName() {
		return this.surgeonName;
	}

	public void setSurgeonName(String surgeonName) {
		this.surgeonName = surgeonName;
	}

	public String getSurgeonRegno() {
		return this.surgeonRegno;
	}

	public void setSurgeonRegno(String surgeonRegno) {
		this.surgeonRegno = surgeonRegno;
	}

}