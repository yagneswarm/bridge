package org.nha.emr.web.hip.model;

import java.util.Objects;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;

import org.springframework.validation.annotation.Validated;

import com.fasterxml.jackson.annotation.JsonProperty;


/**
 * PatientIdentificationRequestQuery
 */
@Validated

public class PatientIdentificationRequestQuery   {
  @JsonProperty("patient")
  private PatientIdentificationRequestQueryPatient patient = null;

  @JsonProperty("requester")
  private PatientIdentificationRequestQueryRequester requester = null;

  public PatientIdentificationRequestQuery patient(PatientIdentificationRequestQueryPatient patient) {
    this.patient = patient;
    return this;
  }

  /**
   * Get patient
   * @return patient
  **/
      @NotNull

    @Valid
    public PatientIdentificationRequestQueryPatient getPatient() {
    return patient;
  }

  public void setPatient(PatientIdentificationRequestQueryPatient patient) {
    this.patient = patient;
  }

  public PatientIdentificationRequestQuery requester(PatientIdentificationRequestQueryRequester requester) {
    this.requester = requester;
    return this;
  }

  /**
   * Get requester
   * @return requester
  **/
      @NotNull

    @Valid
    public PatientIdentificationRequestQueryRequester getRequester() {
    return requester;
  }

  public void setRequester(PatientIdentificationRequestQueryRequester requester) {
    this.requester = requester;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    PatientIdentificationRequestQuery patientIdentificationRequestQuery = (PatientIdentificationRequestQuery) o;
    return Objects.equals(this.patient, patientIdentificationRequestQuery.patient) &&
        Objects.equals(this.requester, patientIdentificationRequestQuery.requester);
  }

  @Override
  public int hashCode() {
    return Objects.hash(patient, requester);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class PatientIdentificationRequestQuery {\n");
    
    sb.append("    patient: ").append(toIndentedString(patient)).append("\n");
    sb.append("    requester: ").append(toIndentedString(requester)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
