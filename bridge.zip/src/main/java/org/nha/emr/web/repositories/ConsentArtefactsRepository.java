package org.nha.emr.web.repositories;

import org.nha.emr.web.entities.ConsentArtefacts;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;

@Repository
@Component
public interface ConsentArtefactsRepository extends JpaRepository<ConsentArtefacts, String> {
	
}
