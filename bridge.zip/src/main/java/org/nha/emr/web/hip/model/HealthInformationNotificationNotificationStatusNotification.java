package org.nha.emr.web.hip.model;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import javax.validation.Valid;

import org.springframework.validation.annotation.Validated;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonValue;

import io.swagger.annotations.ApiModelProperty;

/**
 * HealthInformationNotificationNotificationStatusNotification
 */
@Validated



public class HealthInformationNotificationNotificationStatusNotification   {
  /**
   * Gets or Sets sessionStatus
   */
  public enum SessionStatusEnum {
    TRANSFERRED("TRANSFERRED"),
    
    FAILED("FAILED");

    private String value;

    SessionStatusEnum(String value) {
      this.value = value;
    }

    @Override
    @JsonValue
    public String toString() {
      return String.valueOf(value);
    }

    @JsonCreator
    public static SessionStatusEnum fromValue(String text) {
      for (SessionStatusEnum b : SessionStatusEnum.values()) {
        if (String.valueOf(b.value).equals(text)) {
          return b;
        }
      }
      return null;
    }
  }
  @JsonProperty("sessionStatus")
  private SessionStatusEnum sessionStatus = null;

  @JsonProperty("hipId")
  private String hipId = null;

  @JsonProperty("statusResponses")
  @Valid
  private List<HealthInformationNotificationNotificationStatusNotificationStatusResponses> statusResponses = null;

  public HealthInformationNotificationNotificationStatusNotification sessionStatus(SessionStatusEnum sessionStatus) {
    this.sessionStatus = sessionStatus;
    return this;
  }

  /**
   * Get sessionStatus
   * @return sessionStatus
  **/
  @ApiModelProperty(value = "")
  
    public SessionStatusEnum getSessionStatus() {
    return sessionStatus;
  }

  public void setSessionStatus(SessionStatusEnum sessionStatus) {
    this.sessionStatus = sessionStatus;
  }

  public HealthInformationNotificationNotificationStatusNotification hipId(String hipId) {
    this.hipId = hipId;
    return this;
  }

  /**
   * Get hipId
   * @return hipId
  **/
  @ApiModelProperty(example = "max", value = "")
  
    public String getHipId() {
    return hipId;
  }

  public void setHipId(String hipId) {
    this.hipId = hipId;
  }

  public HealthInformationNotificationNotificationStatusNotification statusResponses(List<HealthInformationNotificationNotificationStatusNotificationStatusResponses> statusResponses) {
    this.statusResponses = statusResponses;
    return this;
  }

  public HealthInformationNotificationNotificationStatusNotification addStatusResponsesItem(HealthInformationNotificationNotificationStatusNotificationStatusResponses statusResponsesItem) {
    if (this.statusResponses == null) {
      this.statusResponses = new ArrayList<HealthInformationNotificationNotificationStatusNotificationStatusResponses>();
    }
    this.statusResponses.add(statusResponsesItem);
    return this;
  }

  /**
   * Get statusResponses
   * @return statusResponses
  **/
  @ApiModelProperty(value = "")
      @Valid
    public List<HealthInformationNotificationNotificationStatusNotificationStatusResponses> getStatusResponses() {
    return statusResponses;
  }

  public void setStatusResponses(List<HealthInformationNotificationNotificationStatusNotificationStatusResponses> statusResponses) {
    this.statusResponses = statusResponses;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    HealthInformationNotificationNotificationStatusNotification healthInformationNotificationNotificationStatusNotification = (HealthInformationNotificationNotificationStatusNotification) o;
    return Objects.equals(this.sessionStatus, healthInformationNotificationNotificationStatusNotification.sessionStatus) &&
        Objects.equals(this.hipId, healthInformationNotificationNotificationStatusNotification.hipId) &&
        Objects.equals(this.statusResponses, healthInformationNotificationNotificationStatusNotification.statusResponses);
  }

  @Override
  public int hashCode() {
    return Objects.hash(sessionStatus, hipId, statusResponses);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class HealthInformationNotificationNotificationStatusNotification {\n");
    
    sb.append("    sessionStatus: ").append(toIndentedString(sessionStatus)).append("\n");
    sb.append("    hipId: ").append(toIndentedString(hipId)).append("\n");
    sb.append("    statusResponses: ").append(toIndentedString(statusResponses)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
