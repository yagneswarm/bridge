package org.nha.emr.web.hip.model;

import java.util.Objects;
import java.util.UUID;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;

import org.springframework.validation.annotation.Validated;

import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * ConsentArtefact
 */
@Validated
public class ConsentArtefact   {
  @JsonProperty("status")
  private ConsentStatus status = null;

  @JsonProperty("consentId")
  private UUID consentId = null;

  @JsonProperty("consentDetail")
  private ConsentArtefactConsentDetail consentDetail = null;

  public ConsentArtefact status(ConsentStatus status) {
    this.status = status;
    return this;
  }

  /**
   * Get status
   * @return status
  **/
      @NotNull

    @Valid
    public ConsentStatus getStatus() {
    return status;
  }

  public void setStatus(ConsentStatus status) {
    this.status = status;
  }

  public ConsentArtefact consentId(UUID consentId) {
    this.consentId = consentId;
    return this;
  }

  /**
   * Get consentId
   * @return consentId
  **/
      @NotNull

    @Valid
    public UUID getConsentId() {
    return consentId;
  }

  public void setConsentId(UUID consentId) {
    this.consentId = consentId;
  }

  public ConsentArtefact consentDetail(ConsentArtefactConsentDetail consentDetail) {
    this.consentDetail = consentDetail;
    return this;
  }

  /**
   * Get consentDetail
   * @return consentDetail
  **/
  
    @Valid
    public ConsentArtefactConsentDetail getConsentDetail() {
    return consentDetail;
  }

  public void setConsentDetail(ConsentArtefactConsentDetail consentDetail) {
    this.consentDetail = consentDetail;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    ConsentArtefact consentArtefact = (ConsentArtefact) o;
    return Objects.equals(this.status, consentArtefact.status) &&
        Objects.equals(this.consentId, consentArtefact.consentId) &&
        Objects.equals(this.consentDetail, consentArtefact.consentDetail);
  }

  @Override
  public int hashCode() {
    return Objects.hash(status, consentId, consentDetail);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ConsentArtefact {\n");
    
    sb.append("    status: ").append(toIndentedString(status)).append("\n");
    sb.append("    consentId: ").append(toIndentedString(consentId)).append("\n");
    sb.append("    consentDetail: ").append(toIndentedString(consentDetail)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
