package org.nha.emr.web.hip.model;

import java.util.Objects;
import java.util.UUID;

import javax.validation.Valid;

import com.fasterxml.jackson.annotation.JsonProperty;

import io.swagger.annotations.ApiModelProperty;

public class PatientShareResult {

	@JsonProperty("requestId")
	  private UUID requestId = null;

	  @JsonProperty("timestamp")
	  private String timestamp = null;


	  @JsonProperty("acknowledgement")
	  private ShareAcknowledgement acknowledgement = null;

	  @JsonProperty("error")
	  private Error error = null;

	  @JsonProperty("resp")
	  private RequestReference resp = null;
	  

	  public PatientShareResult requestId(UUID requestId) {
	    this.requestId = requestId;
	    return this;
	  }

	  /**
	   * a nonce, unique for each HTTP request
	   * @return requestId
	  **/
	  @ApiModelProperty(example = "5f7a535d-a3fd-416b-b069-c97d021fbacd", value = "a nonce, unique for each HTTP request")
	  
	    @Valid
	    public UUID getRequestId() {
	    return requestId;
	  }

	  public void setRequestId(UUID requestId) {
	    this.requestId = requestId;
	  }

	  public PatientShareResult timestamp(String timestamp) {
	    this.timestamp = timestamp;
	    return this;
	  }

	  /**
	   * Get timestamp
	   * @return timestamp
	  **/
	  @ApiModelProperty(value = "")
	  
	    @Valid
	    public String getTimestamp() {
	    return timestamp;
	  }

	  public void setTimestamp(String timestamp) {
	    this.timestamp = timestamp;
	  }
	  
	  
	  
	  public PatientShareResult acknowledgement(ShareAcknowledgement acknowledgement) {
		    this.acknowledgement = acknowledgement;
		    return this;
		  }
	  
	  /**
	   * Get acknowledgement
	   * @return acknowledgement
	  **/
	  @ApiModelProperty(value = "")
	  
	    @Valid
	    public ShareAcknowledgement getAcknowledgement() {
	    return acknowledgement;
	  }

	  public void setAcknowledgement(ShareAcknowledgement acknowledgement) {
	    this.acknowledgement = acknowledgement;
	  }

	 
	  public PatientShareResult error(Error error) {
		    this.error = error;
		    return this;
		  }

		  /**
		   * Get error
		   * @return error
		  **/
		  @ApiModelProperty(value = "")
		  
		    @Valid
		    public Error getError() {
		    return error;
		  }

		  public void setError(Error error) {
		    this.error = error;
		  }

		  public PatientShareResult resp(RequestReference resp) {
		    this.resp = resp;
		    return this;
		  }

		  /**
		   * Get resp
		   * @return resp
		  **/
		  @ApiModelProperty(value = "")
		  
		    @Valid
		    public RequestReference getResp() {
		    return resp;
		  }

		  public void setResp(RequestReference resp) {
		    this.resp = resp;
		  }

		  @Override
		  public boolean equals(java.lang.Object o) {
		    if (this == o) {
		      return true;
		    }
		    if (o == null || getClass() != o.getClass()) {
		      return false;
		    }
		    PatientShareResult patientShareResult = (PatientShareResult) o;
		    return Objects.equals(this.requestId, patientShareResult.requestId) &&
		        Objects.equals(this.timestamp, patientShareResult.timestamp) &&
		        Objects.equals(this.acknowledgement, patientShareResult.acknowledgement) &&
		        Objects.equals(this.error, patientShareResult.error) &&
		        Objects.equals(this.resp, patientShareResult.resp);
		  }

		  @Override
		  public int hashCode() {
		    return Objects.hash(requestId, timestamp, acknowledgement, error, resp);
		  }
		  
		  @Override
		  public String toString() {
		    StringBuilder sb = new StringBuilder();
		    sb.append("class PatientShareResult {\n");
		    
		    sb.append("    requestId: ").append(toIndentedString(requestId)).append("\n");
		    sb.append("    timestamp: ").append(toIndentedString(timestamp)).append("\n");
		    sb.append("    acknowledgement: ").append(toIndentedString(acknowledgement)).append("\n");
		    sb.append("    error: ").append(toIndentedString(error)).append("\n");
		    sb.append("    resp: ").append(toIndentedString(resp)).append("\n");
		    sb.append("}");
		    return sb.toString();
		  }

		  /**
		   * Convert the given object to string with each line indented by 4 spaces
		   * (except the first line).
		   */
		  private String toIndentedString(java.lang.Object o) {
		    if (o == null) {
		      return "null";
		    }
		    return o.toString().replace("\n", "\n    ");
		  }

		
		  

}
