package org.nha.emr.web.repositories;

import java.util.Date;
import java.util.List;

import org.nha.emr.web.entities.PatientVisitDetails;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface PatientVisitRepository extends JpaRepository<PatientVisitDetails, Long> {

	@Query("select a from PatientVisitDetails a where facilityCd=:facilityCd and TO_CHAR(a.visitDt,'dd/MM/yyyy') =:visitDt")
	List<PatientVisitDetails> findAllWithCreationDate(
		      @Param("visitDt") String visitDt,@Param("facilityCd") String facilityCd);
	
	@Query(value="select pv.* from patient p, patient_visit_dtls pv where p.patient_id=pv.patient_id and pv.facility_cd=?3 and p.first_name like ?1 or p.last_name like ?2",nativeQuery = true )
	List<PatientVisitDetails> findAllWithName(String firstName,String lastName,String facilityCd);
	
	@Query(value="select pv.* from patient p, patient_visit_dtls pv where p.patient_id=pv.patient_id and p.first_name like ?1 or p.last_name like ?2",nativeQuery = true )
	List<PatientVisitDetails> findAllWithName(String firstName,String lastName);
	
	@Query(value="select * from patient_visit_dtls pv where pv.visit_id=?1",nativeQuery = true )
	PatientVisitDetails findWithVisitId(Long visitId);
	
	@Query(value="select * from patient_visit_dtls pv where pv.visit_id in ?1  ",nativeQuery = true )
	List<PatientVisitDetails> findWithVisitIds(String visitIds);
	

	@Query(value="select * from patient_visit_dtls pv where pv.visit_id in ?1 and pv.updated_at between ?2 and ?3 ",nativeQuery = true )
	List<PatientVisitDetails> findWithVisitIdsDtRange(List<Long> ids,Date frmDt,Date toDt);
	
	
	@Query(value="select pv.* from patient p, patient_visit_dtls pv where p.patient_id=pv.patient_id and pv.facility_cd=?2 and p.patient_id=?1",nativeQuery = true )
	List<PatientVisitDetails> findAllWithPatientId(Long patId,String facilityCd);
	
	@Query(value="select pv.* from patient p, patient_visit_dtls pv where p.patient_id=pv.patient_id and p.swasthya_id=?1 and p.contact_number=?2 and pv.facility_cd=?3  order by updated_at desc ",nativeQuery = true )
	List<PatientVisitDetails> findAllWithPatientId(String patId,String mobileNo,String hospId);
	
	@Query(value="select pv.* from patient p, patient_visit_dtls pv where p.patient_id=pv.patient_id and p.swasthya_id=?1 and and pv.facility_cd=?2 order by updated_at desc LIMIT 1",nativeQuery = true )
	List<PatientVisitDetails> findAllWithPatientId(String patId,String hospId);
	
	
	
		
}
