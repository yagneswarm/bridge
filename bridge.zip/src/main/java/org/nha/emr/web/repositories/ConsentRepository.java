package org.nha.emr.web.repositories;

import java.util.List;

import org.nha.emr.web.entities.ConsentRequest;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;

@Repository
@Component
public interface ConsentRepository extends JpaRepository<ConsentRequest, String> {
	
	@Query("select a from ConsentRequest a where TO_CHAR(a.createdAt,'dd/MM/yyyy') =:createdAt")
	List<ConsentRequest> findAllWithCreationDate(
		      @Param("createdAt") String createdAt);

	@Query("select a from ConsentRequest a where a.givenName like ?1")
	List<ConsentRequest> findAllWithName(
		      String givenName);
	
	@Query("select a from ConsentRequest a where a.consentRequestId = ?1 or a.consentId =?1")
	List<ConsentRequest>  findByConsentId(String consentRequestId);

	@Query("select a from ConsentRequest a where a.swasthyaId = ?1")
	ConsentRequest findBypatientHealthId(String swasthyaId);
	
	
	//select TO_CHAR(MYDATE,'YYYY-MM-DD')from Event e
}
