package org.nha.emr.web.hip.model;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;

import org.springframework.validation.annotation.Validated;

import com.fasterxml.jackson.annotation.JsonProperty;

import io.swagger.annotations.ApiModelProperty;

/**
 * PatientDemographicResponse
 */
@Validated

public class PatientDemographicResponse   {
  @JsonProperty("id")
  private String id = null;

  @JsonProperty("name")
  private String name = null;

  @JsonProperty("gender")
  private PatientGender gender = null;

  @JsonProperty("yearOfBirth")
  private Integer yearOfBirth = null;

  @JsonProperty("address")
  private PatientAddress address = null;

  @JsonProperty("identifiers")
  @Valid
  private List<Identifier> identifiers = null;

  public PatientDemographicResponse id(String id) {
    this.id = id;
    return this;
  }

  /**
   * PHR Identifier of patient at consent manager
   * @return id
  **/
  @ApiModelProperty(example = "<patient-id>@<consent-manager-id>", required = true, value = "PHR Identifier of patient at consent manager")
      @NotNull

    public String getId() {
    return id;
  }

  public void setId(String id) {
    this.id = id;
  }

  public PatientDemographicResponse name(String name) {
    this.name = name;
    return this;
  }

  /**
   * Get name
   * @return name
  **/
  @ApiModelProperty(example = "Hina Patel", required = true, value = "")
      @NotNull

    public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }

  public PatientDemographicResponse gender(PatientGender gender) {
    this.gender = gender;
    return this;
  }

  /**
   * Get gender
   * @return gender
  **/
  @ApiModelProperty(required = true, value = "")
      @NotNull

    @Valid
    public PatientGender getGender() {
    return gender;
  }

  public void setGender(PatientGender gender) {
    this.gender = gender;
  }

  public PatientDemographicResponse yearOfBirth(Integer yearOfBirth) {
    this.yearOfBirth = yearOfBirth;
    return this;
  }

  /**
   * Get yearOfBirth
   * @return yearOfBirth
  **/
  @ApiModelProperty(example = "2000", required = true, value = "")
      @NotNull

    public Integer getYearOfBirth() {
    return yearOfBirth;
  }

  public void setYearOfBirth(Integer yearOfBirth) {
    this.yearOfBirth = yearOfBirth;
  }

  public PatientDemographicResponse address(PatientAddress address) {
    this.address = address;
    return this;
  }

  /**
   * Get address
   * @return address
  **/
  @ApiModelProperty(value = "")
  
    @Valid
    public PatientAddress getAddress() {
    return address;
  }

  public void setAddress(PatientAddress address) {
    this.address = address;
  }

  public PatientDemographicResponse identifiers(List<Identifier> identifiers) {
    this.identifiers = identifiers;
    return this;
  }

  public PatientDemographicResponse addIdentifiersItem(Identifier identifiersItem) {
    if (this.identifiers == null) {
      this.identifiers = new ArrayList<Identifier>();
    }
    this.identifiers.add(identifiersItem);
    return this;
  }

  /**
   * Get identifiers
   * @return identifiers
  **/
  @ApiModelProperty(value = "")
      @Valid
    public List<Identifier> getIdentifiers() {
    return identifiers;
  }

  public void setIdentifiers(List<Identifier> identifiers) {
    this.identifiers = identifiers;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    PatientDemographicResponse patientDemographicResponse = (PatientDemographicResponse) o;
    return Objects.equals(this.id, patientDemographicResponse.id) &&
        Objects.equals(this.name, patientDemographicResponse.name) &&
        Objects.equals(this.gender, patientDemographicResponse.gender) &&
        Objects.equals(this.yearOfBirth, patientDemographicResponse.yearOfBirth) &&
        Objects.equals(this.address, patientDemographicResponse.address) &&
        Objects.equals(this.identifiers, patientDemographicResponse.identifiers);
  }

  @Override
  public int hashCode() {
    return Objects.hash(id, name, gender, yearOfBirth, address, identifiers);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class PatientDemographicResponse {\n");
    
    sb.append("    id: ").append(toIndentedString(id)).append("\n");
    sb.append("    name: ").append(toIndentedString(name)).append("\n");
    sb.append("    gender: ").append(toIndentedString(gender)).append("\n");
    sb.append("    yearOfBirth: ").append(toIndentedString(yearOfBirth)).append("\n");
    sb.append("    address: ").append(toIndentedString(address)).append("\n");
    sb.append("    identifiers: ").append(toIndentedString(identifiers)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
