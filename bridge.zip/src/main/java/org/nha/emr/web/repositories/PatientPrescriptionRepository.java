package org.nha.emr.web.repositories;

import java.util.Date;
import java.util.List;

import org.nha.emr.web.entities.PatientPrescriptionDetails;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

@Repository
public interface PatientPrescriptionRepository extends JpaRepository<PatientPrescriptionDetails, Long> {
   // List<PatientPrescriptionDetails> findByVisitId(Long visitId);
	@Query(value="select * from patient_prescription_dtls pp where pp.visit_id=?",nativeQuery = true )
	List<PatientPrescriptionDetails> findWithVisitId(Long visitId);
	
	//select * from patient_prescription_dtls pp where pp.visit_id=13352 and updated_at >= '2020-11-30'::date and updated_at < ('2020-12-01'::date + '1 day'::interval);
	
	@Query(value="select * from patient_prescription_dtls pp where pp.visit_id=?1 and updated_at between ?2 and ?3 ",nativeQuery = true )
	List<PatientPrescriptionDetails> findWithVisitIdDateRange(Long visitId,Date fromDt,Date toDt);
	
}
