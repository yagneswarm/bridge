package org.nha.emr.web.hip.model;

import java.util.Objects;
import java.util.UUID;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;

import org.springframework.validation.annotation.Validated;

import com.fasterxml.jackson.annotation.JsonProperty;

import io.swagger.annotations.ApiModelProperty;

/**
 * HIPConsentNotification
 */
@Validated



public class HIPConsentNotification   {
  @JsonProperty("requestId")
  private UUID requestId = null;

  @JsonProperty("timestamp")
  private String timestamp = null;

  @JsonProperty("notification")
  private HIPConsentNotificationNotification notification = null;

  public HIPConsentNotification requestId(UUID requestId) {
    this.requestId = requestId;
    return this;
  }

  /**
   * a nonce, unique for each HTTP request
   * @return requestId
  **/
  @ApiModelProperty(example = "5f7a535d-a3fd-416b-b069-c97d021fbacd", value = "a nonce, unique for each HTTP request")
  
    @Valid
    public UUID getRequestId() {
    return requestId;
  }

  public void setRequestId(UUID requestId) {
    this.requestId = requestId;
  }

  public HIPConsentNotification timestamp(String timestamp) {
    this.timestamp = timestamp;
    return this;
  }

  /**
   * Get timestamp
   * @return timestamp
  **/
  @ApiModelProperty(value = "")
  
    @Valid
    public String getTimestamp() {
    return timestamp;
  }

  public void setTimestamp(String timestamp) {
    this.timestamp = timestamp;
  }

  public HIPConsentNotification notification(HIPConsentNotificationNotification notification) {
    this.notification = notification;
    return this;
  }

  /**
   * Get notification
   * @return notification
  **/
  @ApiModelProperty(required = true, value = "")
      @NotNull

    @Valid
    public HIPConsentNotificationNotification getNotification() {
    return notification;
  }

  public void setNotification(HIPConsentNotificationNotification notification) {
    this.notification = notification;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    HIPConsentNotification hiPConsentNotification = (HIPConsentNotification) o;
    return Objects.equals(this.requestId, hiPConsentNotification.requestId) &&
        Objects.equals(this.timestamp, hiPConsentNotification.timestamp) &&
        Objects.equals(this.notification, hiPConsentNotification.notification);
  }

  @Override
  public int hashCode() {
    return Objects.hash(requestId, timestamp, notification);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class HIPConsentNotification {\n");
    
    sb.append("    requestId: ").append(toIndentedString(requestId)).append("\n");
    sb.append("    timestamp: ").append(toIndentedString(timestamp)).append("\n");
    sb.append("    notification: ").append(toIndentedString(notification)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
