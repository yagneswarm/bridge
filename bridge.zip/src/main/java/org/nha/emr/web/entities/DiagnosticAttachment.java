package org.nha.emr.web.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import org.hibernate.annotations.OnDelete;
import org.hibernate.annotations.OnDeleteAction;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name = "diagnostic_report_attachments")
public class DiagnosticAttachment extends AuditModel {

	public Long getId() {
		return id;
	}

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(generator = "patient_diagnostic_attachment_generator")
	@SequenceGenerator(name = "patient_diagnostic_attachment_generator", sequenceName = "patient_diagnostic_attachment_sequence", initialValue = 1)
	private Long id;

	@ManyToOne(fetch = FetchType.LAZY, optional = false)
	@JoinColumn(name = "visit_id", nullable = false)
	@OnDelete(action = OnDeleteAction.CASCADE)
	@JsonIgnore
	private PatientDiagnosticReportDetails disgnosticReportDetails;
	
	@Column(name = "report_file_path", nullable = true)
    private String reportFilePath;

	public PatientDiagnosticReportDetails getDisgnosticReportDetails() {
		return disgnosticReportDetails;
	}

	public void setDisgnosticReportDetails(PatientDiagnosticReportDetails disgnosticReportDetails) {
		this.disgnosticReportDetails = disgnosticReportDetails;
	}

	public String getReportFilePath() {
		return reportFilePath;
	}

	public void setReportFilePath(String reportFilePath) {
		this.reportFilePath = reportFilePath;
	}

	public void setId(Long id) {
		this.id = id;
	}
	
	
	
	
}
