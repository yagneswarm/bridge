package org.nha.emr.web.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "hip_init_request")
public class HipInitRequest extends AuditModel{

	private static final long serialVersionUID = 1L;
	
	@Id
    private String requestId;
	
	@Column(name = "request_timestamp")
	private String requestTimestanmp;
	
	@Column(name = "healh_id")
	private String healthId;
	
	@Column(name = "auth_type")
	private String authType;
	
	@Column(name = "transaction_id",nullable = true)
	private String transactionId;
	
	@Column(name = "dob",nullable = true)
	private String dob;
	
	@Column(name = "name",nullable = true)
	private String name;
	
	@Column(name = "gender",nullable = true)
	private String gender;
	
	@Column(name = "reference_init",nullable = true)
	private String referenceInit;
	
	@Column(name = "reference_confirm",nullable = true)
	private String referenceConfirm;
	
	@Column(name = "authoriszation",nullable = true)
	private String authoriszation;
	
	@Column(name = "hosp_reg_id",nullable = true)
	private String hospRegId;
	
	
	public HipInitRequest() {
		// TODO Auto-generated constructor stub
	}


	public String getRequestId() {
		return requestId;
	}


	public void setRequestId(String requestId) {
		this.requestId = requestId;
	}


	public String getRequestTimestanmp() {
		return requestTimestanmp;
	}


	public void setRequestTimestanmp(String requestTimestanmp) {
		this.requestTimestanmp = requestTimestanmp;
	}


	public String getHealthId() {
		return healthId;
	}


	public void setHealthId(String healthId) {
		this.healthId = healthId;
	}


	public String getAuthType() {
		return authType;
	}


	public void setAuthType(String authType) {
		this.authType = authType;
	}


	public String getTransactionId() {
		return transactionId;
	}


	public void setTransactionId(String transactionId) {
		this.transactionId = transactionId;
	}


	public String getDob() {
		return dob;
	}


	public void setDob(String dob) {
		this.dob = dob;
	}


	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	public String getGender() {
		return gender;
	}


	public void setGender(String gender) {
		this.gender = gender;
	}


	public String getReferenceInit() {
		return referenceInit;
	}


	public void setReferenceInit(String referenceInit) {
		this.referenceInit = referenceInit;
	}


	public String getReferenceConfirm() {
		return referenceConfirm;
	}


	public void setReferenceConfirm(String referenceConfirm) {
		this.referenceConfirm = referenceConfirm;
	}


	public String getAuthoriszation() {
		return authoriszation;
	}


	public void setAuthoriszation(String authoriszation) {
		this.authoriszation = authoriszation;
	}


	public String getHospRegId() {
		return hospRegId;
	}


	public void setHospRegId(String hospRegId) {
		this.hospRegId = hospRegId;
	}


	
	
}
