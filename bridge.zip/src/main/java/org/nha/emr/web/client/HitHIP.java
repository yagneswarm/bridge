package org.nha.emr.web.client;

import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.util.UUID;

import org.nha.emr.web.client.api.GatewayApi;
import org.nha.emr.web.hip.model.PatientAuthInitRequest;
import org.nha.emr.web.hip.model.PatientAuthModeQueryRequest;
import org.nha.emr.web.hip.model.PatientAuthModeQueryRequestQuery;
import org.nha.emr.web.hip.model.PatientAuthModeQueryRequestQueryRequester;
import org.nha.emr.web.hip.model.PatientAuthModeQueryRequestQueryRequester.TypeEnum;
import org.nha.emr.web.hip.model.PatientAuthPurpose;
import org.nha.emr.web.hip.model.SessionRequest;
import org.nha.emr.web.hip.model.SessionResponse;

public class HitHIP {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		GatewayApi gatewayApi = new GatewayApi();
		SessionRequest sessReq = new SessionRequest();

		try {
			sessReq.clientId(AuthKeys.X_CLIENT_ID);
			sessReq.clientSecret(AuthKeys.AUTHORIZATION_TOKEN);
			SessionResponse sessResp = gatewayApi.v05SessionsPost(sessReq);
			String accessToken = sessResp.getAccessToken();
			System.out.println("AccessToken " + accessToken);
			accessToken = "bearer " + accessToken;
			PatientAuthInitRequest initRequest = new PatientAuthInitRequest();
			initRequest.setRequestId(UUID.randomUUID());
			LocalDateTime ldt = LocalDateTime.now(ZoneOffset.UTC);
			initRequest.setTimestamp(ldt + "");
			System.out.println("Local date and time::" + ldt);

			PatientAuthModeQueryRequest request = new PatientAuthModeQueryRequest();
			request.setRequestId(UUID.randomUUID());
			request.setTimestamp(ldt + "");
			PatientAuthModeQueryRequestQuery query = new PatientAuthModeQueryRequestQuery();
			query.setId("yagnesh1@sbx");
			query.setPurpose(PatientAuthPurpose.LINK);
			PatientAuthModeQueryRequestQueryRequester requester = new PatientAuthModeQueryRequestQueryRequester();
			requester.setId(AuthKeys.X_HIP_ID);
			requester.setType(TypeEnum.HIP);
			query.setRequester(requester);
			request.setQuery(query);
			gatewayApi.v05UsersAuthFetchModesPost(request, accessToken, AuthKeys.X_CM_ID);

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

}
