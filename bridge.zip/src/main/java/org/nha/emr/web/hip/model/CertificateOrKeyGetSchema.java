package org.nha.emr.web.hip.model;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import javax.validation.Valid;

import org.springframework.validation.annotation.Validated;

import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * CertificateOrKeyGetSchema
 */
@Validated



public class CertificateOrKeyGetSchema   {
  @JsonProperty("e")
  private String e = null;

  @JsonProperty("kid")
  private String kid = null;

  @JsonProperty("kty")
  private String kty = null;

  @JsonProperty("n")
  private String n = null;

  @JsonProperty("use")
  private String use = null;

  @JsonProperty("x5c")
  @Valid
  private List<String> x5c = null;

  @JsonProperty("x5t")
  private String x5t = null;

  @JsonProperty("x5t#S256")
  private String x5tS256 = null;

  @JsonProperty("alg")
  private String alg = null;

  public CertificateOrKeyGetSchema e(String e) {
    this.e = e;
    return this;
  }

  /**
   * Get e
   * @return e
  **/
  
    public String getE() {
    return e;
  }

  public void setE(String e) {
    this.e = e;
  }

  public CertificateOrKeyGetSchema kid(String kid) {
    this.kid = kid;
    return this;
  }

  /**
   * Get kid
   * @return kid
  **/
  
    public String getKid() {
    return kid;
  }

  public void setKid(String kid) {
    this.kid = kid;
  }

  public CertificateOrKeyGetSchema kty(String kty) {
    this.kty = kty;
    return this;
  }

  /**
   * Get kty
   * @return kty
  **/
  
    public String getKty() {
    return kty;
  }

  public void setKty(String kty) {
    this.kty = kty;
  }

  public CertificateOrKeyGetSchema n(String n) {
    this.n = n;
    return this;
  }

  /**
   * Get n
   * @return n
  **/
  
    public String getN() {
    return n;
  }

  public void setN(String n) {
    this.n = n;
  }

  public CertificateOrKeyGetSchema use(String use) {
    this.use = use;
    return this;
  }

  /**
   * Get use
   * @return use
  **/
  
    public String getUse() {
    return use;
  }

  public void setUse(String use) {
    this.use = use;
  }

  public CertificateOrKeyGetSchema x5c(List<String> x5c) {
    this.x5c = x5c;
    return this;
  }

  public CertificateOrKeyGetSchema addX5cItem(String x5cItem) {
    if (this.x5c == null) {
      this.x5c = new ArrayList<String>();
    }
    this.x5c.add(x5cItem);
    return this;
  }

  /**
   * Get x5c
   * @return x5c
  **/
  
    public List<String> getX5c() {
    return x5c;
  }

  public void setX5c(List<String> x5c) {
    this.x5c = x5c;
  }

  public CertificateOrKeyGetSchema x5t(String x5t) {
    this.x5t = x5t;
    return this;
  }

  /**
   * Get x5t
   * @return x5t
  **/
  
    public String getX5t() {
    return x5t;
  }

  public void setX5t(String x5t) {
    this.x5t = x5t;
  }

  public CertificateOrKeyGetSchema x5tS256(String x5tS256) {
    this.x5tS256 = x5tS256;
    return this;
  }

  /**
   * Get x5tS256
   * @return x5tS256
  **/
  
    public String getX5tS256() {
    return x5tS256;
  }

  public void setX5tS256(String x5tS256) {
    this.x5tS256 = x5tS256;
  }

  public CertificateOrKeyGetSchema alg(String alg) {
    this.alg = alg;
    return this;
  }

  /**
   * Get alg
   * @return alg
  **/
  
    public String getAlg() {
    return alg;
  }

  public void setAlg(String alg) {
    this.alg = alg;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    CertificateOrKeyGetSchema certificateOrKeyGetSchema = (CertificateOrKeyGetSchema) o;
    return Objects.equals(this.e, certificateOrKeyGetSchema.e) &&
        Objects.equals(this.kid, certificateOrKeyGetSchema.kid) &&
        Objects.equals(this.kty, certificateOrKeyGetSchema.kty) &&
        Objects.equals(this.n, certificateOrKeyGetSchema.n) &&
        Objects.equals(this.use, certificateOrKeyGetSchema.use) &&
        Objects.equals(this.x5c, certificateOrKeyGetSchema.x5c) &&
        Objects.equals(this.x5t, certificateOrKeyGetSchema.x5t) &&
        Objects.equals(this.x5tS256, certificateOrKeyGetSchema.x5tS256) &&
        Objects.equals(this.alg, certificateOrKeyGetSchema.alg);
  }

  @Override
  public int hashCode() {
    return Objects.hash(e, kid, kty, n, use, x5c, x5t, x5tS256, alg);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class CertificateOrKeyGetSchema {\n");
    
    sb.append("    e: ").append(toIndentedString(e)).append("\n");
    sb.append("    kid: ").append(toIndentedString(kid)).append("\n");
    sb.append("    kty: ").append(toIndentedString(kty)).append("\n");
    sb.append("    n: ").append(toIndentedString(n)).append("\n");
    sb.append("    use: ").append(toIndentedString(use)).append("\n");
    sb.append("    x5c: ").append(toIndentedString(x5c)).append("\n");
    sb.append("    x5t: ").append(toIndentedString(x5t)).append("\n");
    sb.append("    x5tS256: ").append(toIndentedString(x5tS256)).append("\n");
    sb.append("    alg: ").append(toIndentedString(alg)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
