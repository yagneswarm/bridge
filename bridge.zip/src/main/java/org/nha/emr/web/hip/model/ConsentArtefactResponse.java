package org.nha.emr.web.hip.model;

import java.util.Objects;
import java.util.UUID;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;

import org.springframework.validation.annotation.Validated;

import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * ConsentArtefactResponse
 */
@Validated


public class ConsentArtefactResponse   {
  @JsonProperty("requestId")
  private UUID requestId = null;

  @JsonProperty("timestamp")
  private String timestamp = null;

  @JsonProperty("consent")
  private ConsentArtefactResponseConsent consent = null;

  @JsonProperty("error")
  private Error error = null;

  @JsonProperty("resp")
  private RequestReference resp = null;

  public ConsentArtefactResponse requestId(UUID requestId) {
    this.requestId = requestId;
    return this;
  }

  /**
   * a nonce, unique for each HTTP request
   * @return requestId
  **/
      @NotNull

    @Valid
    public UUID getRequestId() {
    return requestId;
  }

  public void setRequestId(UUID requestId) {
    this.requestId = requestId;
  }

  public ConsentArtefactResponse timestamp(String timestamp) {
    this.timestamp = timestamp;
    return this;
  }

  /**
   * Get timestamp
   * @return timestamp
  **/
      @NotNull

    @Valid
    public String getTimestamp() {
    return timestamp;
  }

  public void setTimestamp(String timestamp) {
    this.timestamp = timestamp;
  }

  public ConsentArtefactResponse consent(ConsentArtefactResponseConsent consent) {
    this.consent = consent;
    return this;
  }

  /**
   * Get consent
   * @return consent
  **/
  
    @Valid
    public ConsentArtefactResponseConsent getConsent() {
    return consent;
  }

  public void setConsent(ConsentArtefactResponseConsent consent) {
    this.consent = consent;
  }

  public ConsentArtefactResponse error(Error error) {
    this.error = error;
    return this;
  }

  /**
   * Get error
   * @return error
  **/
  
    @Valid
    public Error getError() {
    return error;
  }

  public void setError(Error error) {
    this.error = error;
  }

  public ConsentArtefactResponse resp(RequestReference resp) {
    this.resp = resp;
    return this;
  }

  /**
   * Get resp
   * @return resp
  **/
      @NotNull

    @Valid
    public RequestReference getResp() {
    return resp;
  }

  public void setResp(RequestReference resp) {
    this.resp = resp;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    ConsentArtefactResponse consentArtefactResponse = (ConsentArtefactResponse) o;
    return Objects.equals(this.requestId, consentArtefactResponse.requestId) &&
        Objects.equals(this.timestamp, consentArtefactResponse.timestamp) &&
        Objects.equals(this.consent, consentArtefactResponse.consent) &&
        Objects.equals(this.error, consentArtefactResponse.error) &&
        Objects.equals(this.resp, consentArtefactResponse.resp);
  }

  @Override
  public int hashCode() {
    return Objects.hash(requestId, timestamp, consent, error, resp);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ConsentArtefactResponse {\n");
    
    sb.append("    requestId: ").append(toIndentedString(requestId)).append("\n");
    sb.append("    timestamp: ").append(toIndentedString(timestamp)).append("\n");
    sb.append("    consent: ").append(toIndentedString(consent)).append("\n");
    sb.append("    error: ").append(toIndentedString(error)).append("\n");
    sb.append("    resp: ").append(toIndentedString(resp)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
