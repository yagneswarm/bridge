package org.nha.emr.web.repositories;

import java.util.List;

import org.nha.emr.web.entities.HipInitRequest;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;

@Repository
@Component
public interface HipInitRepository extends JpaRepository<HipInitRequest, String> {
	
	@Query("select a from HipInitRequest a where a.requestId =?1")
	List<HipInitRequest>  findByReqId(String requestId);
	
	@Query("select a from HipInitRequest a where a.referenceInit =?1")
	List<HipInitRequest>  findByRefInitId(String referenceInit);
	
	
}
