package org.nha.emr.web.service;

import java.time.LocalDate;
import java.util.Date;

import org.hl7.fhir.r4.model.Bundle;
import org.hl7.fhir.r4.model.Bundle.BundleEntryComponent;
import org.nha.emr.web.entities.Patient;
import org.nha.emr.web.entities.PatientClinicalNotesDetails;
import org.nha.emr.web.entities.PatientDiagnosticReportDetails;
import org.nha.emr.web.entities.PatientDischargeDetails;
import org.nha.emr.web.entities.PatientPrescriptionDetails;
import org.nha.emr.web.entities.PatientVisitDetails;
import org.springframework.stereotype.Component;

@Component
public interface FhirService {

	public String createFhirResource(String objType,Object obj,Date fromDt,Date toDt);
	
	BundleEntryComponent getPatientFhirObject(Patient patient);
	BundleEntryComponent getEncounterFhirObject(PatientVisitDetails patientVisitDetails);
	BundleEntryComponent getServiceFhirObject(PatientVisitDetails patientVisitDetails);
	BundleEntryComponent getPractitionerFhirObject(PatientVisitDetails patientVisitDetails);
	BundleEntryComponent getMedicationFhirObject(PatientPrescriptionDetails patientPrescriptionDetails);
	BundleEntryComponent getConditionFhirObject(PatientPrescriptionDetails patientPrescriptionDetails);
	BundleEntryComponent getDiagnosticFhirObject(PatientDiagnosticReportDetails patientDiagnosticReportDetails);
	BundleEntryComponent getOpNotesFhirObject(PatientClinicalNotesDetails clinicalNotesDetails);
	BundleEntryComponent getDischargeSummaryFhirObject(PatientDischargeDetails patientDischargeDetails);
	BundleEntryComponent getOrganisationFhirObject(PatientVisitDetails patientVisitDetails);
	BundleEntryComponent getMediaFhirObject(PatientDiagnosticReportDetails patientDiagnosticReportDetails);
	
	Bundle getMedicationRequest(PatientVisitDetails patientVisitDetails,Date fromDt,Date toDt);
	Bundle getDiagnosticRequest(PatientVisitDetails patientVisitDetails,Date fromDt,Date toDt);
	Bundle getConsulingNoteRequest(PatientVisitDetails patientVisitDetails,Date fromDt,Date toDt);
	Bundle getDischargeRequest(PatientVisitDetails patientVisitDetails,Date fromDt,Date toDt);
	
	
	
}
