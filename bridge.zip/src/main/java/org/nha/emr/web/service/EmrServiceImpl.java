package org.nha.emr.web.service;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.ListIterator;

import org.nha.emr.web.entities.Patient;
import org.nha.emr.web.entities.PatientVisitDetails;
import org.nha.emr.web.repositories.DiagnosticAttachmentRepository;
import org.nha.emr.web.repositories.LocationRepository;
import org.nha.emr.web.repositories.PatientClinicalNotesRepository;
import org.nha.emr.web.repositories.PatientDiagnosticReportRepository;
import org.nha.emr.web.repositories.PatientDischargeRepository;
import org.nha.emr.web.repositories.PatientPrescriptionRepository;
import org.nha.emr.web.repositories.PatientRepository;
import org.nha.emr.web.repositories.PatientVisitRepository;
import org.nha.emr.web.vo.PatientSearchVO;
import org.nha.emr.web.vo.PatientVO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;


@Service
@Component
public class EmrServiceImpl implements EmrService {

	@Autowired
	PatientRepository patientRepository;
	@Autowired
	PatientVisitRepository patientVisitRepository;
	@Autowired
	PatientDiagnosticReportRepository diagnosticRepository;
	@Autowired
	PatientPrescriptionRepository prescriptionRepository;
	@Autowired
	PatientClinicalNotesRepository notesRepository;
	@Autowired
	DiagnosticAttachmentRepository attachmentRepository;
	@Autowired
	PatientDischargeRepository dischargeRepository;
	@Autowired
	LocationRepository locationRepository;

	@Override

	public List<PatientVO> getPatientList(PatientSearchVO patientSearchVO) {
		// TODO Auto-generated method stub

		List<PatientVO> patVoLst = new ArrayList<PatientVO>();
		List<Patient> patList = null;
		List<PatientVisitDetails> patVisitList = null;

		String regDate = patientSearchVO.getRegDate();
		String patName = patientSearchVO.getPatName();
		String facilityCd = patientSearchVO.getFacilityId();
		DateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");

		Date dregDate = Calendar.getInstance().getTime();

		System.out.println("Search Name::"+patName);
		System.out.println("Search Date::"+regDate);
		
		if (regDate != null && !regDate.equalsIgnoreCase("")) {
			try {
				dregDate = dateFormat.parse(regDate);
			} catch (ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

		if (patName != null && !patName.equalsIgnoreCase("")) {
			patVisitList = patientVisitRepository.findAllWithName(patName, patName, facilityCd);
		} else {
			patVisitList = patientVisitRepository.findAllWithCreationDate(regDate, facilityCd);
		}
		ListIterator<PatientVisitDetails> iterator1 = patVisitList.listIterator();
		String fullName = "";

		if (!iterator1.hasNext()) {
			PatientVO patVo = new PatientVO();
			patVo.setName("No Record");
			patVo.setPatId("0");
			patVo.setGender("Not Found");
			patVo.setAge("99");
			patVo.setMobileNo("9999999999");
			patVo.setVisitType("OP");
			patVo.setRegDate(dateFormat.format(dregDate));
			patVoLst.add(patVo);

		}

		while (iterator1.hasNext()) {
			PatientVO patVo = new PatientVO();
			PatientVisitDetails patientVisirtDtls = iterator1.next();

			Patient patient = patientVisirtDtls.getPatient();
			fullName="";
			fullName = patient.getFirstName();
			if(patient.getMiddleName()!=null)
				fullName = fullName+" "+patient.getMiddleName();
			if(patient.getLastName()!=null)
				fullName = fullName+" "+patient.getLastName();
			patVo.setName(fullName);
			patVo.setPatId(patient.getPatientId() + "");
			if(patient.getGender()!=null && patient.getGender().equals("M")) {
			patVo.setGender("Male");
			}else if(patient.getGender()!=null && patient.getGender().equals("F")) {
				patVo.setGender("Female");
			}else
			{
				patVo.setGender("Others");
			}
			
			patVo.setAge(patient.getAge());
			patVo.setMobileNo(patient.getContactNumber());
			patVo.setVisitType(patientVisirtDtls.getVisitType());
			patVo.setVisitId(patientVisirtDtls.getVisitId() + "");
			if (patientVisirtDtls.getVisitDt() != null)
				patVo.setRegDate(dateFormat.format(patientVisirtDtls.getVisitDt()));
			patVoLst.add(patVo);
		}
		return patVoLst;
	}

	@Override
	public PatientVO getPatientDetailsById(PatientSearchVO patientSearchVO) {
		// TODO Auto-generated method stub
		Patient patE = null;
		PatientVisitDetails patientVisitDetailsE = null;

		String fullName = "";
		SimpleDateFormat formatter = new SimpleDateFormat("dd-MMM-yyyy hh:mm:ss");
		String patId = patientSearchVO.getPatId();
		System.out.println(patId);
		if (patId != null)
			patientVisitDetailsE = patientVisitRepository.findWithVisitId(new Long(patId));
		else
			patientVisitDetailsE = patientVisitRepository.findWithVisitId(new Long(patId));

		PatientVO patVo = new PatientVO();
		if (patientVisitDetailsE != null) {
			fullName = patientVisitDetailsE.getPatient().getFirstName();
			if(patientVisitDetailsE.getPatient().getMiddleName()!=null) {
				fullName = fullName+" "+patientVisitDetailsE.getPatient().getMiddleName();
			}
			if(patientVisitDetailsE.getPatient().getLastName()!=null) {
				fullName = fullName+" "+patientVisitDetailsE.getPatient().getLastName();
			}
			patVo.setName(fullName);
			patVo.setPatId(patientVisitDetailsE.getPatient().getPatientId() + "");
			String sGender = patientVisitDetailsE.getPatient().getGender();
			if(sGender!=null && sGender.equalsIgnoreCase("M")) {
				patVo.setGender("Male");
			}else if(sGender!=null && sGender.equalsIgnoreCase("F"))
			{
				patVo.setGender("Female");
			}else {
				patVo.setGender("Others");
			}
			if(patientVisitDetailsE.getPatient().getAge()!=null)
			patVo.setAge(patientVisitDetailsE.getPatient().getAge()+" Years");
			patVo.setMobileNo("+91 "+patientVisitDetailsE.getPatient().getContactNumber());
			String visitType = patientVisitDetailsE.getVisitType();
			if(visitType!=null && visitType.equalsIgnoreCase("OP")) {
				patVo.setVisitType("Out Patient");
			}else if(visitType!=null && visitType.equalsIgnoreCase("IP")) {
				patVo.setVisitType("In Patient");
			}else if(visitType!=null && visitType.equalsIgnoreCase("ER")) {
				patVo.setVisitType("Emergency");
			}else {
				patVo.setVisitType("Day Care");
			}
			
			patVo.setVisitId(patientVisitDetailsE.getVisitId().toString());
			patVo.setHealthId(patientVisitDetailsE.getPatient().getSwasthyaId());
			if (patientVisitDetailsE.getVisitDt() != null)
				patVo.setRegDate(formatter.format(patientVisitDetailsE.getVisitDt()));
		}

		return patVo;
	}

	@Override
	public List<PatientVO> getPatientListById(PatientSearchVO patientSearchVO) {
		// TODO Auto-generated method stub
		List<PatientVO> patVoLst = new ArrayList<PatientVO>();
		List<PatientVisitDetails> patVisitList = null;
		SimpleDateFormat formatter = new SimpleDateFormat("dd-MMM-yyyy hh:mm:ss");

		String patName = patientSearchVO.getPatName();
		String patId = patientSearchVO.getPatId();
		String mobileNo = patientSearchVO.getMobileNo();
		String hospId = patientSearchVO.getHospId();
		System.out.println("In search "+patName+" "+patId+" "+mobileNo+" "+hospId);
		
		if(patientSearchVO.getMobileNo()!=null) {
		patVisitList = patientVisitRepository.findAllWithPatientId(patId,mobileNo,hospId);
		}else {
		patVisitList = patientVisitRepository.findAllWithPatientId(patId,hospId);
		}
			
				
		ListIterator<PatientVisitDetails> iterator1 = patVisitList.listIterator();
		String fullName = "";
		while (iterator1.hasNext()) {
			PatientVO patVo = new PatientVO();
			PatientVisitDetails patientVisirtDtls = iterator1.next();

			Patient patient = patientVisirtDtls.getPatient();
			fullName="";
			fullName = patient.getFirstName();
			if(patient.getMiddleName()!=null)
				fullName = fullName+" "+patient.getMiddleName();
			if(patient.getLastName()!=null)
				fullName = fullName+" "+patient.getLastName();
			patVo.setName(fullName);
			patVo.setPatId(patient.getSwasthyaId()+ "");
			if(patient.getGender()!=null && patient.getGender().equals("M")) {
			patVo.setGender("Male");
			}else if(patient.getGender()!=null && patient.getGender().equals("F")) {
				patVo.setGender("Female");
			}else
			{
				patVo.setGender("Others");
			}
			
			patVo.setAge(patient.getAge());
			patVo.setMobileNo(patient.getContactNumber());
			
			String visitType = patientVisirtDtls.getVisitType();
			if(visitType!=null && visitType.equalsIgnoreCase("OP")) {
				patVo.setVisitType("Out Patient");
			}else if(visitType!=null && visitType.equalsIgnoreCase("IP")) {
				patVo.setVisitType("In Patient");
			}else if(visitType!=null && visitType.equalsIgnoreCase("ER")) {
				patVo.setVisitType("Emergency");
			}else {
				patVo.setVisitType("Day Care");
			}
			patVo.setVisitId(patientVisirtDtls.getVisitId()+"");
			if (patientVisirtDtls.getVisitDt() != null)
				patVo.setRegDate(formatter.format(patientVisirtDtls.getVisitDt()));
			patVoLst.add(patVo);
		}
		return patVoLst;
	}

			 
}
