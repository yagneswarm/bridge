package org.nha.emr.web.entities;

import java.io.Serializable;
import javax.persistence.*;

/**
 * The primary key class for the tms_trn_case_dtls database table.
 * 
 */
@Embeddable
public class TmsTrnCaseDtlPK implements Serializable {
	//default serial version id, required for serializable classes.
	private static final long serialVersionUID = 1L;

	@Column(name="case_id")
	private String caseId;

	private String state;

	public TmsTrnCaseDtlPK() {
	}
	public String getCaseId() {
		return this.caseId;
	}
	public void setCaseId(String caseId) {
		this.caseId = caseId;
	}
	public String getState() {
		return this.state;
	}
	public void setState(String state) {
		this.state = state;
	}

	public boolean equals(Object other) {
		if (this == other) {
			return true;
		}
		if (!(other instanceof TmsTrnCaseDtlPK)) {
			return false;
		}
		TmsTrnCaseDtlPK castOther = (TmsTrnCaseDtlPK)other;
		return 
			this.caseId.equals(castOther.caseId)
			&& this.state.equals(castOther.state);
	}

	public int hashCode() {
		final int prime = 31;
		int hash = 17;
		hash = hash * prime + this.caseId.hashCode();
		hash = hash * prime + this.state.hashCode();
		
		return hash;
	}
}