package org.nha.emr.web.hip.model;

import java.util.Objects;

import javax.validation.Valid;

import org.springframework.validation.annotation.Validated;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonValue;

import io.swagger.annotations.ApiModelProperty;

/**
 * Permission
 */
@Validated



public class Permission   {
  /**
   * Gets or Sets accessMode
   */
  public enum AccessModeEnum {
    VIEW("VIEW"),
    
    STORE("STORE"),
    
    QUERY("QUERY"),
    
    STREAM("STREAM");

    private String value;

    AccessModeEnum(String value) {
      this.value = value;
    }

    @Override
    @JsonValue
    public String toString() {
      return String.valueOf(value);
    }

    @JsonCreator
    public static AccessModeEnum fromValue(String text) {
      for (AccessModeEnum b : AccessModeEnum.values()) {
        if (String.valueOf(b.value).equals(text)) {
          return b;
        }
      }
      return null;
    }
  }
  @JsonProperty("accessMode")
  private AccessModeEnum accessMode = null;

  @JsonProperty("dateRange")
  private PermissionDateRange dateRange = null;

  @JsonProperty("dataEraseAt")
  private String dataEraseAt = null;

  @JsonProperty("frequency")
  private PermissionFrequency frequency = null;

  public Permission accessMode(AccessModeEnum accessMode) {
    this.accessMode = accessMode;
    return this;
  }

  /**
   * Get accessMode
   * @return accessMode
  **/
  @ApiModelProperty(value = "")
  
    public AccessModeEnum getAccessMode() {
    return accessMode;
  }

  public void setAccessMode(AccessModeEnum accessMode) {
    this.accessMode = accessMode;
  }

  public Permission dateRange(PermissionDateRange dateRange) {
    this.dateRange = dateRange;
    return this;
  }

  /**
   * Get dateRange
   * @return dateRange
  **/
  @ApiModelProperty(value = "")
  
    @Valid
    public PermissionDateRange getDateRange() {
    return dateRange;
  }

  public void setDateRange(PermissionDateRange dateRange) {
    this.dateRange = dateRange;
  }

  public Permission dataEraseAt(String dataEraseAt) {
    this.dataEraseAt = dataEraseAt;
    return this;
  }

  /**
   * Get dataEraseAt
   * @return dataEraseAt
  **/
  @ApiModelProperty(value = "")
  
    @Valid
    public String getDataEraseAt() {
    return dataEraseAt;
  }

  public void setDataEraseAt(String dataEraseAt) {
    this.dataEraseAt = dataEraseAt;
  }

  public Permission frequency(PermissionFrequency frequency) {
    this.frequency = frequency;
    return this;
  }

  /**
   * Get frequency
   * @return frequency
  **/
  @ApiModelProperty(value = "")
  
    @Valid
    public PermissionFrequency getFrequency() {
    return frequency;
  }

  public void setFrequency(PermissionFrequency frequency) {
    this.frequency = frequency;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    Permission permission = (Permission) o;
    return Objects.equals(this.accessMode, permission.accessMode) &&
        Objects.equals(this.dateRange, permission.dateRange) &&
        Objects.equals(this.dataEraseAt, permission.dataEraseAt) &&
        Objects.equals(this.frequency, permission.frequency);
  }

  @Override
  public int hashCode() {
    return Objects.hash(accessMode, dateRange, dataEraseAt, frequency);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class Permission {\n");
    
    sb.append("    accessMode: ").append(toIndentedString(accessMode)).append("\n");
    sb.append("    dateRange: ").append(toIndentedString(dateRange)).append("\n");
    sb.append("    dataEraseAt: ").append(toIndentedString(dataEraseAt)).append("\n");
    sb.append("    frequency: ").append(toIndentedString(frequency)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
