package org.nha.emr.web.hip.model;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;

/**
 * Gets or Sets ConsentStatus
 */
public enum ConsentStatus {
  GRANTED("GRANTED"),
    EXPIRED("EXPIRED"),
    DENIED("DENIED"),
    REQUESTED("REQUESTED"),
    REVOKED("REVOKED");

  private String value;

  ConsentStatus(String value) {
    this.value = value;
  }

  @Override
  @JsonValue
  public String toString() {
    return String.valueOf(value);
  }

  @JsonCreator
  public static ConsentStatus fromValue(String text) {
    for (ConsentStatus b : ConsentStatus.values()) {
      if (String.valueOf(b.value).equals(text)) {
        return b;
      }
    }
    return null;
  }
}
