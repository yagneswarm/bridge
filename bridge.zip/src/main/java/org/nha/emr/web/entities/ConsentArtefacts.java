package org.nha.emr.web.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;

@Entity
@Table(name = "consent_artefacts")
public class ConsentArtefacts extends AuditModel{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@Size(min = 1, max = 100)
	@Column(name="consent_artefact_id")
	String consentArtefactId;
	
	@NotBlank
    @Size(min = 1, max = 100)
    @Column(name = "consent_id")
	String consentId;
	
	public String getConsentId() {
		return consentId;
	}

	public void setConsentId(String consentId) {
		this.consentId = consentId;
	}

	public String getConsentArtefactId() {
		return consentArtefactId;
	}

	public void setConsentArtefactId(String consentArtefactId) {
		this.consentArtefactId = consentArtefactId;
	}
	

}
