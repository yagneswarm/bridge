package org.nha.emr.web.repositories;

import java.util.List;

import org.nha.emr.web.entities.HiuConsentRequest;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;

@Repository
@Component
public interface HiuConsentRepository extends JpaRepository<HiuConsentRequest, Long> {
	
	@Query("select a from HiuConsentRequest a where a.consentRefNum =?1")
	List<HiuConsentRequest>  findByConsentRefId(String consentRefNum);
	
	@Query("select a from HiuConsentRequest a where a.consentTxnNum =?1")
	List<HiuConsentRequest>  findByconsentTxnNum(String consentTxnNum);
	
	@Query(value="select hcr.* from consent_request cr,consent_artefacts ca, hiu_consent_request hcr  where cr.consent_id = ca.consent_id and hcr.consent_id = ca.consent_artefact_id and cr.consent_request_id=?1",nativeQuery = true)
	List<HiuConsentRequest>  findByconsentReqId(String consentRequestId);
}
