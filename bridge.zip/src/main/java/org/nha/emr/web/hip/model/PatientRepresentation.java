package org.nha.emr.web.hip.model;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import javax.validation.Valid;

import org.springframework.validation.annotation.Validated;

import com.fasterxml.jackson.annotation.JsonProperty;

import io.swagger.annotations.ApiModelProperty;

/**
 * PatientRepresentation
 */
@Validated



public class PatientRepresentation   {
  @JsonProperty("referenceNumber")
  private String referenceNumber = null;

  @JsonProperty("display")
  private String display = null;

  @JsonProperty("careContexts")
  @Valid
  private List<CareContextRepresentation> careContexts = null;

  @JsonProperty("matchedBy")
  @Valid
  private List<IdentifierType> matchedBy = null;

  public PatientRepresentation referenceNumber(String referenceNumber) {
    this.referenceNumber = referenceNumber;
    return this;
  }

  /**
   * Get referenceNumber
   * @return referenceNumber
  **/
  @ApiModelProperty(value = "")
  
    public String getReferenceNumber() {
    return referenceNumber;
  }

  public void setReferenceNumber(String referenceNumber) {
    this.referenceNumber = referenceNumber;
  }

  public PatientRepresentation display(String display) {
    this.display = display;
    return this;
  }

  /**
   * Get display
   * @return display
  **/
  @ApiModelProperty(value = "")
  
    public String getDisplay() {
    return display;
  }

  public void setDisplay(String display) {
    this.display = display;
  }

  public PatientRepresentation careContexts(List<CareContextRepresentation> careContexts) {
    this.careContexts = careContexts;
    return this;
  }

  public PatientRepresentation addCareContextsItem(CareContextRepresentation careContextsItem) {
    if (this.careContexts == null) {
      this.careContexts = new ArrayList<CareContextRepresentation>();
    }
    this.careContexts.add(careContextsItem);
    return this;
  }

  /**
   * Get careContexts
   * @return careContexts
  **/
  @ApiModelProperty(value = "")
      @Valid
    public List<CareContextRepresentation> getCareContexts() {
    return careContexts;
  }

  public void setCareContexts(List<CareContextRepresentation> careContexts) {
    this.careContexts = careContexts;
  }

  public PatientRepresentation matchedBy(List<IdentifierType> matchedBy) {
    this.matchedBy = matchedBy;
    return this;
  }

  public PatientRepresentation addMatchedByItem(IdentifierType matchedByItem) {
    if (this.matchedBy == null) {
      this.matchedBy = new ArrayList<IdentifierType>();
    }
    this.matchedBy.add(matchedByItem);
    return this;
  }

  /**
   * Get matchedBy
   * @return matchedBy
  **/
  @ApiModelProperty(value = "")
      @Valid
    public List<IdentifierType> getMatchedBy() {
    return matchedBy;
  }

  public void setMatchedBy(List<IdentifierType> matchedBy) {
    this.matchedBy = matchedBy;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    PatientRepresentation patientRepresentation = (PatientRepresentation) o;
    return Objects.equals(this.referenceNumber, patientRepresentation.referenceNumber) &&
        Objects.equals(this.display, patientRepresentation.display) &&
        Objects.equals(this.careContexts, patientRepresentation.careContexts) &&
        Objects.equals(this.matchedBy, patientRepresentation.matchedBy);
  }

  @Override
  public int hashCode() {
    return Objects.hash(referenceNumber, display, careContexts, matchedBy);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class PatientRepresentation {\n");
    
    sb.append("    referenceNumber: ").append(toIndentedString(referenceNumber)).append("\n");
    sb.append("    display: ").append(toIndentedString(display)).append("\n");
    sb.append("    careContexts: ").append(toIndentedString(careContexts)).append("\n");
    sb.append("    matchedBy: ").append(toIndentedString(matchedBy)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
