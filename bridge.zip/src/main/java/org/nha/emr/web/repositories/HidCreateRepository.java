package org.nha.emr.web.repositories;

import java.util.List;
import java.util.UUID;

import org.nha.emr.web.entities.HidCreate;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;


@Repository
@Component
public interface HidCreateRepository extends JpaRepository< HidCreate, String> {
	
	@Query(value="select * from hpridcreate hc where hc.hipcode=?1",nativeQuery = true )
	 List<HidCreate> findByHipCode(String hipCode) ;

}
