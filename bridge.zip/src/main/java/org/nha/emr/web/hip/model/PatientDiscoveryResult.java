package org.nha.emr.web.hip.model;

import java.util.Objects;
import java.util.UUID;

import javax.validation.Valid;

import org.springframework.validation.annotation.Validated;

import com.fasterxml.jackson.annotation.JsonProperty;

import io.swagger.annotations.ApiModelProperty;

/**
 * PatientDiscoveryResult
 */
@Validated



public class PatientDiscoveryResult   {
  @JsonProperty("requestId")
  private UUID requestId = null;

  @JsonProperty("timestamp")
  private String timestamp = null;

  @JsonProperty("transactionId")
  private UUID transactionId = null;

  @JsonProperty("patient")
  private PatientRepresentation patient = null;

  @JsonProperty("error")
  private Error error = null;

  @JsonProperty("resp")
  private RequestReference resp = null;

  public PatientDiscoveryResult requestId(UUID requestId) {
    this.requestId = requestId;
    return this;
  }

  /**
   * a nonce, unique for each HTTP request
   * @return requestId
  **/
  @ApiModelProperty(example = "5f7a535d-a3fd-416b-b069-c97d021fbacd", value = "a nonce, unique for each HTTP request")
  
    @Valid
    public UUID getRequestId() {
    return requestId;
  }

  public void setRequestId(UUID requestId) {
    this.requestId = requestId;
  }

  public PatientDiscoveryResult timestamp(String timestamp) {
    this.timestamp = timestamp;
    return this;
  }

  /**
   * Get timestamp
   * @return timestamp
  **/
  @ApiModelProperty(value = "")
  
    @Valid
    public String getTimestamp() {
    return timestamp;
  }

  public void setTimestamp(String timestamp) {
    this.timestamp = timestamp;
  }

  public PatientDiscoveryResult transactionId(UUID transactionId) {
    this.transactionId = transactionId;
    return this;
  }

  /**
   * Get transactionId
   * @return transactionId
  **/
  @ApiModelProperty(value = "")
  
    @Valid
    public UUID getTransactionId() {
    return transactionId;
  }

  public void setTransactionId(UUID transactionId) {
    this.transactionId = transactionId;
  }

  public PatientDiscoveryResult patient(PatientRepresentation patient) {
    this.patient = patient;
    return this;
  }

  /**
   * Get patient
   * @return patient
  **/
  @ApiModelProperty(value = "")
  
    @Valid
    public PatientRepresentation getPatient() {
    return patient;
  }

  public void setPatient(PatientRepresentation patient) {
    this.patient = patient;
  }

  public PatientDiscoveryResult error(Error error) {
    this.error = error;
    return this;
  }

  /**
   * Get error
   * @return error
  **/
  @ApiModelProperty(value = "")
  
    @Valid
    public Error getError() {
    return error;
  }

  public void setError(Error error) {
    this.error = error;
  }

  public PatientDiscoveryResult resp(RequestReference resp) {
    this.resp = resp;
    return this;
  }

  /**
   * Get resp
   * @return resp
  **/
  @ApiModelProperty(value = "")
  
    @Valid
    public RequestReference getResp() {
    return resp;
  }

  public void setResp(RequestReference resp) {
    this.resp = resp;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    PatientDiscoveryResult patientDiscoveryResult = (PatientDiscoveryResult) o;
    return Objects.equals(this.requestId, patientDiscoveryResult.requestId) &&
        Objects.equals(this.timestamp, patientDiscoveryResult.timestamp) &&
        Objects.equals(this.transactionId, patientDiscoveryResult.transactionId) &&
        Objects.equals(this.patient, patientDiscoveryResult.patient) &&
        Objects.equals(this.error, patientDiscoveryResult.error) &&
        Objects.equals(this.resp, patientDiscoveryResult.resp);
  }

  @Override
  public int hashCode() {
    return Objects.hash(requestId, timestamp, transactionId, patient, error, resp);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class PatientDiscoveryResult {\n");
    
    sb.append("    requestId: ").append(toIndentedString(requestId)).append("\n");
    sb.append("    timestamp: ").append(toIndentedString(timestamp)).append("\n");
    sb.append("    transactionId: ").append(toIndentedString(transactionId)).append("\n");
    sb.append("    patient: ").append(toIndentedString(patient)).append("\n");
    sb.append("    error: ").append(toIndentedString(error)).append("\n");
    sb.append("    resp: ").append(toIndentedString(resp)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
