package org.nha.emr.web.hip.model;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;

/**
 * what is the purpose of user auth
 */
public enum PatientAuthPurpose {
  LINK("LINK"),
    KYC("KYC"),
    KYC_AND_LINK("KYC_AND_LINK");

  private String value;

  PatientAuthPurpose(String value) {
    this.value = value;
  }

  @Override
  @JsonValue
  public String toString() {
    return String.valueOf(value);
  }

  @JsonCreator
  public static PatientAuthPurpose fromValue(String text) {
    for (PatientAuthPurpose b : PatientAuthPurpose.values()) {
      if (String.valueOf(b.value).equals(text)) {
        return b;
      }
    }
    return null;
  }
}
