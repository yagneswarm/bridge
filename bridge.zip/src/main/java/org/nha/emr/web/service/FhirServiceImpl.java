package org.nha.emr.web.service;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.math.BigInteger;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import org.hl7.fhir.r4.model.AllergyIntolerance;
import org.hl7.fhir.r4.model.Annotation;
import org.hl7.fhir.r4.model.Appointment;
import org.hl7.fhir.r4.model.Appointment.AppointmentParticipantComponent;
import org.hl7.fhir.r4.model.Appointment.AppointmentStatus;
import org.hl7.fhir.r4.model.Appointment.ParticipationStatus;
import org.hl7.fhir.r4.model.Attachment;
import org.hl7.fhir.r4.model.Bundle;
import org.hl7.fhir.r4.model.Bundle.BundleEntryComponent;
import org.hl7.fhir.r4.model.Bundle.BundleType;
import org.hl7.fhir.r4.model.CanonicalType;
import org.hl7.fhir.r4.model.CarePlan;
import org.hl7.fhir.r4.model.CarePlan.CarePlanIntent;
import org.hl7.fhir.r4.model.CarePlan.CarePlanStatus;
import org.hl7.fhir.r4.model.CodeableConcept;
import org.hl7.fhir.r4.model.Coding;
import org.hl7.fhir.r4.model.Composition;
import org.hl7.fhir.r4.model.Composition.CompositionStatus;
import org.hl7.fhir.r4.model.Composition.DocumentConfidentiality;
import org.hl7.fhir.r4.model.Composition.SectionComponent;
import org.hl7.fhir.r4.model.Condition;
import org.hl7.fhir.r4.model.ContactPoint;
import org.hl7.fhir.r4.model.ContactPoint.ContactPointSystem;
import org.hl7.fhir.r4.model.ContactPoint.ContactPointUse;
import org.hl7.fhir.r4.model.DiagnosticReport;
import org.hl7.fhir.r4.model.DiagnosticReport.DiagnosticReportStatus;
import org.hl7.fhir.r4.model.DocumentReference;
import org.hl7.fhir.r4.model.DocumentReference.DocumentReferenceContentComponent;
import org.hl7.fhir.r4.model.DocumentReference.ReferredDocumentStatus;
import org.hl7.fhir.r4.model.Dosage;
import org.hl7.fhir.r4.model.Duration;
import org.hl7.fhir.r4.model.Encounter;
import org.hl7.fhir.r4.model.Encounter.EncounterStatus;
import org.hl7.fhir.r4.model.Enumerations.AdministrativeGender;
import org.hl7.fhir.r4.model.Enumerations.DocumentReferenceStatus;
import org.hl7.fhir.r4.model.HumanName;
import org.hl7.fhir.r4.model.Identifier;
import org.hl7.fhir.r4.model.Media;
import org.hl7.fhir.r4.model.Media.MediaStatus;
import org.hl7.fhir.r4.model.MedicationRequest;
import org.hl7.fhir.r4.model.MedicationRequest.MedicationRequestIntent;
import org.hl7.fhir.r4.model.MedicationRequest.MedicationRequestStatus;
import org.hl7.fhir.r4.model.Narrative.NarrativeStatus;
import org.hl7.fhir.r4.model.Organization;
import org.hl7.fhir.r4.model.Patient;
import org.hl7.fhir.r4.model.Period;
import org.hl7.fhir.r4.model.Practitioner;
import org.hl7.fhir.r4.model.Procedure;
import org.hl7.fhir.r4.model.Procedure.ProcedureStatus;
import org.hl7.fhir.r4.model.Quantity;
import org.hl7.fhir.r4.model.Reference;
import org.hl7.fhir.r4.model.ServiceRequest;
import org.hl7.fhir.r4.model.ServiceRequest.ServiceRequestIntent;
import org.hl7.fhir.r4.model.ServiceRequest.ServiceRequestStatus;
import org.hl7.fhir.r4.model.Signature;
import org.hl7.fhir.utilities.xhtml.NodeType;
import org.hl7.fhir.utilities.xhtml.XhtmlNode;
import org.nha.emr.web.entities.DiagnosticAttachment;
import org.nha.emr.web.entities.PatientClinicalNotesDetails;
import org.nha.emr.web.entities.PatientDiagnosticReportDetails;
import org.nha.emr.web.entities.PatientDischargeDetails;
import org.nha.emr.web.entities.PatientPrescriptionDetails;
import org.nha.emr.web.entities.PatientVisitDetails;
import org.nha.emr.web.repositories.DiagnosticAttachmentRepository;
import org.nha.emr.web.repositories.PatientClinicalNotesRepository;
import org.nha.emr.web.repositories.PatientDiagnosticReportRepository;
import org.nha.emr.web.repositories.PatientDischargeRepository;
import org.nha.emr.web.repositories.PatientPrescriptionRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import ca.uhn.fhir.context.FhirContext;
import ca.uhn.fhir.narrative.DefaultThymeleafNarrativeGenerator;
import ca.uhn.fhir.rest.client.api.IGenericClient;

@Service
@Component
public class FhirServiceImpl implements FhirService {


	FhirContext ctx = FhirContext.forR4();
	IGenericClient client = null;
	@Autowired
	DiagnosticAttachmentRepository attachmentRepository;
	@Autowired
	PatientPrescriptionRepository patientPrescriptionRepository;
	@Autowired
	PatientDiagnosticReportRepository patientDiagnosticReportRepository;
	@Autowired
	PatientDischargeRepository patientDischargeRepository;
	@Autowired
	PatientClinicalNotesRepository patientClinicalNotesRepository;
	
	
	public String createFhirResource(String objType,Object obj , Date fromDt,Date toDt) {
		
		String  encoded = null;
		BundleEntryComponent bundleEntryComponent = null;
		Bundle bundle = null;
		ctx.setNarrativeGenerator(new DefaultThymeleafNarrativeGenerator());
		if (objType.equalsIgnoreCase("patient")) {
			 bundleEntryComponent = getPatientFhirObject((org.nha.emr.web.entities.Patient)obj);
			 encoded =  ctx.newJsonParser().setSuppressNarratives(true).encodeResourceToString(bundleEntryComponent.getResource());
				
		}else if (objType.equalsIgnoreCase("encounter")) {
			PatientVisitDetails patientVisitDtlsE = (PatientVisitDetails)obj;
			bundleEntryComponent = getEncounterFhirObject(patientVisitDtlsE);
			
			 encoded =  ctx.newJsonParser().setSuppressNarratives(true).encodeResourceToString(bundleEntryComponent.getResource());
			
		}else if(objType.equalsIgnoreCase("practitioner")){
			PatientVisitDetails patientVisitDtlsE = (PatientVisitDetails)obj;
			bundleEntryComponent = getPractitionerFhirObject(patientVisitDtlsE);
			
			 encoded =  ctx.newJsonParser().setSuppressNarratives(true).encodeResourceToString(bundleEntryComponent.getResource());
			
		}else if(objType.equalsIgnoreCase("medication")) {
			PatientVisitDetails patientVisitDtlsE = (PatientVisitDetails)obj;
			
			bundle = getMedicationRequest(patientVisitDtlsE,fromDt,toDt);
		
			 encoded =  ctx.newJsonParser().setSuppressNarratives(true).encodeResourceToString(bundle);
				
		}else if(objType.equalsIgnoreCase("diagnostic")) {
			PatientVisitDetails patientVisitDtlsE = (PatientVisitDetails)obj;
			
			bundle = getDiagnosticRequest(patientVisitDtlsE,fromDt,toDt);
			 encoded =  ctx.newJsonParser().setSuppressNarratives(true).encodeResourceToString(bundle);
				
		}else if(objType.equalsIgnoreCase("opconsultation")) {
			PatientVisitDetails patientVisitDtlsE = (PatientVisitDetails)obj;
			
			bundle = getConsulingNoteRequest(patientVisitDtlsE,fromDt,toDt);
		
			 encoded =  ctx.newJsonParser().setSuppressNarratives(true).encodeResourceToString(bundle);
				
		}else if(objType.equalsIgnoreCase("dischargesummary")) {
			PatientVisitDetails patientVisitDtlsE = (PatientVisitDetails)obj;
			
			bundle = getDischargeRequest(patientVisitDtlsE,fromDt,toDt);
		
			 encoded =  ctx.newJsonParser().setSuppressNarratives(true).encodeResourceToString(bundle);
				
		}
		
		return encoded;
	}
	


	
	@Override
	public BundleEntryComponent getPatientFhirObject(org.nha.emr.web.entities.Patient patientE) {
		// TODO Auto-generated method stub
		String  encoded = null;
		Patient patient = null;
		
		BundleEntryComponent bundleEntryComponent = new BundleEntryComponent();
		patient = new Patient();
		bundleEntryComponent.setFullUrl("Patient/"+patientE.getPatientId()); 
		patient.setId(patientE.getPatientId().toString());
		patient.getMeta().setVersionId("1");
		patient.getMeta().setLastUpdated(patientE.getLastVisitDt());
		
		Identifier identifier = new Identifier();
		identifier.setSystem("https://emr.ndhm.gov.in");
		identifier.setValue(patientE.getPatientId().toString());
		List<Identifier> list = new ArrayList<Identifier>();
		list.add(identifier);
		patient.setIdentifier(list);
		
		HumanName humanName = new HumanName();
		humanName.setFamily(patientE.getLastName());
		humanName.addGiven(patientE.getFirstName());
		
		List<HumanName> humanLst = new ArrayList<HumanName>();
		humanLst.add(humanName);
		patient.setName(humanLst);
		
		ContactPoint contactPoint = new ContactPoint();
		contactPoint.setSystem( ContactPointSystem.PHONE);
		contactPoint.setValue(patientE.getContactNumber());
		contactPoint.setUse(ContactPointUse.HOME);
		
		List<ContactPoint> contLst = new ArrayList<ContactPoint>();
		contLst.add(contactPoint);
		patient.setTelecom(contLst);
		if(patientE.getGender().equalsIgnoreCase("Female")) {
			patient.setGender(AdministrativeGender.FEMALE);
		}else if(patientE.getGender().equalsIgnoreCase("Male")){
			patient.setGender(AdministrativeGender.MALE);
		}else {
			patient.setGender(AdministrativeGender.OTHER);
		}
		
		patient.setBirthDate(patientE.getBirthDt());
		patient.getText().setStatus(org.hl7.fhir.r4.model.Narrative.NarrativeStatus.GENERATED);
		patient.getText().setDivAsString("Person Resource");
		
		bundleEntryComponent.setResource(patient);
		
		return bundleEntryComponent;
	}



	@Override
	public BundleEntryComponent getEncounterFhirObject(PatientVisitDetails patientVisitDetails) {
		// TODO Auto-generated method stub
		
		BundleEntryComponent bundleEntryComponent = new BundleEntryComponent();
		Encounter encounter = new Encounter();
		
		bundleEntryComponent.setFullUrl("Encounter/"+patientVisitDetails.getVisitId());
		
		encounter.setId(patientVisitDetails.getVisitId()+"");
		encounter.getMeta().setVersionId("1");
		encounter.getMeta().setLastUpdated(patientVisitDetails.getVisitDt());
		
		Identifier identifier = new Identifier();
		identifier.setSystem("https://emr.ndhm.gov.in");
		identifier.setValue(patientVisitDetails.getVisitId()+"");
		List<Identifier> list = new ArrayList<Identifier>();
		list.add(identifier);
		encounter.setIdentifier(list);
		encounter.setStatus(EncounterStatus.FINISHED);
		
		 Coding coding = new Coding();
		 coding.setCode(patientVisitDetails.getVisitType());
		 coding.setSystem("http://snomedct.ndhm.gov.in");
		 if(patientVisitDetails.getVisitType()!=null && patientVisitDetails.getVisitType().equalsIgnoreCase("OP")) {
			 coding.setDisplay("Out patient");
		 }else if(patientVisitDetails.getVisitType()!=null && patientVisitDetails.getVisitType().equalsIgnoreCase("IP")) {
			 coding.setDisplay("In patient");
		 }else if(patientVisitDetails.getVisitType()!=null && patientVisitDetails.getVisitType().equalsIgnoreCase("ER")) {
			 coding.setDisplay("Emergency");
		 }else {
			 coding.setDisplay("Day Care");
		 }
		 
		 encounter.setClass_(coding) ;
		 encounter.getText().setStatus(org.hl7.fhir.r4.model.Narrative.NarrativeStatus.GENERATED);
		 encounter.getText().setDivAsString("Encounter Resource");
		 
		 bundleEntryComponent.setResource(encounter);
		
		//End of Encounter
		
		 
		return bundleEntryComponent;
	}

	@Override
	public BundleEntryComponent getServiceFhirObject(PatientVisitDetails patientVisitDetails) {
		// TODO Auto-generated method stub
		
		BundleEntryComponent bundleEntryComponent = new BundleEntryComponent();
		ServiceRequest serviceRequest = new ServiceRequest();
		
		bundleEntryComponent.setFullUrl("ServiceRequest/"+patientVisitDetails.getVisitId());
		
		serviceRequest.setId(patientVisitDetails.getVisitId()+"");
		serviceRequest.getText().setStatus(org.hl7.fhir.r4.model.Narrative.NarrativeStatus.GENERATED);
		serviceRequest.getText().setDivAsString("Service Request");
		 
		serviceRequest.setStatus(ServiceRequestStatus.ACTIVE);
		serviceRequest.setIntent(ServiceRequestIntent.ORIGINALORDER);
		Reference ref = new Reference();
		ref.setReference("Patient/"+patientVisitDetails.getPatient().getPatientId());
		serviceRequest.setSubject(ref);
		serviceRequest.getOccurrenceDateTimeType().setValue(patientVisitDetails.getCreatedAt());
		Reference ref1 = new Reference();
		ref1.setReference("Practitioner/"+patientVisitDetails.getPractitionerCd());
		ref1.setDisplay(patientVisitDetails.getPractitionerName());
		serviceRequest.setRequester(ref1);
		bundleEntryComponent.setResource(serviceRequest);
		
		//End of Encounter
		
		 
		return bundleEntryComponent;
	}


	@Override
	public BundleEntryComponent getPractitionerFhirObject(PatientVisitDetails patientVisitDetailsE) {
		// TODO Auto-generated method stub
		
			 //Starting of Practitioner
			 
			 BundleEntryComponent bundleEntryComponent = new BundleEntryComponent();
			 bundleEntryComponent.setFullUrl("Practitioner/"+patientVisitDetailsE.getPractitionerCd());
			 Practitioner practitioner = new Practitioner();
			 practitioner.setId(patientVisitDetailsE.getPractitionerCd());
			 practitioner.getMeta().setVersionId("1");
			 practitioner.getMeta().setLastUpdated(patientVisitDetailsE.getVisitDt());
			 
			 Identifier identifier = new Identifier();
				identifier.setSystem("https://digidoc.ndhm.gov.in");
				identifier.setValue(patientVisitDetailsE.getPractitionerCd());
				List<Identifier> list = new ArrayList<Identifier>();
				list.add(identifier);
				practitioner.setIdentifier(list);
				
				HumanName humanName = new HumanName();
				humanName.addGiven(patientVisitDetailsE.getPractitionerName());
				List<HumanName> humanLst = new ArrayList<HumanName>();
				humanLst.add(humanName);
				practitioner.setName(humanLst);
				practitioner.getText().setStatus(org.hl7.fhir.r4.model.Narrative.NarrativeStatus.GENERATED);
				practitioner.getText().setDivAsString("Practitioner Resource");
				
				bundleEntryComponent.setResource(practitioner);
				
		return bundleEntryComponent;
		
	}




	@Override
	public BundleEntryComponent getMedicationFhirObject(PatientPrescriptionDetails patientPrescriptionDetails) {
		// TODO Auto-generated method stub
		
		BundleEntryComponent bundleEntryComponent = new BundleEntryComponent();
		bundleEntryComponent.setFullUrl("MedicationRequest/"+patientPrescriptionDetails.getId());
		
		MedicationRequest medicationRequest = new MedicationRequest();
		medicationRequest.setId(patientPrescriptionDetails.getId()+"");
		medicationRequest.getSubject().setReference("Patient/"+patientPrescriptionDetails.getPatientVisitDetails().getPatient().getPatientId());
		medicationRequest.getSubject().setDisplay(patientPrescriptionDetails.getPatientVisitDetails().getPatient().getFirstName());
		medicationRequest.setStatus(MedicationRequestStatus.ACTIVE);
		medicationRequest.setIntent(MedicationRequestIntent.ORDER);
		medicationRequest.getText().setStatus(org.hl7.fhir.r4.model.Narrative.NarrativeStatus.GENERATED);
		medicationRequest.getText().setDivAsString("MedicationRequest resource");
		medicationRequest.getRequester().setReference("Practitioner/"+patientPrescriptionDetails.getPatientVisitDetails().getPractitionerCd());
		//medicationRequest.setMedication(value)
		medicationRequest.getMedicationCodeableConcept().setText(patientPrescriptionDetails.getDrugName());
		medicationRequest.setAuthoredOn(patientPrescriptionDetails.getCreatedAt());
		Dosage dosage = new Dosage();
		dosage.setText(patientPrescriptionDetails.getInstruction());
		medicationRequest.getDosageInstruction().add(dosage);
		
		Quantity quantity = new Quantity();
		if(patientPrescriptionDetails.getQuantity()!=null) {
		quantity.setValue(new Long(patientPrescriptionDetails.getQuantity()));
		}else {
		quantity.setValue(0L);
		}
		quantity.setUnit("As per prescription");
		
		Duration duration = new Duration();
		if(patientPrescriptionDetails.getDuration()!=null) {
		duration.setValue(new Long(patientPrescriptionDetails.getDuration()));
		duration.setUnit(patientPrescriptionDetails.getDurationUnit());
		}else {
			duration.setValue(0L);
			duration.setUnit("day/s");
		}
		
		medicationRequest.getDispenseRequest().setQuantity(quantity);
		medicationRequest.getDispenseRequest().setExpectedSupplyDuration(duration);
		medicationRequest.getMedication().setId(patientPrescriptionDetails.getId().toString());
		bundleEntryComponent.setResource(medicationRequest);
		  
		return bundleEntryComponent;
	}


	@Override
	public BundleEntryComponent getConditionFhirObject(PatientPrescriptionDetails patientPrescriptionDetails) {
		// TODO Auto-generated method stub
		BundleEntryComponent bundleEntryComponent = new BundleEntryComponent();
		bundleEntryComponent.setFullUrl("Condition/"+patientPrescriptionDetails.getPatientVisitDetails().getVisitId());
		Condition condition = new Condition();
		condition.setId(patientPrescriptionDetails.getPatientVisitDetails().getVisitId().toString());
		condition.getSubject().setReference("Patient/"+patientPrescriptionDetails.getPatientVisitDetails().getPatient().getPatientId());
		condition.getCode().setText(patientPrescriptionDetails.getPrescriptionNotes());
		condition.getText().setStatus(org.hl7.fhir.r4.model.Narrative.NarrativeStatus.GENERATED);
		condition.getText().setDivAsString("condition resource");
		
		bundleEntryComponent.setResource(condition);
		return bundleEntryComponent;
	}




	@Override
	public Bundle getMedicationRequest(PatientVisitDetails patientVisitDetails,Date fromDt,Date toDt) {
		// TODO Auto-generated method stub
		
		Bundle bundle = new Bundle();
		bundle.setId("bundle-"+patientVisitDetails.getVisitId());
		bundle.getMeta().setLastUpdated(patientVisitDetails.getUpdatedAt());
		bundle.getIdentifier().setSystem("https://emr.ndhm.gov.in");
		//bundle.getIdentifier().setId(patientVisitDetails.getVisitId()+"");
		bundle.getIdentifier().setValue(patientVisitDetails.getVisitId()+"");
		bundle.setTimestamp(patientVisitDetails.getUpdatedAt());
		
		/***
		 * This needs to be validated against CDAC FHIR profiles
		 */
		Signature signature = new Signature();
		
		List<Coding> codeLst = new ArrayList<Coding>(); Coding coding = new Coding();
		coding.setCode(""); 
		coding.setSystem("urn:iso-astm:E1762-95:2013");
		coding.setDisplay("Author's signature"); 
		codeLst.add(coding);
		signature.setType(codeLst);
		signature.setWhen(patientVisitDetails.getUpdatedAt());
		signature.getWho().setReference("Practitioner/"+patientVisitDetails.getPractitionerCd());
		signature.setSigFormat("XML Digi Sign"); 
		signature.setData(null);
		//bundle.setSignature(signature); Will verify later.
		
	    bundle.setType(BundleType.DOCUMENT);
	  
	    
	    BundleEntryComponent bundleEntryComponent = new BundleEntryComponent();
		bundleEntryComponent.setFullUrl("Composition/"+patientVisitDetails.getVisitId());
		
		Composition composition = new Composition();
		composition.setId(patientVisitDetails.getVisitId()+"");
		composition.getMeta().setVersionId("1");
		composition.getMeta().setLastUpdated(patientVisitDetails.getUpdatedAt());
		CanonicalType canonicalType = new CanonicalType();
		canonicalType.setValue("This is prescription composition");
		List<CanonicalType> canonicalLst = new ArrayList<CanonicalType>();
		composition.getMeta().setProfile(canonicalLst);
		composition.setLanguage("en-IN");
		XhtmlNode xmlType = new XhtmlNode(); 
		xmlType.setNodeType(NodeType.Text);
		xmlType.setValue("Prescription Record");
		composition.getText().setDiv( xmlType);
		composition.getText().setStatus(NarrativeStatus.GENERATED);
		
		composition.getIdentifier().setSystem("https://emr.ndhm.gov.in");
		composition.getIdentifier().setValue(patientVisitDetails.getVisitId()+"");
		composition.setStatus(CompositionStatus.FINAL);
		
		List<Coding> codeLst1 = new ArrayList<Coding>();
		 Coding coding1 = new Coding();
		 coding1.setCode("440545006");
		 coding1.setSystem("https://snomedct.ndhm.gov.in/sct");
		 coding1.setDisplay("Prescription Record");
		 codeLst1.add(coding1);
		composition.getType().setCoding(codeLst1);
		composition.getType().setText("Prescription Record");
		composition.getSubject().setReference("Patient/"+patientVisitDetails.getPatient().getPatientId());
		composition.getEncounter().setReference("Encounter/"+patientVisitDetails.getVisitId());
		composition.setDate(patientVisitDetails.getUpdatedAt());
		List<Reference> authorLst =  new ArrayList<Reference>();
		
		Reference ref = new Reference();
		ref.setReference("Practitioner/"+patientVisitDetails.getPractitionerCd());
		authorLst.add(ref);
		composition.setAuthor(authorLst);
		composition.setTitle("Prescription Record");
		List<SectionComponent> sectionList = new ArrayList<SectionComponent>(); 
		
		//List<PatientPrescriptionDetails> setPatientPrescriptions = patientVisitDetails.getPatientPrescriptionDetails();
		
		List<PatientPrescriptionDetails> setPatientPrescriptions = patientPrescriptionRepository.findWithVisitIdDateRange(patientVisitDetails.getVisitId(), fromDt, toDt);
		
		PatientPrescriptionDetails patientPrescriptionDetails = null;
		
		if(setPatientPrescriptions!=null) {
			Iterator<PatientPrescriptionDetails> iterator = setPatientPrescriptions.iterator();	
			while(iterator.hasNext()) {
				patientPrescriptionDetails = iterator.next();
				if(patientPrescriptionDetails!=null && patientPrescriptionDetails.getReportType().equalsIgnoreCase("OL")) {
				SectionComponent section = new SectionComponent();
				section.setTitle("Prescription Record");
				CodeableConcept concept = new CodeableConcept();
				concept.addCoding(coding1);
				section.setCode(concept);
				Reference secRef = new Reference();
				secRef.setReference("MedicationRequest/"+patientPrescriptionDetails.getId());
				section.getEntry().add(secRef);
				sectionList.add(section);
				}else {
					SectionComponent documentRef = new SectionComponent();
					documentRef.setTitle("Document Referece");
					Coding codingDocRef = new Coding();
					codingDocRef.setCode("440545006");
					codingDocRef.setDisplay("Prescription record");
					codingDocRef.setSystem("http://snomed.info/sct");
					
					Reference docRef = new Reference();
					docRef.setReference("DocumentReference/"+patientPrescriptionDetails.getId());
					documentRef.getEntry().add(docRef); 
					sectionList.add(documentRef);				
				}
			}
		}
		
		
		SectionComponent sectionCondtion = new SectionComponent();
		sectionCondtion.setTitle("Presenting problems");
		CodeableConcept conceptCondition = new CodeableConcept();
		conceptCondition.addCoding(coding1);
		sectionCondtion.setCode(conceptCondition);
		Reference secRef1 = new Reference();
		secRef1.setReference("Condition/"+patientVisitDetails.getVisitId());
		sectionCondtion.getEntry().add(secRef1);
		sectionList.add(sectionCondtion);
		composition.setSection(sectionList);
		
		bundleEntryComponent.setResource(composition); 
		List<BundleEntryComponent> bundleComponentLst = new ArrayList<BundleEntryComponent>();
		bundleComponentLst.add(bundleEntryComponent);
		bundleComponentLst.add(getPatientFhirObject(patientVisitDetails.getPatient()));
		bundleComponentLst.add(getEncounterFhirObject(patientVisitDetails));
		bundleComponentLst.add(getPractitionerFhirObject(patientVisitDetails));
		List<PatientPrescriptionDetails> setPatientPrescriptions1 = patientVisitDetails.getPatientPrescriptionDetails();
		PatientPrescriptionDetails patientPrescriptionDetails1 = null;
		if(setPatientPrescriptions1!=null) {
			Iterator<PatientPrescriptionDetails> iterator = setPatientPrescriptions1.iterator();	
			while(iterator.hasNext()) {
				patientPrescriptionDetails1 = iterator.next();
				if(patientPrescriptionDetails1!=null && patientPrescriptionDetails1.getReportType().equalsIgnoreCase("OL")) {
					bundleComponentLst.add(getMedicationFhirObject(patientPrescriptionDetails1));
				}else {
					BundleEntryComponent documentReferenceComp = new BundleEntryComponent();
					documentReferenceComp.setFullUrl("DocumentReference/"+patientPrescriptionDetails1.getId());
					DocumentReference  documentReference= new DocumentReference();
					documentReference.setId(patientPrescriptionDetails1.getId().toString());
					documentReference.getText().setStatus(NarrativeStatus.GENERATED).setDivAsString("Docuemt Reference ");
					documentReference.setStatus(DocumentReferenceStatus.CURRENT);
					documentReference.setDocStatus(ReferredDocumentStatus.FINAL);
					documentReference.getType().addCoding().setSystem("https://snomedct.ndhm.gov.in/loinc").setCode("440545006").setDisplay("Prescription record");	
					documentReference.getType().setText("Clinical Consultation report");
					documentReference.getSubject().setReference("Patient/"+patientVisitDetails.getPatient());
					DocumentReferenceContentComponent documentReferenceContentComponent = new DocumentReferenceContentComponent();
					Attachment attach = new Attachment();
					String fileExt = null;
					String filePath=null;
					String contentType = null;
					if(patientPrescriptionDetails1!=null && patientPrescriptionDetails1.getReportType()!=null) {
						filePath = patientPrescriptionDetails1.getAttachPath();
						fileExt = filePath.substring((filePath.lastIndexOf(".") + 1));
						if (fileExt.equalsIgnoreCase("jpg") || fileExt.equalsIgnoreCase("jpeg") || fileExt.equalsIgnoreCase("png"))
						{
							contentType="image/jpeg";
						}
						if (fileExt.equalsIgnoreCase("pdf"))
						{
							contentType="application/pdf";
						}
						attach.setContentType(contentType);
						attach.setLanguage("en-IN");
						attach.setTitle("Prescription Record");
						byte[] bytestream = getBase64(filePath);
						if(bytestream!=null) {
						attach.setData(bytestream);
						attach.setSize(bytestream.length);
						attach.setTitle("Prescription Record");
						}else {
							attach.setData(null);
							attach.setSize(0);
							attach.setTitle("No data");
						}
						attach.setCreation(patientPrescriptionDetails1.getCreatedAt());
						documentReferenceContentComponent.setAttachment(attach);
					}
					
			        documentReference.getContent().add(documentReferenceContentComponent);
					documentReferenceComp.setResource(documentReference);
					bundleComponentLst.add(documentReferenceComp);				
					}
				
			}
		}
		bundleComponentLst.add(getConditionFhirObject(patientVisitDetails.getPatientPrescriptionDetails().iterator().next()));
		
		bundle.setEntry(bundleComponentLst);
		
		return bundle;
	}

	public BundleEntryComponent getDiagnosticComposition(PatientVisitDetails patientVisitDetails) {
		// TODO Auto-generated method stub
				List<PatientDiagnosticReportDetails> setDiagnosticReport = null;
				PatientDiagnosticReportDetails diagnosticReport = null;
				if(patientVisitDetails.getDiagnosticReportYn()!="Y") {
					setDiagnosticReport = patientVisitDetails.getPatientDiagnosticReportDetails();
				}
				if(setDiagnosticReport!=null) {
					Iterator<PatientDiagnosticReportDetails> iterator = setDiagnosticReport.iterator();
					while(iterator.hasNext()) {
						diagnosticReport = (PatientDiagnosticReportDetails)iterator.next();
					}
				}
				
		BundleEntryComponent bundleEntryComponent = new BundleEntryComponent();
		bundleEntryComponent.setFullUrl("Composition/"+patientVisitDetails.getVisitId());
	
		Composition composition = new Composition();
		composition.setId(patientVisitDetails.getVisitId()+"");
		composition.getMeta().setVersionId("1");
		composition.getMeta().setLastUpdated(patientVisitDetails.getUpdatedAt());
		CanonicalType canonicalType = new CanonicalType();
		canonicalType.setValue("https://emr.ndhm.gov.in/"+patientVisitDetails.getVisitId());
		List<CanonicalType> canonicalLst = new ArrayList<CanonicalType>();
		canonicalLst.add(canonicalType);
		composition.getMeta().setProfile(canonicalLst);
		composition.setLanguage("en-IN");
		composition.getIdentifier().setSystem("https://emr.ndhm.gov.in");
		composition.getIdentifier().setValue(patientVisitDetails.getVisitId()+"");
		composition.setStatus(CompositionStatus.FINAL);
		
		 List<Coding> codeLst1 = new ArrayList<Coding>();
		 Coding coding1 = new Coding();
		 String code = diagnosticReport.getReportFileType();
		 if(code!=null &&  code.equalsIgnoreCase(""))
		 { 
			 coding1.setCode("721981007"); 
			 coding1.setDisplay("Diagnostic studies service"); 
		 } 
		 coding1.setSystem("https://snomedct.ndhm.gov.in/ionic"); 
		 codeLst1.add(coding1);
		 composition.getType().setCoding(codeLst1);
		 composition.getType().setText("Diagnostic Report-Media");
		 composition.getSubject().setReference("Patient/"+patientVisitDetails.getPatient().getPatientId()); 
		 composition.setDate(patientVisitDetails.getUpdatedAt());
		 List<Reference> authorLst =  new ArrayList<Reference>();
		 Reference ref = new Reference();
		 ref.setReference("Practitioner/"+patientVisitDetails.getPractitionerCd());
		 authorLst.add(ref);
		 composition.setAuthor(authorLst);
		 composition.setTitle("Diagnostic Report-Media");
		
		List<SectionComponent> sectionList = new ArrayList<SectionComponent>(); 
		
		SectionComponent section = new SectionComponent();
		section.setTitle("Diagnostic Report-Imaging Media");
		CodeableConcept concept = new CodeableConcept(); 
		concept.addCoding(coding1);
		section.setCode(concept); 
		Reference secRef = new Reference();
		secRef.setReference("DiagnosticReport/"+patientVisitDetails.getVisitId()); 
		section.getEntry().add(secRef); 
		
		sectionList.add(section);
		
		composition.setSection(sectionList);
		
		bundleEntryComponent.setResource(composition);
		return bundleEntryComponent;
	}
	
	@Override
	public Bundle getDiagnosticRequest(PatientVisitDetails patientVisitDetails,Date fromDt,Date toDt) {
		// TODO Auto-generated method stub
		List<PatientDiagnosticReportDetails> setDiagnosticReport = null;
		PatientDiagnosticReportDetails diagnosticReport = null;
		if(patientVisitDetails.getDiagnosticReportYn()!="Y") {
			
			//setDiagnosticReport = patientVisitDetails.getPatientDiagnosticReportDetails();
			setDiagnosticReport = patientDiagnosticReportRepository.findWithVisitIdDateRange(patientVisitDetails.getVisitId(), fromDt, toDt);
		}
		
	
		Bundle bundle = new Bundle();
		if(setDiagnosticReport!=null) {
			
			bundle.setId("Diagnostic-bundle-"+patientVisitDetails.getVisitId());
			bundle.getMeta().setLastUpdated(patientVisitDetails.getUpdatedAt());
			bundle.getIdentifier().setSystem("https://emr.ndhm.gov.in");
			bundle.getIdentifier().setValue(patientVisitDetails.getVisitId()+"");
			bundle.setTimestamp(patientVisitDetails.getUpdatedAt());
			bundle.setType(BundleType.DOCUMENT);
			
			List<BundleEntryComponent> bundleComponentLst = new ArrayList<BundleEntryComponent>();
			
			BundleEntryComponent bundleEntryComponent = new BundleEntryComponent();
			bundleEntryComponent.setFullUrl("Composition/"+patientVisitDetails.getVisitId());
		
			Composition composition = new Composition();
			composition.setId(patientVisitDetails.getVisitId()+"");
			composition.getMeta().setVersionId("1");
			composition.getMeta().setLastUpdated(patientVisitDetails.getUpdatedAt());
			CanonicalType canonicalType = new CanonicalType();
			canonicalType.setValue("https://emr.ndhm.gov.in/"+patientVisitDetails.getVisitId());
			composition.setLanguage("en-IN");
			composition.getIdentifier().setSystem("https://emr.ndhm.gov.in");
			composition.getIdentifier().setValue(patientVisitDetails.getVisitId()+"");
			composition.setStatus(CompositionStatus.FINAL);
			
			 List<Coding> codeLst1 = new ArrayList<Coding>();
			 Coding coding1 = new Coding();
			 coding1.setCode("721981007"); 
			 coding1.setDisplay("Diagnostic studies service"); 
			 coding1.setSystem("https://snomedct.ndhm.gov.in/ionic"); 
			 codeLst1.add(coding1);
			
			 composition.getType().setCoding(codeLst1);
			 composition.getType().setText("Diagnostic Report-Media");
			 composition.getSubject().setReference("Patient/"+patientVisitDetails.getPatient().getPatientId()); 
			 composition.setDate(patientVisitDetails.getUpdatedAt());
			 List<Reference> authorLst =  new ArrayList<Reference>();
			 Reference ref = new Reference();
			 ref.setReference("Practitioner/"+patientVisitDetails.getPractitionerCd());
			 authorLst.add(ref);
			 composition.setAuthor(authorLst);
			 composition.setTitle("Diagnostic Report-Media");
			 
			 List<SectionComponent> sectionList = new ArrayList<SectionComponent>(); 
			 if(setDiagnosticReport!=null) {
					Iterator<PatientDiagnosticReportDetails> iterator = setDiagnosticReport.iterator();
					while(iterator.hasNext()) {
						diagnosticReport = (PatientDiagnosticReportDetails)iterator.next();
						SectionComponent section = new SectionComponent();
						section.setTitle("Diagnostic Report-Imaging Media");
						CodeableConcept concept = new CodeableConcept(); 
						concept.addCoding(coding1);
						section.setCode(concept); 
						Reference secRef = new Reference();
						secRef.setReference("DiagnosticReport/"+diagnosticReport.getId()); 
						section.getEntry().add(secRef); 
						sectionList.add(section);
						//bundleComponentLst.add(getDiagnosticFhirObject(diagnosticReport));
					}
				}
			
			composition.setSection(sectionList);
			
			composition.getText().setStatus(NarrativeStatus.GENERATED);
			composition.getText().setDivAsString("Diagnostic Report");
			bundleEntryComponent.setResource(composition);
			
			bundleComponentLst.add(bundleEntryComponent);
			
			bundleComponentLst.add(getPatientFhirObject(patientVisitDetails.getPatient()));
			bundleComponentLst.add(getOrganisationFhirObject(patientVisitDetails));
			bundleComponentLst.add(getPractitionerFhirObject(patientVisitDetails));
			if(setDiagnosticReport!=null) {
				Iterator<PatientDiagnosticReportDetails> iterator = setDiagnosticReport.iterator();
				while(iterator.hasNext()) {
					diagnosticReport = (PatientDiagnosticReportDetails)iterator.next();
					bundleComponentLst.add(getDiagnosticFhirObject(diagnosticReport));
				}
			}
			bundle.setEntry(bundleComponentLst);
		}
		
		return bundle;
	}
	
	
	@Override
	public BundleEntryComponent getDiagnosticFhirObject(PatientDiagnosticReportDetails patientDiagnosticReportDetails) {
		// TODO Auto-generated method stub
		
		BundleEntryComponent bundleEntryComponent = new BundleEntryComponent();
		bundleEntryComponent.setFullUrl("DiagnosticReport/"+patientDiagnosticReportDetails.getId());
		
		DiagnosticReport diagnosticReport = new DiagnosticReport();
		diagnosticReport.setId(patientDiagnosticReportDetails.getId()+"");
	
		diagnosticReport.getText().setDivAsString("Diagnostic Report");
		diagnosticReport.getText().setStatus(NarrativeStatus.GENERATED);
		diagnosticReport.setStatus(DiagnosticReportStatus.FINAL);
		
		 Identifier identifier = new Identifier();
			identifier.setSystem("https://emr.ndhm.gov.in");
			identifier.setValue(patientDiagnosticReportDetails.getId()+"");
			List<Identifier> list = new ArrayList<Identifier>();
			list.add(identifier);
			diagnosticReport.setIdentifier(list);
			
			//report category
			CodeableConcept concept = new CodeableConcept();
			List<Coding> lstCoding = new ArrayList<Coding>();
			Coding coding = new Coding();
		    String code = patientDiagnosticReportDetails.getReportCategoryValue();
		    if(code!=null) {
		    coding.setCode(patientDiagnosticReportDetails.getReportCategoryValue());
			coding.setDisplay(patientDiagnosticReportDetails.getReportCategory());
			coding.setSystem("https://snomedct.ndhm.gov.in");
		    }
		    
			lstCoding.add(coding);
			concept.setCoding(lstCoding);
			diagnosticReport.getCategory().add(concept);
			
			diagnosticReport.getCode().setText(patientDiagnosticReportDetails.getTestCode());
			
			Reference ref1 =  new Reference();
			ref1.setReference("Patient/"+patientDiagnosticReportDetails.getPatientVisitDetails().getPatient().getPatientId());
			diagnosticReport.setSubject(ref1);
			
			diagnosticReport.setIssued(patientDiagnosticReportDetails.getUpdatedAt());
			
			List<Reference> thePerformer = new ArrayList<Reference>();
			Reference ref3 =  new Reference();
			ref3.setReference("Organization/"+patientDiagnosticReportDetails.getPatientVisitDetails().getFacilityCd());
			ref3.setDisplay(patientDiagnosticReportDetails.getPatientVisitDetails().getFacilityName());
			thePerformer.add(ref3);
			diagnosticReport.setPerformer(thePerformer);
			
			List<Reference> theResultsInterpreter = new ArrayList<Reference>();
			Reference ref2 =  new Reference();
			ref2.setReference("Practitioner/"+patientDiagnosticReportDetails.getPatientVisitDetails().getPractitionerCd());
			ref2.setDisplay(patientDiagnosticReportDetails.getPatientVisitDetails().getPractitionerName());
			theResultsInterpreter.add(ref2);
			diagnosticReport.setResultsInterpreter(theResultsInterpreter);
			diagnosticReport.setConclusion(patientDiagnosticReportDetails.getReportConclusion());
			Long visitId = patientDiagnosticReportDetails.getId();
			
			List<DiagnosticAttachment> lstDiagnostic =  attachmentRepository.findWithVisitId(visitId);
			List<Attachment> thePresentedForm =  new ArrayList<Attachment>();
			
			Iterator<DiagnosticAttachment> iteratorLst = lstDiagnostic.listIterator();
			String filePath=null;
			String fileExt = null;
			String lStrContentType = "";
			while(iteratorLst!=null && iteratorLst.hasNext()) {
				DiagnosticAttachment diagnosticAttachment = iteratorLst.next();
				filePath = diagnosticAttachment.getReportFilePath();
				Attachment attach = new Attachment();
				fileExt = filePath.substring((filePath.lastIndexOf(".") + 1));
				if (fileExt.equalsIgnoreCase("jpg") || fileExt.equalsIgnoreCase("jpeg") || fileExt.equalsIgnoreCase("png"))
				{
					lStrContentType="image/jpeg";
				}
				if (fileExt.equalsIgnoreCase("pdf"))
				{
					lStrContentType="application/pdf";
				}
				attach.setContentType(lStrContentType);
				attach.setLanguage("en-IN");
				attach.setTitle(patientDiagnosticReportDetails.getTestCodeValue());
				byte[] bytestream = getBase64(filePath);
				attach.setData(bytestream);
				//attach.setSize(bytestream.length);
				thePresentedForm.add(attach);
			}
			
			diagnosticReport.setPresentedForm(thePresentedForm);
			bundleEntryComponent.setResource(diagnosticReport);
		
		return bundleEntryComponent;
	}

    
	private byte[] getBase64(String path) {
		byte imageData[] =null;
		File file = new File(path);
		File file1 = new File("/storageNAS/file_area/emrweb/emr.png");
		
	    try (FileInputStream imageInFile = new FileInputStream(file)) {
	      imageData = new byte[(int) file.length()];
	      imageInFile.read(imageData);
	    } catch (FileNotFoundException e) {
	    	imageData = null;
	      System.out.println("Image not found" + e);
	    } catch (IOException ioe) {
	    	imageData = null;
	      System.out.println("Exception while reading the Image " + ioe);
	    }
	  return imageData;
	}


	@Override
	public BundleEntryComponent getOpNotesFhirObject(PatientClinicalNotesDetails clinicalNotesDetails) {
		// TODO Auto-generated method stub
		return null;
	}



	@Override
	public Bundle getConsulingNoteRequest(PatientVisitDetails patientVisitDetails,Date fromDt,Date toDt) {
		// TODO Auto-generated method stub
		
		// TODO Auto-generated method stub
				List<PatientClinicalNotesDetails> setPatientClinicalNotesDetails = patientClinicalNotesRepository.findWithVisitIdWithDateRange(patientVisitDetails.getVisitId(), fromDt, toDt);
						//patientVisitDetails.getPatientClinicalNotesDetails();
				PatientClinicalNotesDetails patientClinicalNotesDetails = null;
				if(setPatientClinicalNotesDetails!=null) {
					Iterator<PatientClinicalNotesDetails> iteratorNotes =  setPatientClinicalNotesDetails.iterator();
					while(iteratorNotes.hasNext()) {
						patientClinicalNotesDetails = iteratorNotes.next();
					}
				}
				Bundle bundle = new Bundle();
				bundle.setId("bundle-"+patientVisitDetails.getVisitId());
				bundle.getMeta().setLastUpdated(patientVisitDetails.getUpdatedAt());
				bundle.getIdentifier().setSystem("https://emrweb.ndhm.nha.gov.in");
				bundle.getIdentifier().setValue(patientVisitDetails.getVisitId()+"");
				bundle.setTimestamp(patientVisitDetails.getUpdatedAt());
				bundle.setType(BundleType.DOCUMENT);
				
				if(patientClinicalNotesDetails!=null) {
					
					BundleEntryComponent bundleEntryComponent = new BundleEntryComponent();
					bundleEntryComponent.setFullUrl("Composition/"+patientVisitDetails.getVisitId());
				
					Composition composition = new Composition();
					composition.setId(patientVisitDetails.getVisitId()+"");
					composition.getMeta().setVersionId("1");
					composition.getMeta().setLastUpdated(patientVisitDetails.getUpdatedAt());
					CanonicalType canonicalType = new CanonicalType();
					canonicalType.setValue("http://nrces.in/ndhm/fhir/r4/StructureDefinition/OPConsultRecord");
					List<CanonicalType> canonicalLst = new ArrayList<CanonicalType>();
					composition.getMeta().setProfile(canonicalLst);
					composition.setLanguage("en-IN");
					composition.getIdentifier().setSystem("https://emrweb.ndhm.nha.gov.in");
					composition.getIdentifier().setValue(patientVisitDetails.getVisitId()+"");
					composition.setStatus(CompositionStatus.FINAL);
					composition.getText().setDivAsString("OP consultation record");
					composition.getText().setStatus(NarrativeStatus.GENERATED);
					composition.getMeta().addSecurity().setCode("V").setDisplay("Very Restricted").setSystem("http://terminology.hl7.org/CodeSystem/v3-Confidentiality");
					
					composition.addAuthor().setReference("Practitioner/"+patientVisitDetails.getPractitionerCd()).setDisplay(patientVisitDetails.getPractitionerName());
					
					 List<Coding> codeLst1 = new ArrayList<Coding>();
					 Coding coding1 = new Coding();
					  coding1.setCode("371530004");
					  coding1.setDisplay("Clinical Consultation Report"); 
					  coding1.setSystem("https://snomedct.ndhm.gov.in");
					  codeLst1.add(coding1);
					 composition.getType().setCoding(codeLst1);
					 composition.getType().setText("Clinical Consultation Report");
					
					 composition.getSubject().setReference("Patient/"+patientVisitDetails.getPatient().getPatientId());
					 composition.getEncounter().setReference("Encounter/"+patientVisitDetails.getVisitId());
					 composition.addAuthor().setReference("Practitioner/"+patientVisitDetails.getPractitionerCd()).setDisplay(patientVisitDetails.getPractitionerName());
					 composition.setDate(patientVisitDetails.getUpdatedAt());
					 composition.setTitle("Consultation Report");
					 
					 Reference ref1 = new Reference();
					 ref1.setReference("Organization/"+patientVisitDetails.getFacilityCd());
					 ref1.setDisplay(patientVisitDetails.getFacilityName());
					 composition.setCustodian(ref1);
					 
					List<SectionComponent> sectionList = new ArrayList<SectionComponent>(); 
					
					
					
					if(patientClinicalNotesDetails.getReportType()!=null && patientClinicalNotesDetails.getReportType().equalsIgnoreCase("OL")) {
						SectionComponent sectionAllergy = new SectionComponent();
						sectionAllergy.setTitle("Allergy");
						Reference refAllergy = new Reference();
						refAllergy.setReference("AllergyIntolerance/"+patientVisitDetails.getVisitId()); 
						sectionAllergy.getCode().addCoding().setCode("417662000").setDisplay("History of clinical finding in subject").setSystem("https://snomedct.ndhm.gov.in");
						sectionAllergy.getEntry().add(refAllergy); 
						sectionList.add(sectionAllergy);
						
						SectionComponent sectionMedicalHistory = new SectionComponent();
						sectionMedicalHistory.setTitle("Medical History");
						Reference refMedicalHistory = new Reference();
						refMedicalHistory.setReference("Condition/1"+patientVisitDetails.getVisitId()); 
						sectionMedicalHistory.getCode().addCoding().setCode("417662000").setDisplay("History of clinical finding in subject").setSystem("https://snomedct.ndhm.gov.in");
						
						sectionMedicalHistory.getEntry().add(refMedicalHistory); 
						sectionList.add(sectionMedicalHistory);
						
						SectionComponent sectionSymptoms = new SectionComponent();
						sectionSymptoms.setTitle("Symptoms");
						Reference refSymptoms = new Reference();
						refSymptoms.setReference("Condition/2"+patientVisitDetails.getVisitId()); 
						sectionSymptoms.getCode().addCoding().setCode("417662000").setDisplay("History of clinical finding in subject").setSystem("https://snomedct.ndhm.gov.in");
						
						sectionSymptoms.getEntry().add(refSymptoms); 
						sectionList.add(sectionSymptoms);
						
						SectionComponent sectionObservations = new SectionComponent();
						sectionObservations.setTitle("Observations");
						Reference refObservations = new Reference();
						refObservations.setReference("Procedure/"+patientVisitDetails.getVisitId()); 
						sectionObservations.getCode().addCoding().setCode("223493006").setDisplay("Documenting observations").setSystem("https://snomedct.ndhm.gov.in");
						
						sectionObservations.getEntry().add(refObservations); 
						sectionList.add(sectionObservations);
						
						SectionComponent sectionDiagnosis = new SectionComponent();
						sectionDiagnosis.setTitle("Final Diagnosis");
						Reference refDiagnosis = new Reference();
						refDiagnosis.setReference("Condition/3"+patientVisitDetails.getVisitId()); 
						sectionDiagnosis.getCode().addCoding().setCode("417662000").setDisplay("History of clinical finding in subject").setSystem("https://snomedct.ndhm.gov.in");
						
						sectionDiagnosis.getEntry().add(refDiagnosis); 
						sectionList.add(sectionDiagnosis);
						
						
						SectionComponent sectionPlan = new SectionComponent();
						sectionPlan.setTitle("Treatment Plan"); 
						Reference refPlan = new Reference();
						refPlan.setReference("CarePlan/1"+patientVisitDetails.getVisitId());
						sectionPlan.getCode().addCoding().setCode("417662000").setDisplay("History of clinical finding in subject").setSystem("https://snomedct.ndhm.gov.in");
						
						sectionPlan.getEntry().add(refPlan); 
						sectionList.add(sectionPlan);
						
						
						SectionComponent sectionMedications = new SectionComponent();
						sectionMedications.setTitle("Prescription");
						Reference refMedication = new Reference();
						refMedication.setReference("MedicationRequest/"+patientVisitDetails.getVisitId()); 
						sectionMedications.getCode().addCoding().setCode("182816009").setDisplay("Therapeutic prescription").setSystem("https://snomedct.ndhm.gov.in");
						sectionMedications.getEntry().add(refMedication); 
						sectionList.add(sectionMedications);
					}else
					{
						SectionComponent documentRef = new SectionComponent();
						documentRef.setTitle("Document Attachment");
						Coding codingDocRef = new Coding();
						codingDocRef.setCode("371530004");
						codingDocRef.setDisplay("Clinical Consultation report");
						codingDocRef.setSystem("http://snomed.info/sct");
						
						Reference docRef = new Reference();
						docRef.setReference("DocumentReference/"+patientClinicalNotesDetails.getId());
						documentRef.getEntry().add(docRef); 
						sectionList.add(documentRef);
					}
					
					composition.setSection(sectionList);
					bundleEntryComponent.setResource(composition);
					
					List<BundleEntryComponent> bundleComponentLst = new ArrayList<BundleEntryComponent>();
					bundleComponentLst.add(bundleEntryComponent);
					
					bundleComponentLst.add(getPatientFhirObject(patientVisitDetails.getPatient()));
					bundleComponentLst.add(getEncounterFhirObject(patientVisitDetails));
					bundleComponentLst.add(getPractitionerFhirObject(patientVisitDetails));
					bundleComponentLst.add(getOrganisationFhirObject(patientVisitDetails));
					
					if(patientClinicalNotesDetails.getReportType()!=null && patientClinicalNotesDetails.getReportType().equalsIgnoreCase("OL")) {
						BundleEntryComponent conditionAllergy = new BundleEntryComponent();
						
						conditionAllergy.setFullUrl("AllergyIntolerance/"+patientVisitDetails.getVisitId());
						AllergyIntolerance alleryResource =  new AllergyIntolerance();
						alleryResource.setId(patientClinicalNotesDetails.getId()+"");
						
						Reference patRef = new Reference();
						patRef.setReference("Patient/"+patientVisitDetails.getPatient().getPatientId());
						alleryResource.setPatient(patRef);
						alleryResource.getClinicalStatus().addCoding().setCode("active").setDisplay("Active").setSystem("http://terminology.hl7.org/CodeSystem/allergyintolerance-clinical");
						
						Annotation noteAnno = new Annotation();
						noteAnno.setText(patientClinicalNotesDetails.getAllergy());
						alleryResource.getNote().add(noteAnno);
						conditionAllergy.setResource(alleryResource);
						bundleComponentLst.add(conditionAllergy);
						
						
						BundleEntryComponent medicalHistoryResource = new BundleEntryComponent(); //This should be added
						medicalHistoryResource.setFullUrl("Condition/1"+patientVisitDetails.getVisitId());
						Condition condition1 = new Condition();
						condition1.setId("1"+patientVisitDetails.getVisitId());
						condition1.setSubject(patRef);
						
						CodeableConcept concept = new CodeableConcept();
						condition1.setCode(concept.setText(patientClinicalNotesDetails.getHistory()));
						medicalHistoryResource.setResource(condition1);
						
						BundleEntryComponent symptomsResource = new BundleEntryComponent();//This should be added
						symptomsResource.setFullUrl("Condition/2"+patientVisitDetails.getVisitId());
						Condition condition2 = new Condition();
						condition2.setId("2"+patientVisitDetails.getVisitId());
						
						condition2.setSubject(patRef);
						CodeableConcept concept1 = new CodeableConcept();
						condition2.setCode(concept1.setText(patientClinicalNotesDetails.getSymptoms()));
						symptomsResource.setResource(condition2);
						
						
						BundleEntryComponent diagnosisResource = new BundleEntryComponent();//This should be added
						diagnosisResource.setFullUrl("Condition/3"+patientVisitDetails.getVisitId());
						Condition condition3 = new Condition();
						condition3.setId("3"+patientVisitDetails.getVisitId());
						
						condition3.setSubject(patRef);
						CodeableConcept concept3 = new CodeableConcept();
						condition3.setCode(concept3.setText(patientClinicalNotesDetails.getDiagnosis()));
						diagnosisResource.setResource(condition3);
						
						
						BundleEntryComponent carepalnResource = new BundleEntryComponent();
						carepalnResource.setFullUrl("CarePlan/1"+patientVisitDetails.getVisitId());
						CarePlan carePlan = new CarePlan();
						carePlan.setId("1"+patientVisitDetails.getVisitId()+"");
						carePlan.setStatus(CarePlanStatus.ACTIVE);
						carePlan.setIntent(CarePlanIntent.PLAN);
						carePlan.addNote().setText(patientClinicalNotesDetails.getTreatmentPlan());
						carePlan.setSubject(patRef);
						carepalnResource.setResource(carePlan);
						
						BundleEntryComponent observationResource = new BundleEntryComponent();
						observationResource.setFullUrl("Procedure/"+patientVisitDetails.getVisitId());
						Procedure procedure = new Procedure();
						procedure.setId(patientVisitDetails.getVisitId()+"");
						procedure.setStatus(ProcedureStatus.COMPLETED);
						procedure.setSubject(patRef);
						procedure.addNote().setText(patientClinicalNotesDetails.getVitals());
						observationResource.setResource(procedure);
					
						
						BundleEntryComponent medicationResource = new BundleEntryComponent();
						medicationResource.setFullUrl("MedicationRequest/"+patientVisitDetails.getVisitId());
						MedicationRequest medicationRequest = new MedicationRequest();
						medicationRequest.setId(patientVisitDetails.getVisitId()+"");
						medicationRequest.setSubject(patRef);
						medicationRequest.setStatus(MedicationRequestStatus.ACTIVE);
						medicationRequest.setIntent(MedicationRequestIntent.ORDER);
						medicationRequest.getMedicationCodeableConcept().setText(patientClinicalNotesDetails.getPrescription());
						medicationResource.setResource(medicationRequest);
					
						bundleComponentLst.add(medicationResource);
						bundleComponentLst.add(observationResource);
						bundleComponentLst.add(carepalnResource);
						bundleComponentLst.add(diagnosisResource);
						bundleComponentLst.add(symptomsResource);
						bundleComponentLst.add(medicalHistoryResource);
					}else {
						
						BundleEntryComponent documentReferenceComp = new BundleEntryComponent();//This should be added
						// TODO Auto-generated method stub
						documentReferenceComp.setFullUrl("DocumentReference/"+patientClinicalNotesDetails.getId());
						DocumentReference  documentReference= new DocumentReference();
						documentReference.setId(patientClinicalNotesDetails.getId().toString());
						documentReference.getText().setStatus(NarrativeStatus.GENERATED).setDivAsString("Docuemt Reference Resource");
						documentReference.setStatus(DocumentReferenceStatus.CURRENT);
						documentReference.setDocStatus(ReferredDocumentStatus.FINAL);
						documentReference.getType().addCoding().setSystem("https://snomedct.ndhm.gov.in/loinc").setCode("371530004").setDisplay("Clinical Consultation report");	
						documentReference.getType().setText("Clinical Consultation report");
						documentReference.getSubject().setReference("Patient/"+patientVisitDetails.getPatient());
						DocumentReferenceContentComponent documentReferenceContentComponent = new DocumentReferenceContentComponent();
						Attachment attach = new Attachment();
						String fileExt = null;
						String filePath=null;
						String contentType = null;
						if(patientClinicalNotesDetails!=null && patientClinicalNotesDetails.getReportType()!=null) {
							filePath = patientClinicalNotesDetails.getAttachPath();
							fileExt = filePath.substring((filePath.lastIndexOf(".") + 1));
							if (fileExt.equalsIgnoreCase("jpg") || fileExt.equalsIgnoreCase("jpeg") || fileExt.equalsIgnoreCase("png"))
							{
								contentType="image/jpeg";
							}
							if (fileExt.equalsIgnoreCase("pdf"))
							{
								contentType="application/pdf";
							}
							attach.setContentType(contentType);
							attach.setLanguage("en-IN");
							attach.setTitle("Clinical Consultation report");
							byte[] bytestream = getBase64(filePath);
							if(bytestream!=null) {
							attach.setData(bytestream);
							attach.setSize(bytestream.length);
							attach.setTitle("Clinical Consultation report");
							attach.setCreation(patientClinicalNotesDetails.getCreatedAt());
							}else {
								attach.setData(null);
								attach.setSize(0);
								attach.setTitle("No data");
							}
							documentReferenceContentComponent.setAttachment(attach);
						}
						
				        documentReference.getContent().add(documentReferenceContentComponent);
						documentReferenceComp.setResource(documentReference);
						bundleComponentLst.add(documentReferenceComp);
					
					}
					
					
					bundle.setEntry(bundleComponentLst);
				}
		
		return bundle;
	}


	@Override
	public BundleEntryComponent getDischargeSummaryFhirObject(PatientDischargeDetails patientDischargeDetails) {
		// TODO Auto-generated method stub
		return null;
	}




	@Override
	public Bundle getDischargeRequest(PatientVisitDetails patientVisitDetails,Date fromDt,Date toDt) {
		// TODO Auto-generated method stub
		
		// TODO Auto-generated method stub
		List<PatientDischargeDetails> setDischargeDetails = null;
		PatientDischargeDetails dischargeDetails = null;
		if(patientVisitDetails.getDischargeSummaryYn()!="Y") {
			setDischargeDetails = patientDischargeRepository.findWithVisitIdDateRange(patientVisitDetails.getVisitId(), fromDt, toDt);
					//patientVisitDetails.getPatientDischargeDetails();
		}
		if(setDischargeDetails!=null) {
			//dischargeDetails = setDischargeDetails.iterator().next();
			Iterator<PatientDischargeDetails> iteratorDis = setDischargeDetails.iterator();
			while(iteratorDis.hasNext()) {
				dischargeDetails = iteratorDis.next();
			}
		}
		
		Bundle bundle = new Bundle();
		bundle.setId("bundle-"+patientVisitDetails.getVisitId());
		bundle.getMeta().setLastUpdated(patientVisitDetails.getUpdatedAt());
		bundle.getIdentifier().setSystem("https://emrweb.ndhm.nha.gov.in");
		bundle.getIdentifier().setValue(patientVisitDetails.getVisitId()+"");
		bundle.setTimestamp(patientVisitDetails.getUpdatedAt());
		bundle.setType(BundleType.DOCUMENT);
		
		List<BundleEntryComponent> bundleComponentLst = new ArrayList<BundleEntryComponent>();
		if(dischargeDetails!=null) {
			
			BundleEntryComponent bundleEntryComposition = new BundleEntryComponent();
			bundleEntryComposition.setFullUrl("Composition/"+patientVisitDetails.getVisitId());
		
			Composition composition = new Composition();
			composition.setId(patientVisitDetails.getVisitId()+"");
			composition.getMeta().setVersionId("1");
			composition.getMeta().setLastUpdated(patientVisitDetails.getUpdatedAt());
			CanonicalType canonicalType = new CanonicalType();
			canonicalType.setValue("http://nrces.in/ndhm/fhir/r4/StructureDefinition/DischargeSummaryRecord");
			List<CanonicalType> canonicalLst = new ArrayList<CanonicalType>();
			composition.getMeta().setProfile(canonicalLst);
			composition.setLanguage("en-IN");
			composition.getText().setStatus(NarrativeStatus.GENERATED).setDivAsString("Discharge Summary"); 
			composition.getIdentifier().setSystem("https://emrweb.ndhm.nha.gov.in");
			composition.getIdentifier().setValue(patientVisitDetails.getVisitId()+"");
			composition.setStatus(CompositionStatus.FINAL);
			
			
			 List<Coding> codeLst1 = new ArrayList<Coding>();
			 Coding coding1 = new Coding();
			 coding1.setCode("373942005");
			 coding1.setDisplay("Discharge Summary Report"); 
			 coding1.setSystem("http://snomed.info/sct"); 
			 codeLst1.add(coding1);
			 composition.getType().setCoding(codeLst1);
			 composition.getType().setText("Discharge Summary Report");
			
			 composition.getSubject().setReference("Patient/"+patientVisitDetails.getPatient().getPatientId());
			 composition.getEncounter().setReference("Encounter/"+patientVisitDetails.getVisitId());
			 composition.setDate(patientVisitDetails.getUpdatedAt());
			 
			 List<Reference> authorLst =  new ArrayList<Reference>();
			 Reference ref = new Reference();
			 ref.setReference("Practitioner/"+patientVisitDetails.getPractitionerCd());
			 authorLst.add(ref);
			 composition.setAuthor(authorLst);
			 composition.setTitle("Discharge Summary Report");
			 composition.setConfidentiality(DocumentConfidentiality.N);
			 
			 Reference ref1 = new Reference();
			 ref1.setReference("Organization/"+patientVisitDetails.getFacilityCd());
			 ref1.setDisplay(patientVisitDetails.getFacilityName());
			 composition.setCustodian(ref1);
			 
			List<SectionComponent> sectionList = new ArrayList<SectionComponent>(); 
			String mode =dischargeDetails.getReportType();
			
			if(mode!=null && mode.equalsIgnoreCase("OL")) {
			

				SectionComponent sectionCompliants = new SectionComponent();
				sectionCompliants.setTitle("Chief complaints");
				Coding coding = new Coding();
				coding.setCode("422843007");
				coding.setDisplay("Chief complaint section");
				coding.setSystem("http://snomed.info/sct");
				sectionCompliants.getCode().addCoding(coding);
				
				Reference refComplaints = new Reference();
				refComplaints.setReference("Condition/1"+patientVisitDetails.getVisitId()); 
				sectionCompliants.getEntry().add(refComplaints); 
				sectionList.add(sectionCompliants);
			
				
				SectionComponent sectionMedicalHistory = new SectionComponent();
				sectionMedicalHistory.setTitle("Medical History");
				Coding codingMed = new Coding();
				codingMed.setCode("417662000");
				codingMed.setDisplay("History of clinical finding in subject");
				codingMed.setSystem("http://snomed.info/sct");
				sectionMedicalHistory.getCode().addCoding(codingMed);
				Reference refMedicalHistory = new Reference();
				refMedicalHistory.setReference("Condition/2"+patientVisitDetails.getVisitId()); 
				sectionMedicalHistory.getEntry().add(refMedicalHistory); 
				sectionList.add(sectionMedicalHistory);
				
				SectionComponent sectionDiagnosis = new SectionComponent();
				sectionDiagnosis.setTitle("Final Diagnosis");
				Reference refDiagnosis = new Reference();
				refDiagnosis.setReference("Condition/3"+patientVisitDetails.getVisitId()); 
				//sectionDiagnosis.getCode().addCoding(codingMed);
				sectionDiagnosis.getEntry().add(refDiagnosis); 
				sectionList.add(sectionDiagnosis);
				
				SectionComponent sectionProcedure = new SectionComponent();
				sectionProcedure.setTitle("Procedures Performed");
				Coding codingProced = new Coding();
				codingProced.setCode("371525003");
				codingProced.setDisplay("Clinical procedure report");
				codingProced.setSystem("http://snomed.info/sct");
				sectionProcedure.getCode().addCoding(codingProced);
				Reference refProced = new Reference();
				refProced.setReference("Procedure/1"+patientVisitDetails.getVisitId()); 
				sectionProcedure.getEntry().add(refProced); 
				sectionList.add(sectionProcedure);
			
				SectionComponent sectionTreatment = new SectionComponent();
				sectionTreatment.setTitle("Medications");
				Coding codingMedications = new Coding();
				codingMedications.setCode("721912009");
				codingMedications.setDisplay("Medication summary document");
				codingMedications.setSystem("http://snomed.info/sct");
				sectionTreatment.getCode().addCoding(codingMedications);
				Reference refMedication = new Reference();
				refMedication.setReference("MedicationRequest/"+patientVisitDetails.getVisitId()); 
				sectionTreatment.getEntry().add(refMedication); 
				sectionList.add(sectionTreatment);
				
				SectionComponent sectionPlan = new SectionComponent();
				sectionPlan.setTitle("Care Plan");
				Coding codingCarePlan = new Coding();
				codingCarePlan.setCode("734163000");
				codingCarePlan.setDisplay("Care plan");
				codingCarePlan.setSystem("http://snomed.info/sct");
				sectionPlan.getCode().addCoding(codingCarePlan);
				
				Reference refPlan = new Reference();
				refPlan.setReference("CarePlan/"+patientVisitDetails.getVisitId()); 
				sectionPlan.getEntry().add(refPlan); 
				sectionList.add(sectionPlan);
				
			}else {
				SectionComponent documentRef = new SectionComponent();
				documentRef.setTitle("Document Reference");
				Coding codingDocRef = new Coding();
				codingDocRef.setCode("373942005");
				codingDocRef.setDisplay("Discharge Summary");
				codingDocRef.setSystem("http://snomed.info/sct");
				
				Reference docRef = new Reference();
				docRef.setReference("DocumentReference/"+dischargeDetails.getId());
				documentRef.getEntry().add(docRef); 
				sectionList.add(documentRef);
			}
			
			composition.setSection(sectionList);
			bundleEntryComposition.setResource(composition);
			bundleComponentLst.add(bundleEntryComposition);
			bundleComponentLst.add(getPatientFhirObject(patientVisitDetails.getPatient()));
			//bundleComponentLst.add(getEncounterFhirObject(patientVisitDetails));
			bundleComponentLst.add(getPractitionerFhirObject(patientVisitDetails));
			bundleComponentLst.add(getOrganisationFhirObject(patientVisitDetails));
			
			BundleEntryComponent bundleEntryComponentEncounter = new BundleEntryComponent();
			Encounter encounter = new Encounter();
			bundleEntryComponentEncounter.setFullUrl("Encounter/"+patientVisitDetails.getVisitId());
			
			encounter.setId(patientVisitDetails.getVisitId()+"");
			encounter.getMeta().setVersionId("1");
			encounter.getMeta().setLastUpdated(patientVisitDetails.getVisitDt());
			
			Identifier identifier = new Identifier();
			identifier.setSystem("https://emr.ndhm.gov.in");
			identifier.setValue(patientVisitDetails.getVisitId()+"");
			List<Identifier> list = new ArrayList<Identifier>();
			list.add(identifier);
			encounter.setIdentifier(list);
			encounter.setStatus(EncounterStatus.UNKNOWN);
			
			 Coding coding = new Coding();
			 coding.setCode(patientVisitDetails.getVisitType());
			 coding.setSystem("http://snomedct.ndhm.gov.in");
			 if(patientVisitDetails.getVisitType()!=null && patientVisitDetails.getVisitType().equalsIgnoreCase("OP")) {
				 coding.setDisplay("Out patient");
			 }else if(patientVisitDetails.getVisitType()!=null && patientVisitDetails.getVisitType().equalsIgnoreCase("IP")) {
				 coding.setDisplay("In patient");
			 }else if(patientVisitDetails.getVisitType()!=null && patientVisitDetails.getVisitType().equalsIgnoreCase("ER")) {
				 coding.setDisplay("Emergency");
			 }else {
				 coding.setDisplay("Day Care");
			 }
			 
			 Period period = new Period();
			 if(dischargeDetails.getAdmissionDateTime()!=null && dischargeDetails.getDischargeDateTime()!=null) {
				 period.setStart(dischargeDetails.getAdmissionDateTime());
				 period.setEnd(dischargeDetails.getDischargeDateTime());
				 encounter.setPeriod(period);
			 }else {
				 period.setStart(dischargeDetails.getCreatedAt());
				 period.setEnd(dischargeDetails.getUpdatedAt());
			 }
			
			 
			 encounter.setClass_(coding) ;
			 encounter.getText().setStatus(org.hl7.fhir.r4.model.Narrative.NarrativeStatus.GENERATED);
			 encounter.getText().setDivAsString("Encounter Resource");
			 
			 bundleEntryComponentEncounter.setResource(encounter);
			 bundleComponentLst.add(bundleEntryComponentEncounter);
			 
	        
			if(mode!=null && mode.equalsIgnoreCase("OL")) {
				
				if(dischargeDetails.getFollowUp()!=null && !dischargeDetails.getFollowUp().equalsIgnoreCase("") ) {
				try {
					BundleEntryComponent bundleEntryComponentEncounter2 = new BundleEntryComponent();
					Appointment appointment = new Appointment();
					bundleEntryComponentEncounter2.setFullUrl("Appointment/"+patientVisitDetails.getVisitId());
					appointment.setId(patientVisitDetails.getVisitId()+"");
					appointment.getMeta().setVersionId("1");
					appointment.getMeta().setLastUpdated(patientVisitDetails.getVisitDt());
					
					Identifier identifier1 = new Identifier();
					identifier1.setSystem("https://emr.ndhm.gov.in");
					identifier1.setValue(patientVisitDetails.getVisitId()+"");
					List<Identifier> list1 = new ArrayList<Identifier>();
					list1.add(identifier1);
					appointment.setIdentifier(list1);
					appointment.setStatus(AppointmentStatus.BOOKED);
					appointment.setStart(new SimpleDateFormat("dd/MM/yyyy").parse(dischargeDetails.getFollowUp()));
					appointment.setEnd(new SimpleDateFormat("dd/MM/yyyy").parse(dischargeDetails.getFollowUp()));
					AppointmentParticipantComponent participantComponent1 = new AppointmentParticipantComponent();
					participantComponent1.getActor().setReference("Patient/"+patientVisitDetails.getPatient().getPatientId()).setDisplay(patientVisitDetails.getPatient().getFirstName());
					participantComponent1.setStatus(ParticipationStatus.ACCEPTED);
					appointment.getParticipant().add(participantComponent1);
					
					AppointmentParticipantComponent participantComponent2 = new AppointmentParticipantComponent();
					participantComponent2.getActor().setReference("Practitioner/"+patientVisitDetails.getPractitionerCd()).setDisplay(patientVisitDetails.getPractitionerCd());
					participantComponent2.setStatus(ParticipationStatus.ACCEPTED);
					appointment.getParticipant().add(participantComponent2);
					appointment.setCreated(dischargeDetails.getCreatedAt());
					bundleEntryComponentEncounter2.setResource(appointment);
					bundleComponentLst.add(bundleEntryComponentEncounter2);
				} catch (ParseException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				}
				
				
				BundleEntryComponent condition1Resource = new BundleEntryComponent(); 
				condition1Resource.setFullUrl("Condition/1"+patientVisitDetails.getVisitId());
				Condition condition1 = new Condition();
				condition1.setId("1"+patientVisitDetails.getVisitId());
				condition1.getSubject().setReference("Patient/"+patientVisitDetails.getPatient().getPatientId()).setDisplay(patientVisitDetails.getPatient().getFirstName());
				CodeableConcept concept = new CodeableConcept();
				condition1.setCode(concept.setText(dischargeDetails.getComplaints()));
				condition1Resource.setResource(condition1);
				
				BundleEntryComponent condition2Resource = new BundleEntryComponent();//This should be added
				condition2Resource.setFullUrl("Condition/2"+patientVisitDetails.getVisitId());
				Condition condition2 = new Condition();
				condition2.setId("2"+patientVisitDetails.getVisitId());
				condition2.getSubject().setReference("Patient/"+patientVisitDetails.getPatient().getPatientId()).setDisplay(patientVisitDetails.getPatient().getFirstName());
				CodeableConcept concept1 = new CodeableConcept();
				condition2.setCode(concept1.setText(dischargeDetails.getNotes())); //This needs to be verified
				condition2.getSubject().setReference("Patient/"+patientVisitDetails.getPatient().getPatientId()).setDisplay(patientVisitDetails.getPatient().getFirstName());
				condition2Resource.setResource(condition2);
				
				BundleEntryComponent condition3Resource = new BundleEntryComponent();//This should be added
				condition3Resource.setFullUrl("Condition/3"+patientVisitDetails.getVisitId());
				Condition condition3 = new Condition();
				condition3.setId("3"+patientVisitDetails.getVisitId());
				condition3.getSubject().setReference("Patient/"+patientVisitDetails.getPatient().getPatientId()).setDisplay(patientVisitDetails.getPatient().getFirstName());
				CodeableConcept concept3 = new CodeableConcept();
				condition3.setCode(concept3.setText(dischargeDetails.getDiagnosis()));
				condition3Resource.setResource(condition3);
				
				BundleEntryComponent carepalnResource = new BundleEntryComponent();
				carepalnResource.setFullUrl("CarePlan/"+patientVisitDetails.getVisitId());
				CarePlan carePlan = new CarePlan();
				carePlan.setId(patientVisitDetails.getVisitId()+"");
				carePlan.setStatus(CarePlanStatus.ACTIVE);
				carePlan.setDescription(dischargeDetails.getAdviceDischarge());
				carePlan.setSubject(new Reference().setReference("Patient/"+patientVisitDetails.getPatient().getPatientId()).setDisplay("Patient/"+patientVisitDetails.getPatient().getPatientId()));
				carePlan.setIntent(CarePlanIntent.PLAN);
				if(dischargeDetails.getFollowUp()!=null && !dischargeDetails.getFollowUp().equalsIgnoreCase("")) {
					carePlan.addActivity().addOutcomeReference().setReference("Appointment/"+patientVisitDetails.getVisitId());
				}
				carepalnResource.setResource(carePlan);
				
				BundleEntryComponent procedure1Resource = new BundleEntryComponent();
				procedure1Resource.setFullUrl("Procedure/1"+patientVisitDetails.getVisitId());
				Procedure procedure = new Procedure();
				procedure.setId("1"+patientVisitDetails.getVisitId());
				procedure.getText().setStatus(NarrativeStatus.GENERATED).setDivAsString(dischargeDetails.getProcedureDone());
				procedure.getCode().setText(dischargeDetails.getProcedureDone());
				procedure.setSubject(new Reference().setDisplay("Patient/"+patientVisitDetails.getPatient().getPatientId()));
				procedure.getPerformedDateTimeType().setValue(dischargeDetails.getCreatedAt());
				procedure.setStatus(ProcedureStatus.COMPLETED);
				procedure1Resource.setResource(procedure);
				
				BundleEntryComponent medicationResource = new BundleEntryComponent();
				medicationResource.setFullUrl("MedicationRequest/"+patientVisitDetails.getVisitId());
				MedicationRequest medication = new MedicationRequest();
				medication.setId(patientVisitDetails.getVisitId()+"");
				medication.getSubject().setReference("Patient/"+patientVisitDetails.getPatient().getPatientId()).setDisplay(patientVisitDetails.getPatient().getFirstName());
				medication.setStatus(MedicationRequestStatus.ACTIVE);
				medication.setIntent(MedicationRequestIntent.ORDER);
				medication.getMedicationCodeableConcept().setText(dischargeDetails.getTreatmentGiven());
				//medication.getMedication().setId(patientVisitDetails.getVisitId()+"");
				medicationResource.setResource(medication);
				
				bundleComponentLst.add(carepalnResource);
				bundleComponentLst.add(condition1Resource);
				bundleComponentLst.add(condition2Resource);
				bundleComponentLst.add(condition3Resource);
				
				bundleComponentLst.add(procedure1Resource);
				bundleComponentLst.add(medicationResource);
					
			}else {
				
				BundleEntryComponent documentReferenceComp = new BundleEntryComponent();//This should be added
				// TODO Auto-generated method stub
				documentReferenceComp.setFullUrl("DocumentReference/"+dischargeDetails.getId());
				DocumentReference  documentReference= new DocumentReference();
				documentReference.setId(dischargeDetails.getId().toString());
				documentReference.getText().setStatus(NarrativeStatus.GENERATED).setDivAsString("Docuemt Reference Resource");
				documentReference.setStatus(DocumentReferenceStatus.CURRENT);
				documentReference.setDocStatus(ReferredDocumentStatus.FINAL);
				documentReference.getType().addCoding().setSystem("https://snomedct.ndhm.gov.in/loinc").setCode("373942005").setDisplay("Discharge Summary");	
				documentReference.getType().setText("Discharge Summary");
				documentReference.getSubject().setReference("Patient/"+patientVisitDetails.getPatient());
				DocumentReferenceContentComponent documentReferenceContentComponent = new DocumentReferenceContentComponent();
				Attachment attach = new Attachment();
				String fileExt = null;
				String filePath=null;
				String contentType = null;
				if(dischargeDetails!=null && dischargeDetails.getReportType()!=null) {
					filePath = dischargeDetails.getAttachPath();
					fileExt = filePath.substring((filePath.lastIndexOf(".") + 1));
					if (fileExt.equalsIgnoreCase("jpg") || fileExt.equalsIgnoreCase("jpeg") || fileExt.equalsIgnoreCase("png"))
					{
						contentType="image/jpeg";
					}
					if (fileExt.equalsIgnoreCase("pdf"))
					{
						contentType="application/pdf";
					}
					attach.setContentType(contentType);
					attach.setLanguage("en-IN");
					attach.setTitle("Discharge Summary");
					byte[] bytestream = getBase64(filePath);
					if(bytestream!=null) {
					attach.setData(bytestream);
					//attach.setSize(bytestream.length);
					attach.setTitle("Discharge Summary");
					}else {
						attach.setData(null);
						//attach.setSize(bytestream.length);
						attach.setTitle("No data");
					}
					attach.setCreation(dischargeDetails.getCreatedAt());
					documentReferenceContentComponent.setAttachment(attach);
				}
				
		        documentReference.getContent().add(documentReferenceContentComponent);
				documentReferenceComp.setResource(documentReference);
				bundleComponentLst.add(documentReferenceComp);
			}
			
			bundle.setEntry(bundleComponentLst);
			}
		
		return bundle;
	}




	@Override
	public BundleEntryComponent getOrganisationFhirObject(PatientVisitDetails patientVisitDetails) {
		// TODO Auto-generated method stub
		
		BundleEntryComponent OrganizationResource = new BundleEntryComponent();//This should be added
		OrganizationResource.setFullUrl("Organization/"+patientVisitDetails.getFacilityCd());
		Organization organization = new Organization();
		organization.setId(patientVisitDetails.getFacilityCd());
		organization.getText().setStatus(NarrativeStatus.GENERATED);
		organization.getText().setDivAsString("Organization Resource");
		organization.addIdentifier().setSystem("https://facility.ndhm.gov.in").setValue(patientVisitDetails.getFacilityCd());
		organization.setName(patientVisitDetails.getFacilityName());
		organization.addTelecom().setSystem(ContactPointSystem.PHONE).setValue("   ").setUse(ContactPointUse.WORK);
		OrganizationResource.setResource(organization);
		
		return OrganizationResource;
	}




	@Override
	public BundleEntryComponent getMediaFhirObject(PatientDiagnosticReportDetails patientDiagnosticReportDetails) {
		BundleEntryComponent mediaResource = new BundleEntryComponent();//This should be added
		// TODO Auto-generated method stub
		mediaResource.setFullUrl("Media/"+patientDiagnosticReportDetails.getId().toString());
		Media media = new Media();
		media.setId(patientDiagnosticReportDetails.getId().toString());
		media.getText().setStatus(NarrativeStatus.GENERATED).setDivAsString("Media Resource");
		media.getModality().addCoding().setSystem("https://snomedct.ndhm.gov.in/loinc").setCode(patientDiagnosticReportDetails.getTestCode()).setDisplay(patientDiagnosticReportDetails.getTestCodeValue());	
		media.getSubject().setReference("Patient/"+patientDiagnosticReportDetails.getPatientVisitDetails().getPatient().getPatientId());
		media.getCreatedDateTimeType().setValue(patientDiagnosticReportDetails.getCreatedAt());
		media.setStatus(MediaStatus.COMPLETED);
		
		Attachment attach = new Attachment();
		attach.setContentType("application/image");
		attach.setLanguage("en-IN");
		attach.setTitle(patientDiagnosticReportDetails.getTestCodeValue());
		Long visitId = patientDiagnosticReportDetails.getId();
		List<DiagnosticAttachment> lstDiagnostic =  attachmentRepository.findWithVisitId(visitId);
		String filePath=null;
		
		if(lstDiagnostic!=null && lstDiagnostic.size()>0) {
			filePath = lstDiagnostic.get(0).getReportFilePath();
			//filePath="D:/storageNAS/emrweb/3851/3652/diagnosticForm/sample.JPG";
		}
		byte[] bytestream = getBase64(filePath);
		
		if(bytestream!=null) {
		attach.setData(bytestream);
		attach.setSize(bytestream.length);
		
		/**
		 * Hash value
		 */
		
		MessageDigest md = null;
		try {
			md = MessageDigest.getInstance("SHA-1");
		} catch (NoSuchAlgorithmException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
		 byte[] messageDigest = md.digest(bytestream); 
		 BigInteger no = new BigInteger(1, messageDigest); 
		 String hashtext = no.toString(16); 
		// Add preceding 0s to make it 32 bit 
         while (hashtext.length() < 32) { 
             hashtext = "0" + hashtext; 
         }
		attach.setHash(hashtext.getBytes());
		
		media.setContent(attach);
		}else {
			attach.setData(null);
			attach.setSize(0);
		}
		mediaResource.setResource(media);
		return mediaResource;
	}



}
