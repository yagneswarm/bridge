package org.nha.emr.web.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.constraints.Size;


	@Entity
	@Table(name = "hip_consent_request")
	public class HipConsentRequest extends AuditModel {
	    /**
		 * 
		 */
		private static final long serialVersionUID = 1L;

		@Id
	    @GeneratedValue(generator = "hip_consent_generator")
	    @SequenceGenerator(
	            name = "hip_consent_generator",
	            sequenceName = "hip_consent_sequence",
	            initialValue = 1000
	    )
	    private Long id;
		
		@Size(min = 1, max = 100)
	    @Column(name = "consent_id")
	    private String consentId;
		
		
		@Size(min = 0, max = 100)
	    @Column(name = "facility_id")
	    private String faclityId;
		
		@Size(min = 0, max = 100)
	    @Column(name = "doctor_id")
	    private String doctorId;
		
		@Size(min = 0, max = 100)
	    @Column(name = "name")
	    private String givenName;
		
	    public String getGivenName() {
			return givenName;
		}


		public void setGivenName(String givenName) {
			this.givenName = givenName;
		}

		@Size(min = 0, max = 100)
	    @Column(name = "swasthya_id")
	    private String swasthyaId;
		
		public String getPurpose() {
			return purpose;
		}


		public void setPurpose(String purpose) {
			this.purpose = purpose;
		}

		@Size(min = 0, max = 100000)
	    @Column(name = "visit_id")
	    private String visitId;
		
		@Size(min = 0, max = 100)
	    @Column(name = "purpose")
	    private String purpose;
	    

	    public String getSwasthyaId() {
			return swasthyaId;
		}


		public void setSwasthyaId(String swasthyaId) {
			this.swasthyaId = swasthyaId;
		}

		@Size(min = 0, max = 3)
	    @Column(name ="discharge_yn")
	    private String dischargeYn;;
	    
	    
	    @Size(min = 0, max = 3)
	    @Column(name ="prescription_yn")
	    private String prescriptionYn;;
	    

	    @Size(min = 0, max = 3)
	    @Column(name ="op_yn")
	    private String opYn;
	    

	    @Size(min = 0, max = 3)
	    @Column(name ="lab_yn")
	    private String labYn;;

	    @Size(min = 0, max = 3)
	    @Column(name ="image_yn")
	    private String imageYn;
	    
	    
	    @Column(name = "consent_grant_dt", nullable = true)
	    private String consentGrantDt;
	    
	   
	    @Column(name = "consent_expiry_dt", nullable = true)
	    private String consentExpiryDt;
	    
	    
	    @Column(name = "consent_created_dt", nullable = true)
	    private String consentCreatedDt;
	    
	 
	    @Column(name = "health_info_from_dt", nullable = true)
	    private String healthInfoFromDt;
	    
	   
	    @Column(name = "health_info_to_dt", nullable = true)
	    private String healthInfoToDt;
	    
	    
	    @Column(name = "health_expiry_from_dt", nullable = true)
	    private String healthExpiryFromDt;
	    
	  
	    @Column(name = "health_expiry_to_dt", nullable = true)
	    private String healthExpiryToDt;
	    
	    	        
		public HipConsentRequest() {
			// TODO Auto-generated constructor stub
		}


		public Long getId() {
			return id;
		}


		public void setId(Long id) {
			this.id = id;
		}


		public String getConsentId() {
			return consentId;
		}

		public String getFaclityId() {
			return faclityId;
		}


		public void setFaclityId(String faclityId) {
			this.faclityId = faclityId;
		}


		public String getDoctorId() {
			return doctorId;
		}


		public void setDoctorId(String doctorId) {
			this.doctorId = doctorId;
		}


		public void setConsentId(String consentId) {
			this.consentId = consentId;
		}


		public String getVisitId() {
			return visitId;
		}


		public void setVisitId(String visitId) {
			this.visitId = visitId;
		}


		public String getDischargeYn() {
			return dischargeYn;
		}


		public void setDischargeYn(String dischargeYn) {
			this.dischargeYn = dischargeYn;
		}


		public String getPrescriptionYn() {
			return prescriptionYn;
		}


		public void setPrescriptionYn(String prescriptionYn) {
			this.prescriptionYn = prescriptionYn;
		}


		public String getOpYn() {
			return opYn;
		}


		public void setOpYn(String opYn) {
			this.opYn = opYn;
		}


		public String getLabYn() {
			return labYn;
		}


		public void setLabYn(String labYn) {
			this.labYn = labYn;
		}


		public String getImageYn() {
			return imageYn;
		}


		public void setImageYn(String imageYn) {
			this.imageYn = imageYn;
		}


		public String getConsentGrantDt() {
			return consentGrantDt;
		}


		public void setConsentGrantDt(String consentGrantDt) {
			this.consentGrantDt = consentGrantDt;
		}


		public String getConsentExpiryDt() {
			return consentExpiryDt;
		}


		public void setConsentExpiryDt(String consentExpiryDt) {
			this.consentExpiryDt = consentExpiryDt;
		}


		public String getConsentCreatedDt() {
			return consentCreatedDt;
		}


		public void setConsentCreatedDt(String consentCreatedDt) {
			this.consentCreatedDt = consentCreatedDt;
		}


		public String getHealthInfoFromDt() {
			return healthInfoFromDt;
		}


		public void setHealthInfoFromDt(String healthInfoFromDt) {
			this.healthInfoFromDt = healthInfoFromDt;
		}


		public String getHealthInfoToDt() {
			return healthInfoToDt;
		}


		public void setHealthInfoToDt(String healthInfoToDt) {
			this.healthInfoToDt = healthInfoToDt;
		}


		public String getHealthExpiryFromDt() {
			return healthExpiryFromDt;
		}


		public void setHealthExpiryFromDt(String healthExpiryFromDt) {
			this.healthExpiryFromDt = healthExpiryFromDt;
		}


		public String getHealthExpiryToDt() {
			return healthExpiryToDt;
		}


		public void setHealthExpiryToDt(String healthExpiryToDt) {
			this.healthExpiryToDt = healthExpiryToDt;
		}

		

			    
	}
