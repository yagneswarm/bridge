package org.nha.emr.web.repositories;

import org.nha.emr.web.entities.HIPHealthInfoRequest;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;

@Repository
@Component
public interface HipHealthInfoRequestRepository extends JpaRepository<HIPHealthInfoRequest, String> {
		//select TO_CHAR(MYDATE,'YYYY-MM-DD')from Event e
}
