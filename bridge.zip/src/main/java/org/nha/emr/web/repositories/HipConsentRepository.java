package org.nha.emr.web.repositories;

import java.util.List;

import org.nha.emr.web.entities.HipConsentRequest;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;

@Repository
@Component
public interface HipConsentRepository extends JpaRepository<HipConsentRequest, Long> {
	@Query("select a from HipConsentRequest a where a.consentId =?1")
	List<HipConsentRequest>  findByConsentId(String consentId);
	
}
