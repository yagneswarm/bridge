package org.nha.emr.web.hip.configuration;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import springfox.documentation.builders.ApiInfoBuilder;
import springfox.documentation.builders.RequestHandlerSelectors;
import springfox.documentation.service.ApiInfo;
import springfox.documentation.service.Contact;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.spring.web.plugins.Docket;


@Configuration
public class SwaggerDocumentationConfig {

    ApiInfo apiInfo() {
        return new ApiInfoBuilder()
            .title("HIP Bridge")
            .description("The following are the specifications for the APIs to be implemented at the Health Repository end if an entity is only serving the role of a HIP. The specs are essentially duplicates from the Gateway and Bridge specs, but put together as to make it clear to *HIPs* which set of APIs they should implement to participate in the network.     1. The APIs are organized by the flows - **discovery**, **link**, **consent flow**, **data flow**, **user auth** and **monitoring**. They represent the APIs that are expected to be available at the HIP end by the Gateway.    2. For majority of the APIs, there are corresponding callback APIs on the Gateway. e.g for **_/care-context/discover** API on HIP end, its expected that a corresponding callback API **_/care-context/on-discover** on Gateway is called. Such APIs are organized under the **Gateway** label.    3. Gateway relevant APIs for HIPs are grouped under **Gateway** label. These include the APIs that HIPs may require to call on the Gateway. For example, to notify a CM that requested data is transferred, HIP would call **_/health-information/notify** API on gateway. Or for example, to get a session or to do a hip-initiated purpose for linking care-contexts.    4. APIs under **data transfer** are meant to be implemented by the HIU. However, these have been marked here to give indication to the HIPs about the data contract.      ")
            .license("")
            .licenseUrl("http://unlicense.org")
            .termsOfServiceUrl("")
            .version("0.5")
            .contact(new Contact("","", ""))
            .build();
    }

    @Bean
    public Docket customImplementation(){
        return new Docket(DocumentationType.SWAGGER_2)
                .select()
                    .apis(RequestHandlerSelectors.basePackage("org.nha.emr.web.hip.api"))
                    .build()
                .directModelSubstitute(org.threeten.bp.LocalDate.class, java.sql.Date.class)
                .directModelSubstitute(org.threeten.bp.OffsetDateTime.class, java.util.Date.class)
                .apiInfo(apiInfo());
    }

}
