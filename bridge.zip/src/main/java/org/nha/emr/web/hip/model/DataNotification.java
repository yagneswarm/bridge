package org.nha.emr.web.hip.model;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.UUID;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;

import org.springframework.validation.annotation.Validated;

import com.fasterxml.jackson.annotation.JsonProperty;

import io.swagger.annotations.ApiModelProperty;

/**
 * DataNotification
 */
@Validated



public class DataNotification   {
  @JsonProperty("pageNumber")
  private Integer pageNumber = null;

  @JsonProperty("pageCount")
  private Integer pageCount = null;

  @JsonProperty("transactionId")
  private UUID transactionId = null;

  @JsonProperty("entries")
  @Valid
  private List<EntryContent> entries = new ArrayList<EntryContent>();

  @JsonProperty("keyMaterial")
  private KeyMaterial keyMaterial = null;

  public DataNotification pageNumber(Integer pageNumber) {
    this.pageNumber = pageNumber;
    return this;
  }

  /**
   * Current page number.
   * @return pageNumber
  **/
  @ApiModelProperty(required = true, value = "Current page number.")
      @NotNull

    public Integer getPageNumber() {
    return pageNumber;
  }

  public void setPageNumber(Integer pageNumber) {
    this.pageNumber = pageNumber;
  }

  public DataNotification pageCount(Integer pageCount) {
    this.pageCount = pageCount;
    return this;
  }

  /**
   * Total number of pages.
   * @return pageCount
  **/
  @ApiModelProperty(required = true, value = "Total number of pages.")
      @NotNull

    public Integer getPageCount() {
    return pageCount;
  }

  public void setPageCount(Integer pageCount) {
    this.pageCount = pageCount;
  }

  public DataNotification transactionId(UUID transactionId) {
    this.transactionId = transactionId;
    return this;
  }

  /**
   * Transaction Id issued when data requested.
   * @return transactionId
  **/
  @ApiModelProperty(required = true, value = "Transaction Id issued when data requested.")
      @NotNull

    @Valid
    public UUID getTransactionId() {
    return transactionId;
  }

  public void setTransactionId(UUID transactionId) {
    this.transactionId = transactionId;
  }

  public DataNotification entries(List<EntryContent> entries) {
    this.entries = entries;
    return this;
  }

  public DataNotification addEntriesItem(EntryContent entriesItem) {
    this.entries.add(entriesItem);
    return this;
  }

  /**
   * Get entries
   * @return entries
  **/
  @ApiModelProperty(required = true, value = "")
      @NotNull

    public List<EntryContent> getEntries() {
    return entries;
  }

  public void setEntries(List<EntryContent> entries) {
    this.entries = entries;
  }

  public DataNotification keyMaterial(KeyMaterial keyMaterial) {
    this.keyMaterial = keyMaterial;
    return this;
  }

  /**
   * Get keyMaterial
   * @return keyMaterial
  **/
  @ApiModelProperty(required = true, value = "")
      @NotNull

    @Valid
    public KeyMaterial getKeyMaterial() {
    return keyMaterial;
  }

  public void setKeyMaterial(KeyMaterial keyMaterial) {
    this.keyMaterial = keyMaterial;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    DataNotification dataNotification = (DataNotification) o;
    return Objects.equals(this.pageNumber, dataNotification.pageNumber) &&
        Objects.equals(this.pageCount, dataNotification.pageCount) &&
        Objects.equals(this.transactionId, dataNotification.transactionId) &&
        Objects.equals(this.entries, dataNotification.entries) &&
        Objects.equals(this.keyMaterial, dataNotification.keyMaterial);
  }

  @Override
  public int hashCode() {
    return Objects.hash(pageNumber, pageCount, transactionId, entries, keyMaterial);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class DataNotification {\n");
    
    sb.append("    pageNumber: ").append(toIndentedString(pageNumber)).append("\n");
    sb.append("    pageCount: ").append(toIndentedString(pageCount)).append("\n");
    sb.append("    transactionId: ").append(toIndentedString(transactionId)).append("\n");
    sb.append("    entries: ").append(toIndentedString(entries)).append("\n");
    sb.append("    keyMaterial: ").append(toIndentedString(keyMaterial)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
