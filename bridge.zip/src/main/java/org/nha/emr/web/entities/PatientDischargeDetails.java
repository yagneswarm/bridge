package org.nha.emr.web.entities;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.Size;

import org.hibernate.annotations.OnDelete;
import org.hibernate.annotations.OnDeleteAction;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name = "patient_discharge_notes_dtls")
public class PatientDischargeDetails extends AuditModel {
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
    @GeneratedValue(generator = "discharge_notes_generator")
    @SequenceGenerator(
            name = "discharge_notes_generator",
            sequenceName = "discharge_notes_sequence",
            initialValue = 1
    )
    private Long id;
   
    @Size(min = 0, max = 100)
    @Column(name = "document_status")
    private String documentStatus;
    
    @Size(min = 0, max = 100)
    @Column(name = "document_category")
    private String documentCategory;
    
    @Column(name="admission_dt")
    private Date admissionDateTime;
    
    @Column(name="discharge_dt")
    private Date dischargeDateTime;
    
    @Column(name="complaints")
    private String complaints;
    
    @Column(name="diagnosis")
    private String diagnosis;
    
    @Column(name="procedure_done")
    private String procedureDone;
    
    @Column(name = "attach_path")
	private String attachPath;
	
	@Column(name = "notes")
	private String notes;
	
	@Column(name="report_type")
	private String reportType;
    
    @Column(name="treatment_given")
    private String treatmentGiven;
    
    @Column(name="status_discharge")
    private String statusDischarge;
    
    @Column(name="advice_discharge")
    private String adviceDischarge;
    
    @Column(name="follow_up")
    private String followUp;
        
    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "document_created_dt", nullable = false)
    private Date documentCreatedDt;
    
    @Size(min = 0, max = 100)
    @Column(name = "document_by", nullable = false)
    private String documentBy;
        
    @Size(min = 0, max = 100)
    @Column(name = "document_source", nullable = false)
    private String documentSource;
   
    @Size(min = 0, max = 100)
    @Column(name = "document_created_at", nullable = false)
    private String documentCreatedAt;
    
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "visit_id", nullable = false)
    @OnDelete(action = OnDeleteAction.CASCADE)
    @JsonIgnore
    private PatientVisitDetails patientVisitDetails;


    
	public PatientDischargeDetails() {
		// TODO Auto-generated constructor stub
	}



	public Long getId() {
		return id;
	}



	public void setId(Long id) {
		this.id = id;
	}



	public String getDocumentStatus() {
		return documentStatus;
	}



	public void setDocumentStatus(String documentStatus) {
		this.documentStatus = documentStatus;
	}



	public String getDocumentCategory() {
		return documentCategory;
	}



	public void setDocumentCategory(String documentCategory) {
		this.documentCategory = documentCategory;
	}



	public Date getDocumentCreatedDt() {
		return documentCreatedDt;
	}



	public void setDocumentCreatedDt(Date documentCreatedDt) {
		this.documentCreatedDt = documentCreatedDt;
	}



	public String getDocumentBy() {
		return documentBy;
	}



	public void setDocumentBy(String documentBy) {
		this.documentBy = documentBy;
	}



	public String getDocumentSource() {
		return documentSource;
	}



	public void setDocumentSource(String documentSource) {
		this.documentSource = documentSource;
	}



	public String getDocumentCreatedAt() {
		return documentCreatedAt;
	}



	public void setDocumentCreatedAt(String documentCreatedAt) {
		this.documentCreatedAt = documentCreatedAt;
	}



	public PatientVisitDetails getPatientVisitDetails() {
		return patientVisitDetails;
	}



	public void setPatientVisitDetails(PatientVisitDetails patientVisitDetails) {
		this.patientVisitDetails = patientVisitDetails;
	}



	public Date getAdmissionDateTime() {
		return admissionDateTime;
	}



	public void setAdmissionDateTime(Date admissionDateTime) {
		this.admissionDateTime = admissionDateTime;
	}



	public Date getDischargeDateTime() {
		return dischargeDateTime;
	}



	public void setDischargeDateTime(Date dischargeDateTime) {
		this.dischargeDateTime = dischargeDateTime;
	}



	public String getComplaints() {
		return complaints;
	}



	public void setComplaints(String complaints) {
		this.complaints = complaints;
	}



	public String getDiagnosis() {
		return diagnosis;
	}



	public void setDiagnosis(String diagnosis) {
		this.diagnosis = diagnosis;
	}



	public String getProcedureDone() {
		return procedureDone;
	}



	public void setProcedureDone(String procedureDone) {
		this.procedureDone = procedureDone;
	}



	public String getTreatmentGiven() {
		return treatmentGiven;
	}



	public void setTreatmentGiven(String treatmentGiven) {
		this.treatmentGiven = treatmentGiven;
	}



	public String getStatusDischarge() {
		return statusDischarge;
	}



	public void setStatusDischarge(String statusDischarge) {
		this.statusDischarge = statusDischarge;
	}



	public String getAdviceDischarge() {
		return adviceDischarge;
	}



	public void setAdviceDischarge(String adviceDischarge) {
		this.adviceDischarge = adviceDischarge;
	}



	public String getFollowUp() {
		return followUp;
	}



	public void setFollowUp(String followUp) {
		this.followUp = followUp;
	}



	public String getAttachPath() {
		return attachPath;
	}



	public void setAttachPath(String attachPath) {
		this.attachPath = attachPath;
	}



	public String getNotes() {
		return notes;
	}



	public void setNotes(String notes) {
		this.notes = notes;
	}



	public String getReportType() {
		return reportType;
	}



	public void setReportType(String reportType) {
		this.reportType = reportType;
	}
	
	
	
	        
    }
