package org.nha.emr.web.hip.model;

import java.util.Objects;

import javax.validation.constraints.NotNull;

import org.springframework.validation.annotation.Validated;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonValue;

import io.swagger.annotations.ApiModelProperty;

/**
 * EntryContent
 */
@Validated



public class EntryContent  implements AnyOfDataNotificationEntriesItems {
  @JsonProperty("content")
  private String content = null;

  /**
   * mimetype of the content.
   */
  public enum MediaEnum {
    JSON("application/fhir+json");

    private String value;

    MediaEnum(String value) {
      this.value = value;
    }

    @Override
    @JsonValue
    public String toString() {
      return String.valueOf(value);
    }

    @JsonCreator
    public static MediaEnum fromValue(String text) {
      for (MediaEnum b : MediaEnum.values()) {
        if (String.valueOf(b.value).equals(text)) {
          return b;
        }
      }
      return null;
    }
  }
  @JsonProperty("media")
  private String media = null;

  @JsonProperty("checksum")
  private String checksum = null;

  @JsonProperty("careContextReference")
  private String careContextReference = null;

  public EntryContent content(String content) {
    this.content = content;
    return this;
  }

  /**
   * Encrypted content
   * @return content
  **/
  @ApiModelProperty(example = "Encrypted content of data packaged in FHIR bundle", required = true, value = "Encrypted content")
      @NotNull

    public String getContent() {
    return content;
  }

  public void setContent(String content) {
    this.content = content;
  }

  public EntryContent media(String media) {
    this.media = media;
    return this;
  }

  /**
   * mimetype of the content.
   * @return media
  **/
  @ApiModelProperty(required = true, value = "mimetype of the content.")
      @NotNull

    public String getMedia() {
    return media;
  }

  public void setMedia(String media) {
    this.media = media;
  }

  public EntryContent checksum(String checksum) {
    this.checksum = checksum;
    return this;
  }

  /**
   * Md5 checksum of the content before encryption
   * @return checksum
  **/
  @ApiModelProperty(required = true, value = "Md5 checksum of the content before encryption")
      @NotNull

    public String getChecksum() {
    return checksum;
  }

  public void setChecksum(String checksum) {
    this.checksum = checksum;
  }

  public EntryContent careContextReference(String careContextReference) {
    this.careContextReference = careContextReference;
    return this;
  }

  /**
   * care context reference number.
   * @return careContextReference
  **/
  @ApiModelProperty(example = "RVH1008", required = true, value = "care context reference number.")
      @NotNull

    public String getCareContextReference() {
    return careContextReference;
  }

  public void setCareContextReference(String careContextReference) {
    this.careContextReference = careContextReference;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    EntryContent entryContent = (EntryContent) o;
    return Objects.equals(this.content, entryContent.content) &&
        Objects.equals(this.media, entryContent.media) &&
        Objects.equals(this.checksum, entryContent.checksum) &&
        Objects.equals(this.careContextReference, entryContent.careContextReference);
  }

  @Override
  public int hashCode() {
    return Objects.hash(content, media, checksum, careContextReference);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class EntryContent {\n");
    
    sb.append("    content: ").append(toIndentedString(content)).append("\n");
    sb.append("    media: ").append(toIndentedString(media)).append("\n");
    sb.append("    checksum: ").append(toIndentedString(checksum)).append("\n");
    sb.append("    careContextReference: ").append(toIndentedString(careContextReference)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
