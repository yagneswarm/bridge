package org.nha.emr.web.hip.model;


/**
* AnyOfDataNotificationEntriesItems
*/
public interface AnyOfDataNotificationEntriesItems {

}
