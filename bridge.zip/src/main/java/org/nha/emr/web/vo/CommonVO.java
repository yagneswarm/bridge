package org.nha.emr.web.vo;

public class CommonVO {
	private String ID;
	private String VALUE;
	private String hid;
	private String otp;
	private String txnId;
	private String loctype;
    private String locid;
    private String authMethod;
    private String valOtp;
    private String uidOtp;
    private String pwdval;
    private String token;

	public String getID() {
		return ID;
	}
	public void setID(String iD) {
		ID = iD;
	}
	public String getVALUE() {
		return VALUE;
	}
	public void setVALUE(String vALUE) {
		VALUE = vALUE;
	}
	public String getHid() {
		return hid;
	}
	public void setHid(String hid) {
		this.hid = hid;
	}
	public String getOtp() {
		return otp;
	}
	public void setOtp(String otp) {
		this.otp = otp;
	}
	public String getTxnId() {
		return txnId;
	}
	public void setTxnId(String txnId) {
		this.txnId = txnId;
	}
	public String getLoctype() {
		return loctype;
	}
	public void setLoctype(String loctype) {
		this.loctype = loctype;
	}
	public String getLocid() {
		return locid;
	}
	public void setLocid(String locid) {
		this.locid = locid;
	}
	public String getAuthMethod() {
		return authMethod;
	}
	public void setAuthMethod(String authMethod) {
		this.authMethod = authMethod;
	}
	public String getValOtp() {
		return valOtp;
	}
	public void setValOtp(String valOtp) {
		this.valOtp = valOtp;
	}
	public String getUidOtp() {
		return uidOtp;
	}
	public void setUidOtp(String uidOtp) {
		this.uidOtp = uidOtp;
	}
	public String getPwdval() {
		return pwdval;
	}
	public void setPwdval(String pwdval) {
		this.pwdval = pwdval;
	}
	public String getToken() {
		return token;
	}
	public void setToken(String token) {
		this.token = token;
	}
	
}
