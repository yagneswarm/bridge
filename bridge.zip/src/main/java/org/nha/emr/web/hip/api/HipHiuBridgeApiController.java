package org.nha.emr.web.hip.api;

import java.io.IOException;
import java.security.KeyPair;
import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneOffset;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.ListIterator;
import java.util.UUID;
import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;


import org.nha.emr.web.client.ApiException;
import org.nha.emr.web.client.AuthKeys;
import org.nha.emr.web.client.DHKeyExchangeCrypto;
import org.nha.emr.web.client.Decryptor;
import org.nha.emr.web.client.api.GatewayApi;
import org.nha.emr.web.entities.ConsentArtefacts;
import org.nha.emr.web.entities.ConsentRequest;
import org.nha.emr.web.entities.HIDocuments;
import org.nha.emr.web.entities.HIPHealthInfoRequest;
import org.nha.emr.web.entities.HidCreate;
import org.nha.emr.web.entities.HipConsentRequest;
import org.nha.emr.web.entities.HipInitRequest;
import org.nha.emr.web.entities.HipRequest;
import org.nha.emr.web.entities.HiuConsentRequest;
import org.nha.emr.web.entities.PatientVisitDetails;
import org.nha.emr.web.hip.model.AuthenticationMode;
import org.nha.emr.web.hip.model.CareContextRepresentation;
import org.nha.emr.web.hip.model.Certs;
import org.nha.emr.web.hip.model.Consent;
import org.nha.emr.web.hip.model.ConsentAcknowledgement;
import org.nha.emr.web.hip.model.ConsentAcknowledgement.StatusEnum;
import org.nha.emr.web.hip.model.ConsentArtefactReference;
import org.nha.emr.web.hip.model.ConsentArtefactResponse;
import org.nha.emr.web.hip.model.ConsentFetchRequest;
import org.nha.emr.web.hip.model.ConsentRequestInitResponse;
import org.nha.emr.web.hip.model.DataNotification;
import org.nha.emr.web.hip.model.EntryContent;
import org.nha.emr.web.hip.model.Error;
import org.nha.emr.web.hip.model.HIPConsentNotification;
import org.nha.emr.web.hip.model.HIPConsentNotificationNotificationConsentDetail;
import org.nha.emr.web.hip.model.HIPConsentNotificationNotificationConsentDetailCareContexts;
import org.nha.emr.web.hip.model.HIPConsentNotificationResponse;
import org.nha.emr.web.hip.model.HIPHealthInformationRequest;
import org.nha.emr.web.hip.model.HIPHealthInformationRequestAcknowledgement;
import org.nha.emr.web.hip.model.HIPHealthInformationRequestAcknowledgementHiRequest;
import org.nha.emr.web.hip.model.HIRequest;
import org.nha.emr.web.hip.model.HIRequestHiRequest;
import org.nha.emr.web.hip.model.HITypeEnum;
import org.nha.emr.web.hip.model.HIUConsentNotificationEvent;
import org.nha.emr.web.hip.model.HIUHealthInformationRequestResponse;
import org.nha.emr.web.hip.model.HealthInformationNotification;
import org.nha.emr.web.hip.model.HealthInformationNotificationNotification;
import org.nha.emr.web.hip.model.HealthInformationNotificationNotificationNotifier;
import org.nha.emr.web.hip.model.HealthInformationNotificationNotificationNotifier.TypeEnum;
import org.nha.emr.web.hip.model.HealthInformationNotificationNotificationStatusNotification;
import org.nha.emr.web.hip.model.HealthInformationNotificationNotificationStatusNotificationStatusResponses;
import org.nha.emr.web.hip.model.HealthInformationNotificationNotificationStatusNotificationStatusResponses.HiStatusEnum;
import org.nha.emr.web.hip.model.HeartbeatResponse;
import org.nha.emr.web.hip.model.Identifier;
import org.nha.emr.web.hip.model.IdentifierType;
import org.nha.emr.web.hip.model.KeyMaterial;
import org.nha.emr.web.hip.model.KeyObject;
import org.nha.emr.web.hip.model.LinkConfirmationRequest;
import org.nha.emr.web.hip.model.LinkConfirmationRequestConfirmation;
import org.nha.emr.web.hip.model.Meta;
import org.nha.emr.web.hip.model.Meta.CommunicationMediumEnum;
import org.nha.emr.web.hip.model.OpenIdConfiguration;
import org.nha.emr.web.hip.model.PatientAuthConfirmRequest;
import org.nha.emr.web.hip.model.PatientAuthConfirmRequestCredential;
import org.nha.emr.web.hip.model.PatientAuthConfirmResponse;
import org.nha.emr.web.hip.model.PatientAuthInitRequest;
import org.nha.emr.web.hip.model.PatientAuthInitRequestQuery;
import org.nha.emr.web.hip.model.PatientAuthInitRequestQueryRequester;
import org.nha.emr.web.hip.model.PatientAuthInitResponse;
import org.nha.emr.web.hip.model.PatientAuthModeQueryResponse;
import org.nha.emr.web.hip.model.PatientAuthPurpose;
import org.nha.emr.web.hip.model.PatientCareContextLink;
import org.nha.emr.web.hip.model.PatientCareContextLinkPatient;
import org.nha.emr.web.hip.model.PatientCareContextLinkRequest;
import org.nha.emr.web.hip.model.PatientCareContextLinkResponse;
import org.nha.emr.web.hip.model.PatientDemographic;
import org.nha.emr.web.hip.model.PatientDiscoveryRequest;
import org.nha.emr.web.hip.model.PatientDiscoveryRequestPatient.GenderEnum;
import org.nha.emr.web.hip.model.PatientDiscoveryResult;
import org.nha.emr.web.hip.model.PatientGender;
import org.nha.emr.web.hip.model.PatientLinkReferenceRequest;
import org.nha.emr.web.hip.model.PatientLinkReferenceResult;
import org.nha.emr.web.hip.model.PatientLinkReferenceResultLink;
import org.nha.emr.web.hip.model.PatientLinkReferenceResultLink.AuthenticationTypeEnum;
import org.nha.emr.web.hip.model.PatientLinkResult;
import org.nha.emr.web.hip.model.PatientLinkResultPatient;
import org.nha.emr.web.hip.model.PatientRepresentation;
import org.nha.emr.web.hip.model.PatientShareResult;
import org.nha.emr.web.hip.model.ProfileShareCallback;
import org.nha.emr.web.hip.model.RequestReference;
import org.nha.emr.web.hip.model.SessionRequest;
import org.nha.emr.web.hip.model.SessionResponse;
import org.nha.emr.web.hip.model.ShareAcknowledgement;
import org.nha.emr.web.hip.model.ShareProfileAcknowledgement;
import org.nha.emr.web.hip.model.ShareProfileResult;
import org.nha.emr.web.repositories.ConsentArtefactsRepository;
import org.nha.emr.web.repositories.ConsentRepository;
import org.nha.emr.web.repositories.HiDocumentsRepository;
import org.nha.emr.web.repositories.HidCreateRepository;
import org.nha.emr.web.repositories.HipConsentRepository;
import org.nha.emr.web.repositories.HipHealthInfoRequestRepository;
import org.nha.emr.web.repositories.HipInitRepository;
import org.nha.emr.web.repositories.HipRequestRepository;
import org.nha.emr.web.repositories.HiuConsentRepository;
import org.nha.emr.web.repositories.PatientRepository;
import org.nha.emr.web.repositories.PatientVisitRepository;
import org.nha.emr.web.service.EmrService;
import org.nha.emr.web.service.FhirService;
import org.nha.emr.web.vo.PatientSearchVO;
import org.nha.emr.web.vo.PatientVO;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import io.swagger.annotations.ApiParam;

@Controller
public class HipHiuBridgeApiController implements HipHiuBridgeApi {

    private static final Logger log = LoggerFactory.getLogger(HipHiuBridgeApiController.class);

    private final ObjectMapper objectMapper;

    private final HttpServletRequest request;
    
    @Autowired
    PatientRepository patientRepository;
    @Autowired
    PatientVisitRepository patientVisitRepository;
    @Autowired
    HipRequestRepository hipRequestRepository;
    
    @Autowired
    ConsentRepository consentRepository;
    
    @Autowired
    HipInitRepository hipInitRepository;
    
    
    @Autowired
    HipConsentRepository hipConsentRepository;
    
    @Autowired
    HiuConsentRepository hiuConsentRepository;
    @Autowired
    ConsentArtefactsRepository consentArtefactsRepository;
    
    @Autowired
    HiDocumentsRepository hiDocumentsRepository; 
    
    @Autowired
    HipHealthInfoRequestRepository hipHealthInfoRequestRepository;
    
    @Autowired
    HidCreateRepository hidCreateRepository ;
    
    @Autowired
    private FhirService fhirService;
    @Autowired
    private EmrService emrService;
    int count =0;

    public HipHiuBridgeApiController(ObjectMapper objectMapper, HttpServletRequest request) {
        this.objectMapper = objectMapper;
        this.request = request;
    }
    
    @SuppressWarnings("static-access")
	public ResponseEntity<Void> v05HealthInformationHiuOnRequestPost(@ApiParam(value = "Access token which was issued after successful login with gateway auth server, which will be sent by gateway to authenticate itself with API bridge." ,required=true) @RequestHeader(value="Authorization", required=true) String authorization
    		,@ApiParam(value = "Identifier of the health information user to which the request was intended." ,required=true) @RequestHeader(value="X-HIU-ID", required=true) String X_HIU_ID
    		,@ApiParam(value = "" ,required=true )  @Valid @RequestBody HIUHealthInformationRequestResponse body
    		) {
    		        String accept = request.getHeader("Accept");
    		        String refId = null; 
    		        String consentTxnNum = null;
    		        String consentTxnStatus = null;
    		        ObjectMapper mapper = new ObjectMapper();
    		        try {
    		        	refId = body.getResp().getRequestId()+"";
    		      
    		        	if(body.getHiRequest()!=null) {
    		        		consentTxnNum =  body.getHiRequest().getTransactionId()+"";
        		        	consentTxnStatus = body.getHiRequest().getSessionStatus().toString();
        		        	
        		        	List<HiuConsentRequest> lstHiuConsentRequest = hiuConsentRepository.findByConsentRefId(refId);
        		        	ListIterator<HiuConsentRequest> lstIterator = null;
        		        	HiuConsentRequest hiuConsentRequest = null;
        		        	if(lstHiuConsentRequest!=null) {
        		        		lstIterator = lstHiuConsentRequest.listIterator();
        		        		while(lstIterator.hasNext()) {
        		        			hiuConsentRequest = lstIterator.next();
        		        			hiuConsentRequest.setConsentTxnNum(consentTxnNum);
        		        			hiuConsentRequest.setConsentTxnStatus(consentTxnStatus);
        		        			hiuConsentRepository.save(hiuConsentRequest);
        		        		}
        		        	}

    		        	}
						System.out.println("HIUHealthInformationRequestResponse!!  "+mapper.writeValueAsString(body));
					} catch (JsonProcessingException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
    		        
    		        return new ResponseEntity<Void>(HttpStatus.ACCEPTED);
    		    }
    
    
    
	public ResponseEntity<Void> v05ConsentsOnFetchPost(
			@ApiParam(value = "Access token which was issued after successful login with gateway auth server.", required = true) @RequestHeader(value = "Authorization", required = true) String authorization,
			@ApiParam(value = "Identifier of the health information user to which the request was intended.", required = true) @RequestHeader(value = "X-HIU-ID", required = true) String X_HIU_ID,
			@ApiParam(value = "", required = true) @Valid @RequestBody ConsentArtefactResponse body) {
		
		System.out.println("In Consent on Fetch ------------");
		String accept = request.getHeader("Accept");
		ObjectMapper mapper = new ObjectMapper();
		
		 GatewayApi gatewayApi =   new GatewayApi();
			SessionRequest sessReq = new SessionRequest();
			sessReq.clientId(AuthKeys.X_CLIENT_ID);
     	sessReq.clientSecret(AuthKeys.AUTHORIZATION_TOKEN);
     	try {
				SessionResponse sessResp = gatewayApi.v05SessionsPost(sessReq);
				String accessToken = sessResp.getAccessToken();
	        	
	        	accessToken ="bearer "+accessToken;
	        	UUID consentRefNum = UUID.randomUUID();
	        	  /**
	        	   * KeyMaterial
	        	   */
	        	  KeyMaterial keyMaterial = new KeyMaterial();
		          keyMaterial.cryptoAlg(DHKeyExchangeCrypto.ALGORITHM);
		          keyMaterial.curve(DHKeyExchangeCrypto.CURVE);
		          KeyObject dhPublicKey =  new KeyObject();
		          	
		          KeyPair receiverKeyPair = DHKeyExchangeCrypto.generateKeyPair();  //HIU
		          String receiverPrivateKey = DHKeyExchangeCrypto.getBase64String(DHKeyExchangeCrypto.getEncodedPrivateKey(receiverKeyPair.getPrivate()));
		          String receiverPublicKey = DHKeyExchangeCrypto.getBase64String(DHKeyExchangeCrypto.getEncodedPublicKeyQ(receiverKeyPair.getPublic()));
		          String randomReceiver = DHKeyExchangeCrypto.generateRandomKey();
		          
		          
	        	String consentId = body.getConsent().getConsentDetail().getConsentId().toString();
	 		   List<HIPConsentNotificationNotificationConsentDetailCareContexts> careContexts = body.getConsent().getConsentDetail().getCareContexts();
	 	       ListIterator<HIPConsentNotificationNotificationConsentDetailCareContexts> lstIterator = null;
	 	       if(careContexts!=null) {
	 	    	   lstIterator = careContexts.listIterator();
	 	       }
	 	       
	 	       List<HiuConsentRequest> consentRequests = new ArrayList<HiuConsentRequest>();
	 	       List<HITypeEnum> listItems = body.getConsent().getConsentDetail().getHiTypes();
	 		  
	 		   HiuConsentRequest consentRequestE = new HiuConsentRequest();
	 		   consentRequestE.setConsentId(consentId);
	 		   
	 		   if(listItems.contains(HITypeEnum.DIAGNOSTICREPORT)) {
	 			   consentRequestE.setLabYn("Y");
	 		   }
	 		   if(listItems.contains(HITypeEnum.DISCHARGESUMMARY)) {
	 			   consentRequestE.setDischargeYn("Y");
	 		   }
	 		   if(listItems.contains(HITypeEnum.MEDICATIONREQUEST)) {
	 			   consentRequestE.setPrescriptionYn("Y");
	 		   }
	 		   if(listItems.contains(HITypeEnum.OPCONSULTATION)) {
	 			   consentRequestE.setOpYn("Y");
	 		   }
	 		   
	 		   consentRequestE.setFaclityId(body.getConsent().getConsentDetail().getHip().getId());
	 		   consentRequestE.setConsentCreatedDt(body.getConsent().getConsentDetail().getCreatedAt());
	 		   consentRequestE.setConsentExpiryDt(body.getConsent().getConsentDetail().getPermission().getDataEraseAt());
	 		   consentRequestE.setHealthInfoFromDt(body.getConsent().getConsentDetail().getPermission().getDateRange().getFrom());
	 		   consentRequestE.setHealthInfoToDt(body.getConsent().getConsentDetail().getPermission().getDateRange().getTo());
	 		   consentRequestE.setSwasthyaId(body.getConsent().getConsentDetail().getPatient().getId());
	 		   consentRequestE.setPurpose(body.getConsent().getConsentDetail().getPurpose().getCode());
	 		   consentRequestE.setConsentRefNum(consentRefNum+"");
	 		   consentRequestE.setNonce(randomReceiver);
	 		   consentRequestE.setPublicKeyValue(receiverPublicKey);
	 		   consentRequestE.setPrivateKeyValue(receiverPrivateKey);
	 		   consentRequests.add(consentRequestE);
	 		   
	 		   String visitId = "";
	 	       if(lstIterator!=null) {
	 	    	   while(lstIterator.hasNext()) {
	 	    		   
	 	        	   HIPConsentNotificationNotificationConsentDetailCareContexts careContext = lstIterator.next();
	 	        	   if(visitId.equalsIgnoreCase("")) {
	 	        		   visitId = careContext.getCareContextReference();
	 	        	   }else {
	 	        		   visitId = visitId +","+ careContext.getCareContextReference();
	 	        	   }
	 	           }
	 	    	   consentRequestE.setVisitId(visitId);
	 	       }
	 	       consentRequests = hiuConsentRepository.saveAll(consentRequests);
	 	       
	 	       /**
	 	        * health-information/cm/request
	 	        */
	 	      HIRequest hiRequest = new HIRequest();
	 	      hiRequest.setRequestId(consentRefNum);
	 	      hiRequest.setTimestamp(LocalDateTime.now(ZoneOffset.UTC)+"");
	 	      HIRequestHiRequest hiRequestHiRequest = new HIRequestHiRequest();
	 	      Consent consent = new Consent();
	 	      consent.setId(consentId);
	 	      hiRequestHiRequest.setConsent(consent);
	 	      hiRequestHiRequest.setDataPushUrl(AuthKeys.X_DATA_PUSH_URL);
	 	      
	 	      dhPublicKey.setKeyValue(receiverPublicKey);
	          keyMaterial.setNonce(randomReceiver);
	          dhPublicKey.setParameters("Ephemeral public key");
	          LocalDateTime ldt = LocalDateTime.now(ZoneOffset.UTC);
	          ldt.plusDays(1);
	          dhPublicKey.setExpiry(ldt+"");
	          keyMaterial.dhPublicKey(dhPublicKey);
	         
	 	      hiRequestHiRequest.setKeyMaterial(keyMaterial);
	 	      
	 	      hiRequest.setHiRequest(hiRequestHiRequest);
	 	      
	 	      
	 	      gatewayApi.v05HealthInformationCmRequestPost(hiRequest, accessToken, AuthKeys.X_CM_ID);
	 	       
	        	
     	}catch(Exception e) {
     		
     	}
		   
		
		return new ResponseEntity<Void>(HttpStatus.ACCEPTED);
	}
    
    public ResponseEntity<Void> v05ConsentsHiuNotifyPost(@ApiParam(value = "Access token which was issued after successful login with gateway auth server." ,required=true) @RequestHeader(value="Authorization", required=true) String authorization
    		,@ApiParam(value = "Identifier of the health information user to which the request was intended." ,required=true) @RequestHeader(value="X-HIU-ID", required=true) String X_HIU_ID
    		,@ApiParam(value = "" ,required=true )  @Valid @RequestBody HIUConsentNotificationEvent body
    		) {
    				
    				System.out.println("HIU- consentHiuNotify----");
    				String accept = request.getHeader("Accept");
    		        ObjectMapper mapper = new ObjectMapper();
    		        GatewayApi gatewayApi =   new GatewayApi();
    				SessionRequest sessReq = new SessionRequest();
    				sessReq.clientId(AuthKeys.X_CLIENT_ID);
		        	sessReq.clientSecret(AuthKeys.AUTHORIZATION_TOKEN);
		        	try {
						SessionResponse sessResp = gatewayApi.v05SessionsPost(sessReq);
						String accessToken = sessResp.getAccessToken();
			        	
			        	accessToken ="bearer "+accessToken;
						String jsonObject = mapper.writeValueAsString(body);
						System.out.println("HIUConsentNotificationEvent" + jsonObject.toString());
						String consentId = body.getNotification().getConsentRequestId();
	    		    	List<ConsentArtefactReference> artefacts = body.getNotification().getConsentArtefacts();
	    		    	List<ConsentRequest> lstConsentRequest = consentRepository.findByConsentId(consentId);
	    		    	if(lstConsentRequest!=null && lstConsentRequest.listIterator().hasNext()) {
	    		    		ConsentArtefactReference ref = null;
	    		    		ListIterator<ConsentArtefactReference>  iteratorLst = artefacts.listIterator();
	    		    		while(iteratorLst.hasNext()) {
	    		    			ref = iteratorLst.next();
	    		    			ConsentArtefacts consentArtefacts = new ConsentArtefacts();
	        		    		consentArtefacts.setConsentId(consentId);
	        		    		consentArtefacts.setConsentArtefactId(ref.getId());
	        		    		consentArtefacts = consentArtefactsRepository.save(consentArtefacts);
	        		    		/**
	        		    		 * call consent/fetch
	        		    		 */
	        		    		ConsentFetchRequest consentFetchRequest = new ConsentFetchRequest();
	        		        	consentFetchRequest.setConsentId(ref.getId());
	        		        	consentFetchRequest.setRequestId(UUID.randomUUID());
	        		        	consentFetchRequest.setTimestamp(LocalDateTime.now(ZoneOffset.UTC)+"");
	        		        	System.out.println("ConsentFetchRequest:::"+new ObjectMapper().writeValueAsString(consentFetchRequest));
	        		        	gatewayApi.v05ConsentsFetchPost(consentFetchRequest,accessToken,AuthKeys.X_CM_ID);
	        		    		
	        		    	}
	    		    	}
						
					} catch (ApiException | JsonProcessingException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
		        	
    		    	return new ResponseEntity<Void>(HttpStatus.ACCEPTED);
    		        
    		    }
    
    
    public ResponseEntity<Void> v05ConsentRequestsOnInitPost(@ApiParam(value = "Access token which was issued after successful login with gateway auth server." ,required=true) @RequestHeader(value="Authorization", required=true) String authorization
    		,@ApiParam(value = "Identifier of the health information user to which the request was intended." ,required=true) @RequestHeader(value="X-HIU-ID", required=true) String X_HIU_ID
    		,@ApiParam(value = "" ,required=true )  @RequestBody ConsentRequestInitResponse body
    		) {
    		        String accept = request.getHeader("Accept");
    		        
    		        System.out.println("In consent request on Init controller");
    		    	ObjectMapper mapper = new ObjectMapper();
    		    	try {
						String jsonObject = mapper.writeValueAsString(body);
						System.out.println("JsonObject" + jsonObject.toString());
					} catch (JsonProcessingException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
    		    	
    		    	String consentReqId = body.getResp().getRequestId()+"";
    		    	String consentId = body.getConsentRequest().getId()+"";
    		    	System.out.println("ConsentId----"+consentId);
    		    	ConsentRequest consentRequest = null;
    		    	List<ConsentRequest> lstConsentRequest = consentRepository.findByConsentId(consentReqId);
    		    	ListIterator<ConsentRequest> iterator = lstConsentRequest.listIterator();
    		    	
    		    	while(iterator.hasNext()) {
    		    		consentRequest = iterator.next();
    		    		consentRequest.setConsentId(consentId);
    		    		consentRequest = consentRepository.save(consentRequest);
    		    		if(consentRequest!=null) {
    		    			System.out.println("Consent ID updated");
    		    			
    		    		}
    		    	}
    		    	
    		        return new ResponseEntity<Void>(HttpStatus.ACCEPTED);
    		        
    		    }
    

    public ResponseEntity<Void> v05CareContextsDiscoverPost(@ApiParam(value = "Access token which was issued after successful login with gateway auth server, which will be sent by gateway to authenticate itself with API bridge." ,required=true) @RequestHeader(value="Authorization", required=true) String authorization
,@ApiParam(value = "Identifier of the health information provider to which the request was intended." ,required=true) @RequestHeader(value="X-HIP-ID", required=true) String X_HIP_ID
,@ApiParam(value = "" ,required=true )  @Valid @RequestBody PatientDiscoveryRequest body
) {
    	System.out.println("In discovery controller");
    	
        String accept = request.getHeader("Accept");
        GatewayApi gatewayApi = new  GatewayApi();
        
        /**
         * Saving the request
         */
        String hospId = X_HIP_ID;
        String authorizationToken = authorization;
        String requestId = body.getRequestId()+"";
        String requestTimestanmp=body.getTimestamp()+"";
        String transactionId=body.getTransactionId()+"";
        ObjectMapper mapper = new ObjectMapper();
        
        String requestBody=null;;
		try {
			requestBody = mapper.writeValueAsString(body);
		} catch (JsonProcessingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        
        HipRequest hipRequest = new HipRequest();
        hipRequest.setRequestBody(requestBody);
        hipRequest.setRequestId(requestId);
        hipRequest.setRequestTimestanmp(requestTimestanmp);
        hipRequest.setTransactionId(transactionId);
        hipRequest.setRequestType("discover");
        hipRequest.setHospRegId(hospId);
        hipRequest.setAuthoriszation(authorizationToken);
        
        hipRequest = hipRequestRepository.save(hipRequest);
       
        String patientId = body.getPatient().getId();
        String patientName = body.getPatient().getName();
        GenderEnum gender = body.getPatient().getGender();
        String yearOfBirth = body.getPatient().getYearOfBirth()+"";
        IdentifierType verifedIdentifierType = body.getPatient().getVerifiedIdentifiers().get(0).getType();
        String verifedIdentifierValue = body.getPatient().getVerifiedIdentifiers().get(0).getValue()+"";
        PatientSearchVO patientSearchVO = new PatientSearchVO();
        patientSearchVO.setPatId(patientId);
        patientSearchVO.setPatName(patientName);
        patientSearchVO.setHospId(hospId);
        if(verifedIdentifierType.equals(IdentifierType.MOBILE)) {
        	if(verifedIdentifierValue.length()>10) {
        	String[] arrOfStr = verifedIdentifierValue.split("-");
        	patientSearchVO.setMobileNo(arrOfStr[1]);
        	}else {
        	patientSearchVO.setMobileNo(verifedIdentifierValue);
        	}
        
        }
        
        List<PatientVO> listPatients = emrService.getPatientListById(patientSearchVO);
        
        PatientDiscoveryResult discoveryResult =  new PatientDiscoveryResult();
        UUID resultRequestId = UUID.randomUUID();
        UUID resultTransactionId = UUID.fromString(transactionId);
        
        discoveryResult.setRequestId(resultRequestId);
        discoveryResult.setTransactionId(resultTransactionId);
       
        LocalDateTime ldt = LocalDateTime.now(ZoneOffset.UTC);
        discoveryResult.setTimestamp(ldt+"");
        ListIterator<PatientVO> iterator = listPatients.listIterator();
        
        Error err = new Error();
        PatientRepresentation patient =  new PatientRepresentation();
        if(!listPatients.isEmpty()) {
        	
             while(iterator.hasNext()) {
             	PatientVO patientVO = iterator.next();
             	
             	try {
			 		patient.setDisplay(patientVO.getName());
             		patient.setReferenceNumber(patientVO.getPatId());
             	    patient.addMatchedByItem(IdentifierType.MR);
                } catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			     CareContextRepresentation carecontextrep =  new CareContextRepresentation();
                 carecontextrep.setReferenceNumber(patientVO.getVisitId());
                 carecontextrep.setDisplay("Visited on "+patientVO.getRegDate()+ " Visit Type as " +patientVO.getVisitType());
                 patient.addCareContextsItem(carecontextrep);
             }
             
        }
        else {
        	err.setCode("3404");
        	err.setMessage("No Records Found");
        	 discoveryResult.setError(err);
        	 try {
     			requestBody = mapper.writeValueAsString(discoveryResult);
     			System.out.println("RequestBody --"+requestBody.toString());
     		} catch (JsonProcessingException e) {
     			// TODO Auto-generated catch block
     			e.printStackTrace();
     		}
        	 
        }
        
        discoveryResult.setPatient(patient);
        RequestReference respRef = new RequestReference();
        respRef.setRequestId(UUID.fromString(requestId));
        discoveryResult.setResp(respRef);
        
       
        SessionRequest sessReq = new SessionRequest();
        try {
        	sessReq.clientId(AuthKeys.X_CLIENT_ID);
        	sessReq.clientSecret(AuthKeys.AUTHORIZATION_TOKEN);
        	SessionResponse sessResp = gatewayApi.v05SessionsPost(sessReq);
        	
        	String accessToken = sessResp.getAccessToken();
        	
        	accessToken ="bearer "+accessToken;
        	String resultBody = null;
        	try {
				resultBody = mapper.writeValueAsString(discoveryResult);
				System.out.println("resultBody-on-discover  "+resultBody.toString());
			} catch (JsonProcessingException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
        	
        	
        	gatewayApi.v05CareContextsOnDiscoverPost(discoveryResult, accessToken, AuthKeys.X_CM_ID);
		} catch (ApiException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        
        if(hipRequest!=null) {
        	
        	
        	return new ResponseEntity<Void>(HttpStatus.ACCEPTED);
        	 
        }else {
        	 return new ResponseEntity<Void>(HttpStatus.FAILED_DEPENDENCY);
        }
        
    }

    public ResponseEntity<Void> v05CareContextsOnDiscoverPost(@ApiParam(value = "Access token which was issued after successful login with gateway auth server, which will be sent by gateway to authenticate itself with API bridge." ,required=true) @RequestHeader(value="Authorization", required=true) String authorization
,@ApiParam(value = "Suffix of the consent manager to which the request was intended." ,required=true) @RequestHeader(value="X-CM-ID", required=true) String X_CM_ID
,@ApiParam(value = "" ,required=true )  @Valid @RequestBody PatientDiscoveryResult body
) {
        String accept = request.getHeader("Accept");
        return new ResponseEntity<Void>(HttpStatus.NOT_IMPLEMENTED);
    }

    public ResponseEntity<Certs> v05CertsGet() {
        String accept = request.getHeader("Accept");
        if (accept != null && accept.contains("application/json")) {
            try {
                return new ResponseEntity<Certs>(objectMapper.readValue("{\n  \"keys\" : [ {\n    \"kty\" : \"kty\",\n    \"x5t#S256\" : \"x5t#S256\",\n    \"e\" : \"e\",\n    \"use\" : \"use\",\n    \"x5t\" : \"x5t\",\n    \"kid\" : \"kid\",\n    \"x5c\" : [ \"x5c\", \"x5c\" ],\n    \"alg\" : \"alg\",\n    \"n\" : \"n\"\n  }, {\n    \"kty\" : \"kty\",\n    \"x5t#S256\" : \"x5t#S256\",\n    \"e\" : \"e\",\n    \"use\" : \"use\",\n    \"x5t\" : \"x5t\",\n    \"kid\" : \"kid\",\n    \"x5c\" : [ \"x5c\", \"x5c\" ],\n    \"alg\" : \"alg\",\n    \"n\" : \"n\"\n  } ]\n}", Certs.class), HttpStatus.NOT_IMPLEMENTED);
            } catch (IOException e) {
                log.error("Couldn't serialize response for content type application/json", e);
                return new ResponseEntity<Certs>(HttpStatus.INTERNAL_SERVER_ERROR);
            }
        }
        return new ResponseEntity<Certs>(HttpStatus.NOT_IMPLEMENTED);
    }

 public ResponseEntity<Void> v05ConsentsHipNotifyPost(@ApiParam(value = "Access token which was issued after successful login with gateway auth server, which will be sent by gateway to authenticate itself with API bridge." ,required=true) @RequestHeader(value="Authorization", required=true) String authorization
,@ApiParam(value = "Identifier of the health information provider to which the request was intended." ,required=true) @RequestHeader(value="X-HIP-ID", required=true) String X_HIP_ID
,@ApiParam(value = "" ,required=true )  @Valid @RequestBody HIPConsentNotification body
) {
        String accept = request.getHeader("Accept");
        
        System.out.println("In Hip Notify");
        GatewayApi gatewayApi = new  GatewayApi();
        
        /**
         * Saving the request
         */
        String hospId = X_HIP_ID;
        String authorizationToken = authorization;
        String requestId = body.getRequestId()+"";
        String requestTimestanmp=body.getTimestamp()+"";
        ObjectMapper mapper = new ObjectMapper();
        String requestBody=null;;
		try {
			requestBody = mapper.writeValueAsString(body);
			System.out.println("HIPConsentNotification---"+requestBody);
		} catch (JsonProcessingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
        HipRequest hipRequest = new HipRequest();
        hipRequest.setRequestBody(requestBody);
        hipRequest.setRequestId(requestId);
        hipRequest.setRequestTimestanmp(requestTimestanmp);
        hipRequest.setTransactionId(body.getNotification().getConsentId()+"");
        hipRequest.setRequestType("hip-notify");
        hipRequest.setHospRegId(hospId);
        hipRequest.setAuthoriszation(authorizationToken);
        hipRequest = hipRequestRepository.save(hipRequest);
        
       String consentId = body.getNotification().getConsentId().toString();
       HIPConsentNotificationNotificationConsentDetail consentDtls = body.getNotification().getConsentDetail();
       List<HIPConsentNotificationNotificationConsentDetailCareContexts> careContexts = null;
       ListIterator<HIPConsentNotificationNotificationConsentDetailCareContexts> lstIterator = null;
       if(consentDtls!=null) {
    	   careContexts = body.getNotification().getConsentDetail().getCareContexts();
    	   if(careContexts!=null) {
           lstIterator = careContexts.listIterator();
    	   }
       }
       
       List<HipConsentRequest> consentRequests = new ArrayList<HipConsentRequest>();
       List<HITypeEnum> listItems = null;
       if(body.getNotification()!=null) {
    	   if(body.getNotification().getConsentDetail()!=null) {
    		   if(body.getNotification().getConsentDetail().getHiTypes()!=null) {
    			   listItems = body.getNotification().getConsentDetail().getHiTypes();
    			 
    		   }
    	   }
       }
 
       HipConsentRequest consentRequestE = new HipConsentRequest();
	   consentRequestE.setConsentId(consentId);
	   
	   if(listItems!=null && listItems.contains(HITypeEnum.DIAGNOSTICREPORT)) {
		   consentRequestE.setLabYn("Y");
	   }
	   if(listItems!=null && listItems.contains(HITypeEnum.DISCHARGESUMMARY)) {
		   consentRequestE.setDischargeYn("Y");
	   }
	   if(listItems!=null && listItems.contains(HITypeEnum.MEDICATIONREQUEST)) {
		   consentRequestE.setPrescriptionYn("Y");
	   }
	   if(listItems!=null && listItems.contains(HITypeEnum.OPCONSULTATION)) {
		   consentRequestE.setOpYn("Y");
	   }
	   
	   consentRequestE.setFaclityId(consentDtls.getHip().getId());
	   consentRequestE.setConsentCreatedDt(consentDtls.getCreatedAt());
	   consentRequestE.setConsentExpiryDt(consentDtls.getPermission().getDataEraseAt());
	   consentRequestE.setHealthInfoFromDt(consentDtls.getPermission().getDateRange().getFrom());
	   consentRequestE.setHealthInfoToDt(consentDtls.getPermission().getDateRange().getTo());
	   consentRequestE.setSwasthyaId(consentDtls.getPatient().getId());
	   consentRequestE.setPurpose(consentDtls.getPurpose().getCode());
	   consentRequests.add(consentRequestE);
	  
	   String visitId = "";
       if(lstIterator!=null) {
    	   while(lstIterator.hasNext()) {
    		   
        	   HIPConsentNotificationNotificationConsentDetailCareContexts careContext = lstIterator.next();
        	   if(visitId.equalsIgnoreCase("")) {
        		   visitId = careContext.getCareContextReference();
        	   }else {
        		   visitId = visitId +","+ careContext.getCareContextReference();
        	   }
           }
    	   consentRequestE.setVisitId(visitId);
       }
       
       consentRequests = hipConsentRepository.saveAll(consentRequests);
       
        
        HIPConsentNotificationResponse hipConsentNotificationResponse = new HIPConsentNotificationResponse();
        UUID resultRequestId = UUID.randomUUID();
        LocalDateTime ldt = LocalDateTime.now(ZoneOffset.UTC);
        hipConsentNotificationResponse.setRequestId(resultRequestId);
        hipConsentNotificationResponse.setTimestamp(ldt+"");
        
       ConsentAcknowledgement acknowledgement = new ConsentAcknowledgement();
       acknowledgement.setConsentId(body.getNotification().getConsentId()+"");
       acknowledgement.setStatus(StatusEnum.OK);
        hipConsentNotificationResponse.setAcknowledgement(acknowledgement);
        RequestReference ref = new RequestReference();
        ref.setRequestId(UUID.fromString(requestId));
        hipConsentNotificationResponse.setResp(ref);
        
        SessionRequest sessReq = new SessionRequest();
        try {
        	sessReq.clientId(AuthKeys.X_CLIENT_ID);
        	sessReq.clientSecret(AuthKeys.AUTHORIZATION_TOKEN);
        	SessionResponse sessResp = gatewayApi.v05SessionsPost(sessReq);
        	
        	String accessToken = sessResp.getAccessToken();
        	
        	accessToken ="Bearer "+accessToken;
        	
        	System.out.println("hipConsentNotificationResponse  "+ new ObjectMapper().writeValueAsString(hipConsentNotificationResponse));
        	 	gatewayApi.v05ConsentsHipOnNotifyPost(hipConsentNotificationResponse, accessToken, AuthKeys.X_CM_ID);
        	 	
		} catch (ApiException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (JsonProcessingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        
        if(hipRequest!=null) {
        	return new ResponseEntity<Void>(HttpStatus.ACCEPTED);
        }else {
        	 return new ResponseEntity<Void>(HttpStatus.FAILED_DEPENDENCY);
        }
    }
 
 
 

    public ResponseEntity<Void> v05ConsentsHipOnNotifyPost(@ApiParam(value = "Access token which was issued after successful login with gateway auth server, which will be sent by gateway to authenticate itself with API bridge." ,required=true) @RequestHeader(value="Authorization", required=true) String authorization
,@ApiParam(value = "Suffix of the consent manager to which the request was intended." ,required=true) @RequestHeader(value="X-CM-ID", required=true) String X_CM_ID
,@ApiParam(value = "" ,required=true )  @Valid @RequestBody HIPConsentNotificationResponse body
) {
        String accept = request.getHeader("Accept");
        return new ResponseEntity<Void>(HttpStatus.NOT_IMPLEMENTED);
    }

    public ResponseEntity<Void> v05HealthInformationHipOnRequestPost(@ApiParam(value = "Access token which was issued after successful login with gateway auth server, which will be sent by gateway to authenticate itself with API bridge." ,required=true) @RequestHeader(value="Authorization", required=true) String authorization
,@ApiParam(value = "Suffix of the consent manager to which the request was intended." ,required=true) @RequestHeader(value="X-CM-ID", required=true) String X_CM_ID
,@ApiParam(value = "" ,required=true )  @Valid @RequestBody HIPHealthInformationRequestAcknowledgement body
) {
        String accept = request.getHeader("Accept");
        return new ResponseEntity<Void>(HttpStatus.NOT_IMPLEMENTED);
    }

    public ResponseEntity<Void> v05HealthInformationHipRequestPost(@ApiParam(value = "Access token which was issued after successful login with gateway auth server, which will be sent by gateway to authenticate itself with API bridge." ,required=true) @RequestHeader(value="Authorization", required=true) String authorization
,@ApiParam(value = "Identifier of the health information provider to which the request was intended." ,required=true) @RequestHeader(value="X-HIP-ID", required=true) String X_HIP_ID
,@ApiParam(value = "" ,required=true )  @Valid @RequestBody HIPHealthInformationRequest body
) {
        String accept = request.getHeader("Accept");
        
        System.out.println("HealthInformation/hip/request");
        
        GatewayApi gatewayApi = new  GatewayApi();
        
        /**
         * Saving the request
         */
        String hospId = X_HIP_ID;
        String authorizationToken = authorization;
        String requestId = body.getRequestId()+"";
        String requestTimestanmp=body.getTimestamp()+"";
        String transactionId=body.getTransactionId()+"";
        ObjectMapper mapper = new ObjectMapper();
        String requestBody=null;;
		try {
			requestBody = mapper.writeValueAsString(body);
		} catch (JsonProcessingException e) {
			// TODO Auto-generated catch block
		}
		
        HipRequest hipRequest = new HipRequest();
        hipRequest.setRequestBody(requestBody);
        hipRequest.setRequestId(requestId);
        hipRequest.setRequestTimestanmp(requestTimestanmp);
        hipRequest.setTransactionId(transactionId);
        hipRequest.setRequestType("hip-request");
        hipRequest.setHospRegId(hospId);
        hipRequest.setAuthoriszation(authorizationToken);
        
        hipRequest = hipRequestRepository.save(hipRequest);
        
        HIPHealthInfoRequest healthInfoRequest =  new HIPHealthInfoRequest();
        String consentId = body.getHiRequest().getConsent().getId();
        String cryptoAlg = body.getHiRequest().getKeyMaterial().getCryptoAlg();
        String curve = body.getHiRequest().getKeyMaterial().getCurve();
        String dataPushUrl = body.getHiRequest().getDataPushUrl();
        String dateRangeFrom = body.getHiRequest().getDateRange().getFrom();
        String dateRangeTo = body.getHiRequest().getDateRange().getTo();
        String nonce = body.getHiRequest().getKeyMaterial().getNonce();
        String publicKeyExpiry = body.getHiRequest().getKeyMaterial().getDhPublicKey().getExpiry();
        String publicKeyParam = body.getHiRequest().getKeyMaterial().getDhPublicKey().getParameters();
        String publicKeyValue = body.getHiRequest().getKeyMaterial().getDhPublicKey().getKeyValue();
        healthInfoRequest.setConsentId(consentId);
        healthInfoRequest.setCryptoAlg(cryptoAlg);
        healthInfoRequest.setCurve(curve);
        healthInfoRequest.setDataPushUrl(dataPushUrl);
        healthInfoRequest.setDateRangeFrom(dateRangeFrom);
        healthInfoRequest.setDateRangeTo(dateRangeTo);
        healthInfoRequest.setNonce(nonce);
        healthInfoRequest.setPublicKeyExpiry(publicKeyExpiry);
        healthInfoRequest.setPublicKeyParam(publicKeyParam);
        healthInfoRequest.setPublicKeyValue(publicKeyValue);
        healthInfoRequest.setUpdatedAt(new Date());
        healthInfoRequest.setCreatedAt(new Date());
        
        hipHealthInfoRequestRepository.save(healthInfoRequest);
        
        HIPHealthInformationRequestAcknowledgement hipHealthInformationRequestAcknowledgement = new HIPHealthInformationRequestAcknowledgement();
        UUID resultRequestId = UUID.randomUUID();
        UUID resultTransactionId = UUID.fromString(transactionId);
        LocalDateTime ldt = LocalDateTime.now(ZoneOffset.UTC);
        
        hipHealthInformationRequestAcknowledgement.setRequestId(resultRequestId);
        hipHealthInformationRequestAcknowledgement.setTimestamp(ldt+"");
        HIPHealthInformationRequestAcknowledgementHiRequest hiRequest =  new HIPHealthInformationRequestAcknowledgementHiRequest();
        hiRequest.setTransactionId(resultTransactionId);
        hiRequest.setSessionStatus(HIPHealthInformationRequestAcknowledgementHiRequest.SessionStatusEnum.ACKNOWLEDGED);
        hipHealthInformationRequestAcknowledgement.setHiRequest(hiRequest);
        RequestReference resp = new RequestReference();
        resp.setRequestId(UUID.fromString(requestId));
        hipHealthInformationRequestAcknowledgement.setResp(resp);
        
        SessionRequest sessReq = new SessionRequest();
        try {
        	sessReq.clientId(AuthKeys.X_CLIENT_ID);
        	sessReq.clientSecret(AuthKeys.AUTHORIZATION_TOKEN);
        	SessionResponse sessResp = gatewayApi.v05SessionsPost(sessReq);
        	
        	String accessToken = sessResp.getAccessToken();
        	
        	accessToken ="bearer "+accessToken;
        	gatewayApi.v05HealthInformationHipOnRequestPost(hipHealthInformationRequestAcknowledgement, accessToken, AuthKeys.X_CM_ID);
        	System.out.println("consentId in "+consentId);
        	 Date resultFrom = null;
        	 Date resultTo = null;
        	
        	List<HipConsentRequest> consentLst = hipConsentRepository.findByConsentId(consentId);
        	HipConsentRequest consent = null;
        	
        	if(consentLst!=null && consentLst.listIterator().hasNext()) {
        		consent= consentLst.listIterator().next();
        	}
        	List<PatientVisitDetails>  lstPatientVisitDetails = null;
        	PatientVisitDetails patientVisitDetails = null;
        	String visitId = null;
        	LocalDate frmdateIn =null;
        	LocalDate todateIn =null;
        	String[] values = null;
        	 List<Long> ids = new ArrayList<Long>();
        	if(consent!=null) {
	        	 visitId = consent.getVisitId();
	        	 String frmdateInString = consent.getHealthInfoFromDt().substring(0,19);
	        	 String todateInString = consent.getHealthInfoToDt().substring(0,19);
	        	 System.out.println("=======================================================");
	        	 System.out.println("Form dates===before"+frmdateInString);
	        	 System.out.println("To dates===before"+todateInString);
	        	 
	        	 Instant instantFrom = Instant.parse(frmdateInString+"Z");
	        	 Instant instantTo = Instant.parse(todateInString+"Z");
	        	 
	        	 
	             System.out.println("Instant From : " + instantFrom);
	             System.out.println("Instant To : " + instantTo);
	             
	             //get date time only
	              resultFrom = Date.from(instantFrom);// ofInstant(instantFrom, ZoneId.of("Asia/Kolkata"));
	              resultTo = Date.from(instantTo);//, ZoneId.of("Asia/Kolkata"));

	             //get localdate
	             System.out.println("LocalDate : resultFrom" + resultFrom);
	             System.out.println("LocalDate : resultTo" + resultTo);

	        	 
	        	 System.out.println("Visit Ids"+visitId);
	        	 
	        	 if(visitId.contains(",")) {
	        	 values = visitId.split(",");
	        	 for(int i=0;i<values.length;i++) {
	        		 ids.add(new Long(values[i]));
	        	 }
	        	 
	        	 }else {
	        		 ids.add(new Long(visitId));
	        	 }
	        	
	        	 if(visitId!=null) {
	        		System.out.println();
	        		//lstPatientVisitDetails =  patientVisitRepository.findWithVisitIds(ids);  1337144 for date range condition inclusion
	        		lstPatientVisitDetails =  patientVisitRepository.findWithVisitIdsDtRange(ids, resultFrom, resultTo);
	        	}
        	}
        	String diagnosticReport = null;
        	String dischargeSummary = null;
        	String OpconsultingNote = null;
        	String prescriptionNote = null;
        	ListIterator<PatientVisitDetails>  lstIterator = null;
        	if(lstPatientVisitDetails!=null) {
        	 lstIterator = lstPatientVisitDetails.listIterator();
        	}
        	DataNotification dataNotification = new DataNotification();
    	 	
    	 	dataNotification.setPageCount(1);
    	 	dataNotification.setPageNumber(1);
    	 	dataNotification.setTransactionId(body.getTransactionId());
    		String careContextId = null;
        	EntryContent entryContent = null;
        	
    		KeyPair senderKeyPair = DHKeyExchangeCrypto.generateKeyPair();
            String senderPrivateKey = DHKeyExchangeCrypto.getBase64String(DHKeyExchangeCrypto.getEncodedPrivateKey(senderKeyPair.getPrivate()));
            String senderPublicKey =  DHKeyExchangeCrypto.getBase64String(DHKeyExchangeCrypto.getEncodedPublicKey(senderKeyPair.getPublic())); 
            String randomSender = DHKeyExchangeCrypto.generateRandomKey(); 
            String randomReceiver = nonce; 
            // Generating Xor of random Keys
            byte[] xorOfRandom = DHKeyExchangeCrypto.xorOfRandom(randomSender, randomReceiver);
            
            KeyMaterial keyMaterial = new KeyMaterial();
            keyMaterial.cryptoAlg(DHKeyExchangeCrypto.ALGORITHM);
            keyMaterial.curve(DHKeyExchangeCrypto.CURVE);
            KeyObject dhPublicKey =  new KeyObject();
            dhPublicKey.setKeyValue(senderPublicKey);
            keyMaterial.setNonce(randomSender);
            dhPublicKey.setParameters("Ephemeral public key");
            LocalDateTime ldt1 = LocalDateTime.now(ZoneOffset.UTC);
            ldt1.plusDays(1);
            dhPublicKey.setExpiry(ldt1+"");
            keyMaterial.dhPublicKey(dhPublicKey);
            dataNotification.setKeyMaterial(keyMaterial);
            
        	while(lstIterator!=null && lstIterator.hasNext()) {
        		
        		patientVisitDetails = lstIterator.next();
        		careContextId = patientVisitDetails.getVisitId()+"";
        		if(patientVisitDetails!=null) {
            		if(consent.getLabYn()!=null && consent.getLabYn().equalsIgnoreCase("Y") && patientVisitDetails.getDiagnosticReportYn()!=null && patientVisitDetails.getDiagnosticReportYn().equalsIgnoreCase("Y")) {
            			System.out.println("Lab reports requested");
            			diagnosticReport = fhirService.createFhirResource("diagnostic", patientVisitDetails,resultFrom,resultTo);
            		}
    				if(consent.getOpYn()!=null && consent.getOpYn().equalsIgnoreCase("Y") && patientVisitDetails.getClinicalNotesYn()!=null && patientVisitDetails.getClinicalNotesYn().equalsIgnoreCase("Y")) {
    					System.out.println("Consulting notes requested");
    					OpconsultingNote = fhirService.createFhirResource("opconsultation", patientVisitDetails,resultFrom,resultTo);			
    				}
    				if(consent.getDischargeYn()!=null && consent.getDischargeYn().equalsIgnoreCase("Y") && patientVisitDetails.getDischargeSummaryYn()!=null && patientVisitDetails.getDischargeSummaryYn().equalsIgnoreCase("Y")) {
    					System.out.println("Discharge Summary requested");
    					dischargeSummary = fhirService.createFhirResource("dischargesummary", patientVisitDetails,resultFrom,resultTo);
    				}
    				if(consent.getPrescriptionYn()!=null && consent.getPrescriptionYn().equalsIgnoreCase("Y") && patientVisitDetails.getPrescriptionYn()!=null && patientVisitDetails.getPrescriptionYn().equalsIgnoreCase("Y")) {
    					System.out.println("Prescription requested");
    					prescriptionNote = fhirService.createFhirResource("medication", patientVisitDetails,resultFrom,resultTo);
    				}
            	}
        		
        		List<EntryContent> entries = DHKeyExchangeCrypto.encryptNew(careContextId, xorOfRandom,randomSender, senderPrivateKey, publicKeyValue, nonce, diagnosticReport, OpconsultingNote, dischargeSummary, prescriptionNote);
        		ListIterator<EntryContent> iteratorEntries = entries.listIterator();
        			while(iteratorEntries.hasNext()) {
        				entryContent = iteratorEntries.next();
        				dataNotification.addEntriesItem(entryContent);
        		}
            	
        	}
        		
            	try {
            	gatewayApi.v05HealthInformationTransferPost(dataNotification,dataPushUrl, accessToken);
            	}catch(Exception e) {
            		
            	}
		} catch (ApiException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        
        if(hipRequest!=null) {
        	
        	
        	return new ResponseEntity<Void>(HttpStatus.ACCEPTED);
        	 
        }else {
        	 return new ResponseEntity<Void>(HttpStatus.FAILED_DEPENDENCY);
        }
        
    }

    public ResponseEntity<Void> v05HealthInformationNotifyPost(@ApiParam(value = "Access token which was issued after successful login with gateway auth server, which will be sent by gateway to authenticate itself with API bridge." ,required=true) @RequestHeader(value="Authorization", required=true) String authorization
,@ApiParam(value = "Suffix of the consent manager to which the request was intended." ,required=true) @RequestHeader(value="X-CM-ID", required=true) String X_CM_ID
,@ApiParam(value = "" ,required=true )  @Valid @RequestBody HealthInformationNotification body
) {
        String accept = request.getHeader("Accept");
        return new ResponseEntity<Void>(HttpStatus.NOT_IMPLEMENTED);
    }

    public ResponseEntity<Void> v05HealthInformationTransferPost(@ApiParam(value = "Access token which was issued after successful login with gateway auth server, which will be sent by gateway to authenticate itself with API bridge." ,required=true) @RequestHeader(value="Authorization", required=true) String authorization
,@ApiParam(value = "" ,required=true )  @Valid @RequestBody DataNotification body
) {
        String accept = request.getHeader("Accept");
        GatewayApi gatewayApi = new  GatewayApi(); 
        ObjectMapper obj = new ObjectMapper();
        String transactionId = null;
        SessionResponse sessResp = null;
        List<EntryContent> entries = null;
        ListIterator<EntryContent>  lstIterator = null;
        KeyMaterial keyMeterial = null;
        EntryContent entryContent = null;
        SessionRequest sessReq = new SessionRequest();
        SessionResponse sessRes = new SessionResponse();
        sessReq.clientId(AuthKeys.X_CLIENT_ID);
    	sessReq.clientSecret(AuthKeys.AUTHORIZATION_TOKEN);
    	HiuConsentRequest hiuConsentRequest = null;
    	String hipNonce = null;
    	String hiuNonce = null;
    	String hipPublicKeyValue = null;
    	String hiuPublicKeyValue = null;
    	String hiuPrivateKeyValue = null;
    	String decryptedContent = null;
    	String careContextRef = null;
    	HIDocuments hiDocuments = null;
    	String accessToken = null;
    	
    	List<HealthInformationNotificationNotificationStatusNotificationStatusResponses> statusResponses = new ArrayList<HealthInformationNotificationNotificationStatusNotificationStatusResponses>();
    	HealthInformationNotificationNotificationStatusNotificationStatusResponses healthInformationNotificationNotificationStatusNotificationStatusResponses = null;
        		try {
	        	    transactionId = body.getTransactionId()+"";
	        	    
	        	    List<HiuConsentRequest> lstConsents = hiuConsentRepository.findByconsentTxnNum(transactionId); 
	        	    if(lstConsents!=null) {
	        	    	hiuConsentRequest = lstConsents.listIterator().next();
	        	    }
	        	    if(hiuConsentRequest!=null) {
	        	    	hiuNonce = hiuConsentRequest.getNonce();
	        	    	hiuPublicKeyValue = hiuConsentRequest.getPublicKeyValue();
	        	    	hiuPrivateKeyValue = hiuConsentRequest.getPrivateKeyValue();
	        	    }
	        	    
	        	    keyMeterial = body.getKeyMaterial();
	        	    hipNonce = keyMeterial.getNonce();
	        	    hipPublicKeyValue = keyMeterial.getDhPublicKey().getKeyValue();
	        	    byte[] xorOfRandom = DHKeyExchangeCrypto.xorOfRandom(hipNonce, hiuNonce); 
	        	    
	        	    entries = body.getEntries();
	        	    lstIterator = entries.listIterator();
	            	while(lstIterator.hasNext())
	            	{
	            		entryContent = lstIterator.next();
	            		decryptedContent = Decryptor.decryptHiu(xorOfRandom, hiuPrivateKeyValue, hipPublicKeyValue,entryContent.getContent());
	            		hiDocuments = new HIDocuments();
	            		hiDocuments.setCareContextDisplay(entryContent.getCareContextReference());
	            		hiDocuments.setConsentTxnNum(transactionId);
	            		hiDocuments.setFhirObject(decryptedContent);
	            		hiDocumentsRepository.save(hiDocuments);
	            		healthInformationNotificationNotificationStatusNotificationStatusResponses = new HealthInformationNotificationNotificationStatusNotificationStatusResponses();
	            		healthInformationNotificationNotificationStatusNotificationStatusResponses.setCareContextReference(entryContent.getCareContextReference());
	            		healthInformationNotificationNotificationStatusNotificationStatusResponses.setHiStatus(HiStatusEnum.DELIVERED);
	            		statusResponses.add(healthInformationNotificationNotificationStatusNotificationStatusResponses);
	            	}
	            	hiuConsentRequest.setConsentTxnStatus("DELIVERED");
	            	hiuConsentRepository.save(hiuConsentRequest);
        		}catch(Exception e) {
            		e.printStackTrace();
            	}
            	
				 HealthInformationNotification healthInformationNotification = new   HealthInformationNotification();
				 healthInformationNotification.setRequestId(UUID.randomUUID());
				 healthInformationNotification.setTimestamp(LocalDateTime.now(ZoneOffset.UTC)+""); 
				
				 HealthInformationNotificationNotification notification = new  HealthInformationNotificationNotification();
				 notification.setTransactionId(UUID.fromString(transactionId));
				 notification.setConsentId(UUID.fromString(hiuConsentRequest.getConsentId()));
				 notification.setDoneAt("HIU");
				 
				 HealthInformationNotificationNotificationNotifier healthInformationNotificationNotificationNotifier = new HealthInformationNotificationNotificationNotifier();
				 healthInformationNotificationNotificationNotifier.setId(transactionId);
				 healthInformationNotificationNotificationNotifier.setType(TypeEnum.HIU);
				 notification.setNotifier(healthInformationNotificationNotificationNotifier);
				 HealthInformationNotificationNotificationStatusNotification healthInformationNotificationNotificationStatusNotification = new HealthInformationNotificationNotificationStatusNotification();
				 healthInformationNotificationNotificationStatusNotification.setHipId(hiuConsentRequest.getFaclityId());
				 healthInformationNotificationNotificationStatusNotification.setSessionStatus(HealthInformationNotificationNotificationStatusNotification.SessionStatusEnum.TRANSFERRED);
				 healthInformationNotificationNotificationStatusNotification.setStatusResponses(statusResponses);
				 notification.setStatusNotification(healthInformationNotificationNotificationStatusNotification);
				 healthInformationNotification.setNotification(notification);
				 try {
					sessRes = gatewayApi.v05SessionsPost(sessReq);
					accessToken = "Bearer "+sessRes.getAccessToken();
					gatewayApi.v05HealthInformationNotifyPost(healthInformationNotification, accessToken, AuthKeys.X_CM_ID);
				} catch (ApiException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
        	
        
        return new ResponseEntity<Void>(HttpStatus.ACCEPTED);
    }

    public ResponseEntity<HeartbeatResponse> v05HeartbeatGet() {
        String accept = request.getHeader("Accept");
        if (accept != null && accept.contains("application/json")) {
            try {
                return new ResponseEntity<HeartbeatResponse>(objectMapper.readValue("{\n  \"error\" : {\n    \"code\" : 0,\n    \"message\" : \"message\"\n  },\n  \"timestamp\" : \"2000-01-23T04:56:07.000+00:00\",\n  \"status\" : \"UP\"\n}", HeartbeatResponse.class), HttpStatus.ACCEPTED);
            } catch (IOException e) {
                log.error("Couldn't serialize response for content type application/json", e);
                return new ResponseEntity<HeartbeatResponse>(HttpStatus.INTERNAL_SERVER_ERROR);
            }
        }

        return new ResponseEntity<HeartbeatResponse>(HttpStatus.ACCEPTED);
    }

    public ResponseEntity<Void> v05LinksLinkAddContextsPost(@ApiParam(value = "Access token which was issued after successful login with gateway auth server, which will be sent by gateway to authenticate itself with API bridge." ,required=true) @RequestHeader(value="Authorization", required=true) String authorization
,@ApiParam(value = "Suffix of the consent manager to which the request was intended." ,required=true) @RequestHeader(value="X-CM-ID", required=true) String X_CM_ID
,@ApiParam(value = "" ,required=true )  @Valid @RequestBody PatientCareContextLinkRequest body
) {
        String accept = request.getHeader("Accept");
        return new ResponseEntity<Void>(HttpStatus.NOT_IMPLEMENTED);
    }

    public ResponseEntity<Void> v05LinksLinkConfirmPost(@ApiParam(value = "Access token which was issued after successful login with gateway auth server, which will be sent by gateway to authenticate itself with API bridge." ,required=true) @RequestHeader(value="Authorization", required=true) String authorization
,@ApiParam(value = "Identifier of the health information provider to which the request was intended." ,required=true) @RequestHeader(value="X-HIP-ID", required=true) String X_HIP_ID
,@ApiParam(value = "" ,required=true )  @Valid @RequestBody LinkConfirmationRequest body
) {
        String accept = request.getHeader("Accept");
        /**
         * Link Confirm Request
         */
        System.out.println("In link confirm controller");
    	
        GatewayApi gatewayApi = new  GatewayApi();
        
        /**
         * Saving the request
         */
        String hospId = X_HIP_ID;
        String authorizationToken = authorization;
        String requestId = body.getRequestId()+"";
        String requestTimestanmp=body.getTimestamp()+"";
        LinkConfirmationRequestConfirmation linkConfirm = body.getConfirmation();
        String linkRefereceNumber=linkConfirm.getLinkRefNumber();
        
        ObjectMapper mapper = new ObjectMapper();
        
        String requestBody=null;;
		try {
			requestBody = mapper.writeValueAsString(body);
		} catch (JsonProcessingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        
        
        HipRequest hipRequest = new HipRequest();
        hipRequest.setRequestBody(requestBody);
        hipRequest.setRequestId(requestId);
        hipRequest.setRequestTimestanmp(requestTimestanmp);
        hipRequest.setTransactionId(linkRefereceNumber);
        hipRequest.setRequestType("link confirm");
        hipRequest.setHospRegId(hospId);
        hipRequest.setAuthoriszation(authorizationToken);
        
        hipRequest = hipRequestRepository.save(hipRequest);
        
        
       
        PatientLinkResult patientLinkResult = new PatientLinkResult();
        patientLinkResult.setRequestId(UUID.randomUUID());
      	LocalDateTime ldt = LocalDateTime.now(ZoneOffset.UTC);
        
        patientLinkResult.setTimestamp(ldt+"");
        PatientLinkResultPatient patientLinkResultPatient = new PatientLinkResultPatient();
        patientLinkResultPatient.setReferenceNumber(linkRefereceNumber);
        PatientVisitDetails patientVisit = null;
        
        if(body.getConfirmation().getLinkRefNumber()!=null) {
         patientVisit = patientVisitRepository.getOne(new Long(body.getConfirmation().getLinkRefNumber()));
        }else
        {
         patientVisit = patientVisitRepository.getOne(0l);
        }
        
        List<CareContextRepresentation> careContexts = new ArrayList<CareContextRepresentation>();
        if(patientVisit!=null) {
        	String disgnosticReportYN = patientVisit.getDiagnosticReportYn();
        	String prescriptionYN = patientVisit.getPrescriptionYn();
        	String opConsulationYN = patientVisit.getClinicalNotesYn();
        	String dischargeSummaryYN = patientVisit.getDiagnosticReportYn();
        	CareContextRepresentation careContext1 =  new CareContextRepresentation();
        	careContext1.setReferenceNumber(patientVisit.getVisitId()+"");
        	String displayText = "";
        	careContext1.setDisplay("");
        	if(disgnosticReportYN!=null && disgnosticReportYN.equalsIgnoreCase("Y")) {
        		displayText=displayText+"Diagnostic Report ";
        	}
        	if(prescriptionYN!=null && prescriptionYN.equalsIgnoreCase("Y")) {
        		if(displayText.equalsIgnoreCase("")) {
        			displayText="Prescription";
        		}else {
        			displayText=displayText+",Prescription";
        		}
        		
        	}
        	if(opConsulationYN!=null && opConsulationYN.equalsIgnoreCase("Y")) {
        		if(displayText.equalsIgnoreCase("")) {
        			displayText="Clinical Consultation Report";
        		}else {
        			displayText=displayText+",Clinical Consultation Report";
        		}
        		
        	}
        	if(dischargeSummaryYN!=null && dischargeSummaryYN.equalsIgnoreCase("Y")) {
        		if(displayText.equalsIgnoreCase("")) {
        			displayText="Discharge Summary";
        		}else {
        			displayText=displayText+",Discharge Summary";
        		}
        	}
        	if(displayText.equalsIgnoreCase("")){
        		displayText = "No Data Available";
        	}else
        	{
        		displayText =displayText+ " Available";
        	}
        	careContext1.setDisplay(displayText);
        	careContexts.add(careContext1);
        	
        	patientLinkResultPatient.setCareContexts(careContexts);
            patientLinkResultPatient.setDisplay("Patient Visit Details");
            patientLinkResult.setPatient(patientLinkResultPatient);
            
            RequestReference ref = new RequestReference();
            ref.setRequestId(UUID.fromString(requestId));
            patientLinkResult.setResp(ref);
        }
         
        SessionRequest sessReq = new SessionRequest();
        try {
        	sessReq.clientId(AuthKeys.X_CLIENT_ID);
        	sessReq.clientSecret(AuthKeys.AUTHORIZATION_TOKEN);
        	SessionResponse sessResp = gatewayApi.v05SessionsPost(sessReq);
        	
        	String accessToken = sessResp.getAccessToken();
        	
        	accessToken ="Bearer "+accessToken;
        	
        	try{
        		gatewayApi.v05LinksLinkOnConfirmPost(patientLinkResult, accessToken, AuthKeys.X_CM_ID);
        	}catch(Exception e) {
        		e.printStackTrace();
        	}
        
        } catch (ApiException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        
        if(hipRequest!=null) {
        	
        	return new ResponseEntity<Void>(HttpStatus.ACCEPTED);
        	 
        }else {
        	 return new ResponseEntity<Void>(HttpStatus.FAILED_DEPENDENCY);
        }
     
    }

    public ResponseEntity<Void> v05LinksLinkInitPost(@ApiParam(value = "Access token which was issued after successful login with gateway auth server, which will be sent by gateway to authenticate itself with API bridge." ,required=true) @RequestHeader(value="Authorization", required=true) String authorization
,@ApiParam(value = "Identifier of the health information provider to which the request was intended." ,required=true) @RequestHeader(value="X-HIP-ID", required=true) String X_HIP_ID
,@ApiParam(value = "" ,required=true )  @Valid @RequestBody PatientLinkReferenceRequest body
) {
    	
        String accept = request.getHeader("Accept");
        System.out.println("In the liniking process");
       
    	
        
        GatewayApi gatewayApi = new  GatewayApi();
        
        /**
         * Saving the request
         */
        String hospId = X_HIP_ID;
        String authorizationToken = authorization;
        String requestId = body.getRequestId()+"";
        String requestTimestanmp=body.getTimestamp()+"";
        String transactionId=body.getTransactionId()+"";
        ObjectMapper mapper = new ObjectMapper();
        String requestBody=null;;
		try {
			requestBody = mapper.writeValueAsString(body);
		} catch (JsonProcessingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        
        
        HipRequest hipRequest = new HipRequest();
        hipRequest.setRequestBody(requestBody);
        hipRequest.setRequestId(requestId);
        hipRequest.setRequestTimestanmp(requestTimestanmp);
        hipRequest.setTransactionId(transactionId);
        hipRequest.setRequestType("link");
        hipRequest.setHospRegId(hospId);
        hipRequest.setAuthoriszation(authorizationToken);
        
        hipRequest = hipRequestRepository.save(hipRequest);
        
        PatientLinkReferenceResult linkResult =  new PatientLinkReferenceResult();
        UUID resultRequestId = UUID.randomUUID();
        UUID resultTransactionId = UUID.fromString(transactionId);
        
        linkResult.setRequestId(resultRequestId);
        linkResult.setTransactionId(resultTransactionId);
        LocalDateTime ldt = LocalDateTime.now(ZoneOffset.UTC);
        
        linkResult.setTimestamp(ldt+"");
        PatientLinkReferenceResultLink link = new PatientLinkReferenceResultLink();
        link.setAuthenticationType(AuthenticationTypeEnum.MEDIATED);
        Meta meta = new Meta();
        meta.communicationExpiry(ldt.plusMinutes(5).toString());
        meta.communicationHint("NDHM - emrweb");
        meta.communicationMedium(CommunicationMediumEnum.M0BILE);
        /***
         * OTP to be sent from HIP and that needs to be validated 
         */        
        
        link.setMeta(meta);
        link.setReferenceNumber(body.getPatient().getCareContexts().get(0).getReferenceNumber());
        linkResult.setLink(link);
        
        
        RequestReference respRef = new RequestReference();
        respRef.setRequestId(UUID.fromString(requestId));
        linkResult.setResp(respRef);
       
        SessionRequest sessReq = new SessionRequest();
        try {
        	sessReq.clientId(AuthKeys.X_CLIENT_ID);
        	sessReq.clientSecret(AuthKeys.AUTHORIZATION_TOKEN);
        	SessionResponse sessResp = gatewayApi.v05SessionsPost(sessReq);
        	
        	String accessToken = sessResp.getAccessToken();
        	
        	accessToken ="Bearer "+accessToken;
        	
        	
        	
        	gatewayApi.v05LinksLinkOnInitPost(linkResult, accessToken, AuthKeys.X_CM_ID);
        	
        } catch (ApiException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        
        if(hipRequest!=null) {
        	
        	
        	return new ResponseEntity<Void>(HttpStatus.ACCEPTED);
        	 
        }else {
        	 return new ResponseEntity<Void>(HttpStatus.FAILED_DEPENDENCY);
        }
         
    }

    public ResponseEntity<Void> v05LinksLinkOnAddContextsPost(@ApiParam(value = "Access token which was issued after successful login with gateway auth server, which will be sent by gateway to authenticate itself with API bridge." ,required=true) @RequestHeader(value="Authorization", required=true) String authorization
,@ApiParam(value = "Identifier of the health information provider to which the request was intended." ,required=true) @RequestHeader(value="X-HIP-ID", required=true) String X_HIP_ID
,@ApiParam(value = "" ,required=true )  @Valid @RequestBody PatientCareContextLinkResponse body
) {
        String accept = request.getHeader("Accept");
        return new ResponseEntity<Void>(HttpStatus.NOT_IMPLEMENTED);
    }

    public ResponseEntity<Void> v05LinksLinkOnConfirmPost(@ApiParam(value = "Access token which was issued after successful login with gateway auth server, which will be sent by gateway to authenticate itself with API bridge." ,required=true) @RequestHeader(value="Authorization", required=true) String authorization
,@ApiParam(value = "Suffix of the consent manager to which the request was intended." ,required=true) @RequestHeader(value="X-CM-ID", required=true) String X_CM_ID
,@ApiParam(value = "" ,required=true )  @Valid @RequestBody PatientLinkResult body
) {
        String accept = request.getHeader("Accept");
        return new ResponseEntity<Void>(HttpStatus.NOT_IMPLEMENTED);
    }

    public ResponseEntity<Void> v05LinksLinkOnInitPost(@ApiParam(value = "Access token which was issued after successful login with gateway auth server, which will be sent by gateway to authenticate itself with API bridge." ,required=true) @RequestHeader(value="Authorization", required=true) String authorization
,@ApiParam(value = "Suffix of the consent manager to which the request was intended." ,required=true) @RequestHeader(value="X-CM-ID", required=true) String X_CM_ID
,@ApiParam(value = "" ,required=true )  @Valid @RequestBody PatientLinkReferenceResult body
) {
        String accept = request.getHeader("Accept");
        return new ResponseEntity<Void>(HttpStatus.NOT_IMPLEMENTED);
    }

    public ResponseEntity<SessionResponse> v05SessionsPost(@ApiParam(value = "" ,required=true )  @Valid @RequestBody SessionRequest body
) {
        String accept = request.getHeader("Accept");
        if (accept != null && accept.contains("application/json")) {
            try {
                return new ResponseEntity<SessionResponse>(objectMapper.readValue("{\n  \"expiresIn\" : 1800,\n  \"accessToken\" : \"eyJhbGciOiJSUzI1Ni.IsInR5cCIgOiAiSldUIiwia2lkIiA6ICJrVVp.2MXJQMjRyYXN1UW9wU2lWbkdZQUZIVFowYVZGVWpYNXFLMnNibTk0In0\",\n  \"tokenType\" : \"bearer\",\n  \"refreshExpiresIn\" : 1800,\n  \"refreshToken\" : \"eyJhbGciOiJSUzI1Ni.IsInR5cCIgOiAiSldUIiwia2lkIiA6ICJrVVp.2MXJQMjRyYXN1UW9wU2lWbkdZQUZIVFowYVZGVWpYNXFLMnNibTk0In0\"\n}", SessionResponse.class), HttpStatus.NOT_IMPLEMENTED);
            } catch (IOException e) {
                log.error("Couldn't serialize response for content type application/json", e);
                return new ResponseEntity<SessionResponse>(HttpStatus.INTERNAL_SERVER_ERROR);
            }
        }

        return new ResponseEntity<SessionResponse>(HttpStatus.NOT_IMPLEMENTED);
    }

    public ResponseEntity<Void> v05UsersAuthConfirmPost(@ApiParam(value = "Access token which was issued after successful login with gateway auth server, which will be sent by gateway to authenticate itself with API bridge." ,required=true) @RequestHeader(value="Authorization", required=true) String authorization
,@ApiParam(value = "Suffix of the consent manager to which the request was intended." ,required=true) @RequestHeader(value="X-CM-ID", required=true) String X_CM_ID
,@ApiParam(value = "" ,required=true )  @Valid @RequestBody PatientAuthConfirmRequest body
) {
        String accept = request.getHeader("Accept");
        return new ResponseEntity<Void>(HttpStatus.NOT_IMPLEMENTED);
    }

    public ResponseEntity<Void> v05UsersAuthInitPost(@ApiParam(value = "Access token which was issued after successful login with gateway auth server, which will be sent by gateway to authenticate itself with API bridge." ,required=true) @RequestHeader(value="Authorization", required=true) String authorization
,@ApiParam(value = "Suffix of the consent manager to which the request was intended." ,required=true) @RequestHeader(value="X-CM-ID", required=true) String X_CM_ID
,@ApiParam(value = "" ,required=true )  @Valid @RequestBody PatientAuthInitRequest body
) {
        String accept = request.getHeader("Accept");
        return new ResponseEntity<Void>(HttpStatus.NOT_IMPLEMENTED);
    }

    public ResponseEntity<Void> v05UsersAuthOnFetchModesPost(@RequestHeader(value="Authorization", required=true) String authorization
    		,@RequestHeader(value="X-HIP-ID", required=true) String X_HIP_ID
    		,@Valid @RequestBody PatientAuthModeQueryResponse body
    		) {
    		       
    		        
    		        GatewayApi gatewayApi = new  GatewayApi();
    		 		
    		 		 try {
    		        
    		 			System.out.println("request body of on-fetch-modes=="+new ObjectMapper().writeValueAsString(body));
    		 			
    		 			String requestId = body.getRequestId().toString();
        		        String refereceNumber = body.getResp().getRequestId().toString();
        		        
        		        List<AuthenticationMode> modes = body.getAuth().getModes();
        		        
        		        SessionRequest sessReq = new SessionRequest();
    		 			sessReq.clientId(AuthKeys.X_CLIENT_ID);
    		         	sessReq.clientSecret(AuthKeys.AUTHORIZATION_TOKEN);
    		         	SessionResponse sessResp = gatewayApi.v05SessionsPost(sessReq);
    		         	String accessToken = sessResp.getAccessToken();
    		         	accessToken ="bearer "+accessToken;
    		         	PatientAuthInitRequest initRequest =  new PatientAuthInitRequest();
    		        	initRequest.setRequestId(UUID.randomUUID());
    		        	LocalDateTime ldt = LocalDateTime.now(ZoneOffset.UTC);
    		        	initRequest.setTimestamp(ldt+"");
    		        	
	    		         PatientAuthInitRequestQuery authInitRequestQuery = new  PatientAuthInitRequestQuery();
	    				 authInitRequestQuery.setAuthMode(AuthenticationMode.DEMOGRAPHICS);
	    				 authInitRequestQuery.setId("yagnesh1@sbx");
	    				 authInitRequestQuery.setPurpose(PatientAuthPurpose.LINK);
	    				 PatientAuthInitRequestQueryRequester patientAuthInitRequestQueryRequester = new PatientAuthInitRequestQueryRequester();
	    				 patientAuthInitRequestQueryRequester.setId(AuthKeys.X_HIP_ID);
	    				 patientAuthInitRequestQueryRequester.setType(PatientAuthInitRequestQueryRequester.TypeEnum.HIP);
	    				 authInitRequestQuery.setRequester(patientAuthInitRequestQueryRequester);
	    				 initRequest.setQuery(authInitRequestQuery);
	    				 gatewayApi.v05UsersAuthInitPost(initRequest, accessToken, AuthKeys.X_CM_ID);
	    		         }catch(Exception e) {
    		        	 
	    		         }
    		        
    		        
    		        return new ResponseEntity<Void>(HttpStatus.ACCEPTED);
     }

    
    
    public ResponseEntity<Void> v05UsersAuthOnConfirmPost(@ApiParam(value = "Access token which was issued after successful login with gateway auth server, which will be sent by gateway to authenticate itself with API bridge." ,required=true) @RequestHeader(value="Authorization", required=true) String authorization
,@ApiParam(value = "Identifier of the health information provider to which the request was intended." ,required=true) @RequestHeader(value="X-HIP-ID", required=true) String X_HIP_ID
,@ApiParam(value = "" ,required=true ) @RequestBody PatientAuthConfirmResponse body
) {
        String accept = request.getHeader("Accept");
        ObjectMapper mapper = new ObjectMapper();
        
        GatewayApi gatewayApi =  new GatewayApi();
        try {
			System.out.println("v05UsersAuthOnConfirmPost======"+mapper.writeValueAsString(body));
			String accessToken = null;
			if(body.getAuth()!=null) {
			 accessToken = body.getAuth().getAccessToken();
			}
			String hipInitRequestId = body.getResp().getRequestId().toString();
			
			 List<HipInitRequest> hipInitRequestLst =  hipInitRepository.findByRefInitId(hipInitRequestId);
		       ListIterator<HipInitRequest> hipInitRequestIterator  = hipInitRequestLst.listIterator();
		       HipInitRequest hipInitRequest = null;
		       if(hipInitRequestIterator!=null && hipInitRequestIterator.hasNext()) {
		    	   hipInitRequest = hipInitRequestIterator.next();
		    	  
		       }
		       
			
			PatientCareContextLinkRequest patientCareContextLinkRequest = new PatientCareContextLinkRequest();
			patientCareContextLinkRequest.setRequestId(UUID.randomUUID());
			patientCareContextLinkRequest.setTimestamp(LocalDateTime.now(ZoneOffset.UTC)+""); 
				
		 	PatientCareContextLink patientCareContextLink = new PatientCareContextLink();
			patientCareContextLink.setAccessToken(accessToken);
			PatientCareContextLinkPatient patient = new PatientCareContextLinkPatient();
			patient.setDisplay(hipInitRequest.getName());
			patient.setReferenceNumber(hipInitRequest.getTransactionId());
			List<CareContextRepresentation> lstCareContexts = new ArrayList<CareContextRepresentation>();
			
			PatientSearchVO patientSearchVO = new PatientSearchVO();
	        patientSearchVO.setPatId(hipInitRequest.getHealthId());
	       
	        List<PatientVO> listPatients = emrService.getPatientListById(patientSearchVO);
	        ListIterator<PatientVO> iterator = listPatients.listIterator();
	        Error err = new Error();
	        CareContextRepresentation careContextRepresentation = null;
	        if(!listPatients.isEmpty()) {
	             while(iterator.hasNext()) {
	             	PatientVO patientVO = iterator.next();
	             	
	             	try {
	             		 careContextRepresentation = new CareContextRepresentation();
	             		careContextRepresentation.setReferenceNumber(patientVO.getVisitId());
	             		careContextRepresentation.setDisplay(patientVO.getVisitType());
	             	} catch (Exception e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
	             	lstCareContexts.add(careContextRepresentation);
				    
	             }
	        }
	    	patient.setCareContexts(lstCareContexts);
			patientCareContextLink.setPatient(patient);
			patientCareContextLinkRequest.setLink(patientCareContextLink);
			
			 SessionRequest sessReq = new SessionRequest();
		        try {
		        	sessReq.clientId(AuthKeys.X_CLIENT_ID);
		        	sessReq.clientSecret(AuthKeys.AUTHORIZATION_TOKEN);
		        	SessionResponse sessResp = gatewayApi.v05SessionsPost(sessReq);
		        	accessToken = sessResp.getAccessToken();
		        	accessToken ="Bearer "+accessToken;
		        	if(body.getAuth()!=null) {
		        	gatewayApi.v05LinksLinkAddContextsPost(patientCareContextLinkRequest, accessToken, AuthKeys.X_CM_ID);
		        	}
		        } catch (ApiException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		        
			
        } catch (JsonProcessingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        
        return new ResponseEntity<Void>(HttpStatus.ACCEPTED);
    }
    
    
    
    
    public ResponseEntity<Void> v05UsersAuthOnInitPost(@RequestHeader(value="Authorization", required=true) String authorization
,@RequestHeader(value="X-HIP-ID", required=true) String X_HIP_ID
,@RequestBody PatientAuthInitResponse body
) {
    	
    	System.out.println("In the v05UsersAuthOnInitPost method====");
    	
        String accept = request.getHeader("Accept");
        GatewayApi gatewayApi =  new GatewayApi();
        ObjectMapper mapper = new ObjectMapper();
        try {
			System.out.println("In on-init "+mapper.writeValueAsString(body));
		} catch (JsonProcessingException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
        
        String transactionId = body.getAuth().getTransactionId();
        String hipInitRequestId = body.getResp().getRequestId().toString();
        
       List<HipInitRequest> hipInitRequestLst =  hipInitRepository.findByReqId(hipInitRequestId);
       ListIterator<HipInitRequest> hipInitRequestIterator  = hipInitRequestLst.listIterator();
       HipInitRequest hipInitRequest = null;
       if(hipInitRequestIterator!=null && hipInitRequestIterator.hasNext()) {
    	   hipInitRequest = hipInitRequestIterator.next();
    	   
       }
        
        PatientAuthConfirmRequest patientAuthConfirmRequest= new PatientAuthConfirmRequest();
        
        String requestId = UUID.randomUUID().toString();
        patientAuthConfirmRequest.setRequestId(UUID.fromString(requestId));
        patientAuthConfirmRequest.setTimestamp(LocalDateTime.now(ZoneOffset.UTC)+"");
        patientAuthConfirmRequest.setTransactionId(transactionId);
        PatientAuthConfirmRequestCredential patientAuthConfirmRequestCredential = new PatientAuthConfirmRequestCredential();
        PatientDemographic patientDemographic = new PatientDemographic();
        patientAuthConfirmRequestCredential.setDemographic(patientDemographic);
        //1980-08-30
        patientDemographic.setDateOfBirth(hipInitRequest.getDob());
        patientDemographic.setGender(PatientGender.fromValue(hipInitRequest.getGender()));
        patientDemographic.setName(hipInitRequest.getName());
		
        patientAuthConfirmRequest.setCredential(patientAuthConfirmRequestCredential);
        
        hipInitRequest.setReferenceInit(requestId);
        hipInitRequest = hipInitRepository.save(hipInitRequest);
        
        SessionRequest sessReq = new SessionRequest();
        try {
        	sessReq.clientId(AuthKeys.X_CLIENT_ID);
        	sessReq.clientSecret(AuthKeys.AUTHORIZATION_TOKEN);
        	SessionResponse sessResp = gatewayApi.v05SessionsPost(sessReq);
        	String accessToken = sessResp.getAccessToken();
        	accessToken ="Bearer "+accessToken;
        	
        	gatewayApi.v05UsersAuthConfirmPost(patientAuthConfirmRequest, accessToken, AuthKeys.X_CM_ID);
        } catch (ApiException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        return new ResponseEntity<Void>(HttpStatus.ACCEPTED);
    }

    public ResponseEntity<OpenIdConfiguration> v05WellKnownOpenidConfigurationGet() {
        String accept = request.getHeader("Accept");
        if (accept != null && accept.contains("application/json")) {
            try {
                return new ResponseEntity<OpenIdConfiguration>(objectMapper.readValue("{\n  \"jwks_uri\" : \"https://ncg-gateway/certs\"\n}", OpenIdConfiguration.class), HttpStatus.NOT_IMPLEMENTED);
            } catch (IOException e) {
                log.error("Couldn't serialize response for content type application/json", e);
                return new ResponseEntity<OpenIdConfiguration>(HttpStatus.INTERNAL_SERVER_ERROR);
            }
        }

        return new ResponseEntity<OpenIdConfiguration>(HttpStatus.NOT_IMPLEMENTED);
    }
	/*
	 * // method to perform Xor of random keys private static byte []
	 * xorOfRandom(String randomKeySender, String randomKeyReceiver) { byte[]
	 * randomSender = DHKeyExchangeCrypto.getBytesForBase64String(randomKeySender);
	 * byte[] randomReceiver =
	 * DHKeyExchangeCrypto.getBytesForBase64String(randomKeyReceiver);
	 * 
	 * byte[] out = new byte[randomSender.length]; for (int i = 0; i <
	 * randomSender.length; i++) { out[i] = (byte) (randomSender[i] ^
	 * randomReceiver[i%randomReceiver.length]); } return out; }
	 */
    
    
	public ResponseEntity<Void> v05PatientsProfileShare(@ApiParam(value = "Access token which was issued after successful login with gateway auth server, which will be sent by gateway to authenticate itself with API bridge." ,required=true) @RequestHeader(value="Authorization", required=true) String authorization
,@ApiParam(value = "Identifier of the health information provider to which the request was intended." ,required=true) @RequestHeader(value="X-HIP-ID", required=true) String X_HIP_ID
,@ApiParam(value = "" ,required=true )  @Valid @RequestBody ProfileShareCallback body
) {
System.out.println("In Profile Share controller");
    	
        String accept = request.getHeader("Accept");
        GatewayApi gatewayApi = new  GatewayApi();
        
     
        
        /**
         * Saving the request 
         */
        
        String requestId = body.getRequestId()+"";
        
        String timestamp=body.getTimestamp();
        
        String hipCode = body.getProfile().getHipCode();
       
        String healthId=body.getProfile().getPatient().getHealthId();
       
        String healthIdNumber=body.getProfile().getPatient().getHealthIdNumber();
        
        String patientName = body.getProfile().getPatient().getName();
      
        Enum<PatientGender> gender = body.getProfile().getPatient().getGender();
       
        String addressLine=body.getProfile().getPatient().getAddress().getLine();
       
        String state=body.getProfile().getPatient().getAddress().getState();
       
        String district=body.getProfile().getPatient().getAddress().getDistrict();
       
        String pin=body.getProfile().getPatient().getAddress().getPincode();
       
        String yearOfBirth = body.getProfile().getPatient().getYearOfBirth()+"";
        
        String monthOfBirth = body.getProfile().getPatient().getMonthOfBirth()+"";
       
        String dayOfBirth = body.getProfile().getPatient().getDayOfBirth()+"";
        
        List<Identifier> idenTypeLsit=body.getProfile().getPatient().getIdentifiers();
        String idenType = null;
        String idenValue = null;
        if(!idenTypeLsit.isEmpty()) {
        	idenType = idenTypeLsit.get(0).getType().name();
        	 idenValue = idenTypeLsit.get(0).getValue();
        }
       
        ObjectMapper mapper = new ObjectMapper();
       
        try {
      
	        	List<HidCreate> hidCreate = hidCreateRepository.findByHipCode(hipCode);
	        	HidCreate hidObj = null;
	        	if(hidCreate!=null && !hidCreate.isEmpty()) {
	        		hidObj = hidCreate.get(0);
	        		
	        			hidObj.setRequestid(requestId);
	        			hidObj.setTimestamp(timestamp);
	        			hidObj.setHealthid(healthId);
	        			hidObj.setHealthIdnumber(healthIdNumber);
	        			hidObj.setName(patientName);
	        			hidObj.setGender(gender.name());
	        			hidObj.setAddressline(addressLine);
	        			hidObj.setState(state);
	        			hidObj.setDistrict(district);
	        			hidObj.setPin(pin);
	        			hidObj.setYearOfBirth(yearOfBirth);
	        			hidObj.setDayOfBirth(dayOfBirth);
	        			hidObj.setMonthOfBirth(monthOfBirth);
	        			hidObj.setIden_type(idenType);
	        			hidObj.setIden_value(idenValue);
	        			
	        			hidObj = hidCreateRepository.save(hidObj);
	        		
	        			System.out.println("Profile shared by Gateway successfully !!  "+mapper.writeValueAsString(body));
	        		 
	        	}

	        	// Starting to build  on-share async call 
	            ShareProfileResult patientShareResult =  new ShareProfileResult();
	            Error err = new Error();
	            UUID resultRequestId = UUID.randomUUID();
				patientShareResult.setRequestId(resultRequestId);
				LocalDateTime ldt = LocalDateTime.now(ZoneOffset.UTC);
				patientShareResult.setTimestamp(ldt + "");
				ShareProfileAcknowledgement acknowledgement = new ShareProfileAcknowledgement();
				if(hidObj!=null) {
				acknowledgement.setStatus(ShareProfileAcknowledgement.StatusEnum.SUCCESS);
				acknowledgement.setHealthId(healthIdNumber);
				patientShareResult.setAcknowledgement(acknowledgement);
				}else {
				err.setCode("1000");
				err.setMessage("Unknown Error");
				patientShareResult.setError(err);
				}
				
				RequestReference respRef = new RequestReference();
	      		respRef.setRequestId(UUID.fromString(requestId));
	      		patientShareResult.setResp(respRef);
	      		
	      		
	      		 SessionRequest sessReq = new SessionRequest();
	      	     try {
	      	     	sessReq.clientId(AuthKeys.X_CLIENT_ID);
	      	     	sessReq.clientSecret(AuthKeys.AUTHORIZATION_TOKEN);
	      	     	SessionResponse sessResp = gatewayApi.v05SessionsPost(sessReq);
	      	     	String accessToken = sessResp.getAccessToken();
	      	     	accessToken ="bearer "+accessToken;
	      	     	String resultBody = null;
	      	     	try {
	      					resultBody = mapper.writeValueAsString(patientShareResult);
	      					System.out.println("resultBody-on-share  "+resultBody.toString());
	      				} catch (JsonProcessingException e) {
	      					// TODO Auto-generated catch block
	      					e.printStackTrace();
	      				}
	      	     	gatewayApi.v05PatientsProfileOnSharePost(patientShareResult, accessToken, AuthKeys.X_CM_ID);
	      			} catch (ApiException e) {
	      				// TODO Auto-generated catch block
	      				e.printStackTrace();
	      			}
			
		} catch (Exception e) {
		
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
          
      	return new ResponseEntity<Void>(HttpStatus.OK);
   	     
        
	}

	
}
