package org.nha.emr.web.hip.model;

import java.util.Objects;
import java.util.UUID;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;

import org.springframework.validation.annotation.Validated;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonValue;

import io.swagger.annotations.ApiModelProperty;

/**
 * HIUHealthInformationRequestResponseHiRequest
 */
@Validated

public class HIUHealthInformationRequestResponseHiRequest   {
  @JsonProperty("transactionId")
  private UUID transactionId = null;

  /**
   * Gets or Sets sessionStatus
   */
  public enum SessionStatusEnum {
    REQUESTED("REQUESTED"),
    
    ACKNOWLEDGED("ACKNOWLEDGED");

    private String value;

    SessionStatusEnum(String value) {
      this.value = value;
    }

    @Override
    @JsonValue
    public String toString() {
      return String.valueOf(value);
    }

    @JsonCreator
    public static SessionStatusEnum fromValue(String text) {
      for (SessionStatusEnum b : SessionStatusEnum.values()) {
        if (String.valueOf(b.value).equals(text)) {
          return b;
        }
      }
      return null;
    }
  }
  @JsonProperty("sessionStatus")
  private SessionStatusEnum sessionStatus = null;

  public HIUHealthInformationRequestResponseHiRequest transactionId(UUID transactionId) {
    this.transactionId = transactionId;
    return this;
  }

  /**
   * Get transactionId
   * @return transactionId
  **/
  @ApiModelProperty(required = true, value = "")
      @NotNull

    @Valid
    public UUID getTransactionId() {
    return transactionId;
  }

  public void setTransactionId(UUID transactionId) {
    this.transactionId = transactionId;
  }

  public HIUHealthInformationRequestResponseHiRequest sessionStatus(SessionStatusEnum sessionStatus) {
    this.sessionStatus = sessionStatus;
    return this;
  }

  /**
   * Get sessionStatus
   * @return sessionStatus
  **/
  @ApiModelProperty(required = true, value = "")
      @NotNull

    public SessionStatusEnum getSessionStatus() {
    return sessionStatus;
  }

  public void setSessionStatus(SessionStatusEnum sessionStatus) {
    this.sessionStatus = sessionStatus;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    HIUHealthInformationRequestResponseHiRequest hiUHealthInformationRequestResponseHiRequest = (HIUHealthInformationRequestResponseHiRequest) o;
    return Objects.equals(this.transactionId, hiUHealthInformationRequestResponseHiRequest.transactionId) &&
        Objects.equals(this.sessionStatus, hiUHealthInformationRequestResponseHiRequest.sessionStatus);
  }

  @Override
  public int hashCode() {
    return Objects.hash(transactionId, sessionStatus);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class HIUHealthInformationRequestResponseHiRequest {\n");
    
    sb.append("    transactionId: ").append(toIndentedString(transactionId)).append("\n");
    sb.append("    sessionStatus: ").append(toIndentedString(sessionStatus)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
