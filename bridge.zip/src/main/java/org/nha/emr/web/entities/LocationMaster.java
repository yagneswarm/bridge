package org.nha.emr.web.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name = "locations_master_lgd")
public class LocationMaster implements java.io.Serializable{
	private static final long serialVersionUID = 1L;

	@Id
    @GeneratedValue(generator = "lgd_generator")
    @SequenceGenerator(
            name = "lgd_generator",
            sequenceName = "lgd_sequence",
            initialValue = 1
    )
	  private String sno;
	  
	  @Column(name = "state_code")
	    private String stateCode;
	  
	  @Column(name = "state_name")
	    private String stateName;
	  
	  @Column(name = "district_code")
	    private String districtCode;
	  
	  @Column(name = "district_name")
	    private String districtName;
	  
	  @Column(name = "sub_district_code")
	    private String sub_districtCode;
	  
	  @Column(name = "sub_district_name")
	    private String sub_districtName;
	  
	  @Column(name = "village_code")
	    private String villageCode;
	  
	  @Column(name = "village_name")
	    private String villageName;
	  
	  public String getVillageName() {
		return villageName;
	}

	public void setVillageName(String villageName) {
		this.villageName = villageName;
	}

	@Column(name = "block_code")
	    private String blockCode;
	  
	  @Column(name = "block_name")
	    private String blockName;
	  
	  @Column(name = "active_yn")
	    private String activeYn;



	/**
	 * 
	 */
	public LocationMaster() {
		// TODO Auto-generated constructor stub
	}

	public String getSno() {
		return sno;
	}

	public void setSno(String sno) {
		this.sno = sno;
	}

	public String getStateCode() {
		return stateCode;
	}

	public void setStateCode(String stateCode) {
		this.stateCode = stateCode;
	}

	public String getStateName() {
		return stateName;
	}

	public void setStateName(String stateName) {
		this.stateName = stateName;
	}

	public String getDistrictCode() {
		return districtCode;
	}

	public void setDistrictCode(String districtCode) {
		this.districtCode = districtCode;
	}

	public String getDistrictName() {
		return districtName;
	}

	public void setDistrictName(String districtName) {
		this.districtName = districtName;
	}

	public String getSub_districtCode() {
		return sub_districtCode;
	}

	public void setSub_districtCode(String sub_districtCode) {
		this.sub_districtCode = sub_districtCode;
	}

	public String getSub_districtName() {
		return sub_districtName;
	}

	public void setSub_districtName(String sub_districtName) {
		this.sub_districtName = sub_districtName;
	}

	public String getVillageCode() {
		return villageCode;
	}

	public void setVillageCode(String villageCode) {
		this.villageCode = villageCode;
	}

	public String getBlockCode() {
		return blockCode;
	}

	public void setBlockCode(String blockCode) {
		this.blockCode = blockCode;
	}

	public String getBlockName() {
		return blockName;
	}

	public void setBlockName(String blockName) {
		this.blockName = blockName;
	}

	public String getActiveYn() {
		return activeYn;
	}

	public void setActiveYn(String activeYn) {
		this.activeYn = activeYn;
	}


	  
	
}
