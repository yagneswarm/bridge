package org.nha.emr.web.hip.model;

import java.util.Objects;
import java.util.UUID;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;

import org.springframework.validation.annotation.Validated;

import com.fasterxml.jackson.annotation.JsonProperty;

import io.swagger.annotations.ApiModelProperty;

/**
 * ConsentRequestInitResponse
 */
@Validated

public class ConsentRequestInitResponse   {
  @JsonProperty("requestId")
  private UUID requestId = null;

  @JsonProperty("timestamp")
  private String timestamp = null;

  @JsonProperty("consentRequest")
  private ConsentRequestInitResponseConsentRequest consentRequest = null;

  @JsonProperty("error")
  private Error error = null;

  @JsonProperty("resp")
  private RequestReference resp = null;

  public ConsentRequestInitResponse requestId(UUID requestId) {
    this.requestId = requestId;
    return this;
  }

  /**
   * a nonce, unique for each HTTP request
   * @return requestId
  **/
  @ApiModelProperty(example = "5f7a535d-a3fd-416b-b069-c97d021fbacd", required = true, value = "a nonce, unique for each HTTP request")
      @NotNull

    @Valid
    public UUID getRequestId() {
    return requestId;
  }

  public void setRequestId(UUID requestId) {
    this.requestId = requestId;
  }

  public ConsentRequestInitResponse timestamp(String timestamp) {
    this.timestamp = timestamp;
    return this;
  }

  /**
   * Get timestamp
   * @return timestamp
  **/
  @ApiModelProperty(required = true, value = "")
      //@NotNull

    @Valid
    public String getTimestamp() {
    return timestamp;
  }

  public void setTimestamp(String timestamp) {
    this.timestamp = timestamp;
  }

  public ConsentRequestInitResponse consentRequest(ConsentRequestInitResponseConsentRequest consentRequest) {
    this.consentRequest = consentRequest;
    return this;
  }

  /**
   * Get consentRequest
   * @return consentRequest
  **/
  @ApiModelProperty(value = "")
  
    @Valid
    public ConsentRequestInitResponseConsentRequest getConsentRequest() {
    return consentRequest;
  }

  public void setConsentRequest(ConsentRequestInitResponseConsentRequest consentRequest) {
    this.consentRequest = consentRequest;
  }

  public ConsentRequestInitResponse error(Error error) {
    this.error = error;
    return this;
  }

  /**
   * Get error
   * @return error
  **/
  @ApiModelProperty(value = "")
  
    @Valid
    public Error getError() {
    return error;
  }

  public void setError(Error error) {
    this.error = error;
  }

  public ConsentRequestInitResponse resp(RequestReference resp) {
    this.resp = resp;
    return this;
  }

  /**
   * Get resp
   * @return resp
  **/
  @ApiModelProperty(required = true, value = "")
      @NotNull

    @Valid
    public RequestReference getResp() {
    return resp;
  }

  public void setResp(RequestReference resp) {
    this.resp = resp;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    ConsentRequestInitResponse consentRequestInitResponse = (ConsentRequestInitResponse) o;
    return Objects.equals(this.requestId, consentRequestInitResponse.requestId) &&
        Objects.equals(this.timestamp, consentRequestInitResponse.timestamp) &&
        Objects.equals(this.consentRequest, consentRequestInitResponse.consentRequest) &&
        Objects.equals(this.error, consentRequestInitResponse.error) &&
        Objects.equals(this.resp, consentRequestInitResponse.resp);
  }

  @Override
  public int hashCode() {
    return Objects.hash(requestId, timestamp, consentRequest, error, resp);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ConsentRequestInitResponse {\n");
    
    sb.append("    requestId: ").append(toIndentedString(requestId)).append("\n");
    sb.append("    timestamp: ").append(toIndentedString(timestamp)).append("\n");
    sb.append("    consentRequest: ").append(toIndentedString(consentRequest)).append("\n");
    sb.append("    error: ").append(toIndentedString(error)).append("\n");
    sb.append("    resp: ").append(toIndentedString(resp)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
