package org.nha.emr.web.client;

public interface AuthKeys {
	final String X_CM_ID ="sbx";
	final String X_CLIENT_ID ="WEBEMR011000003";
	final String AUTHORIZATION_TOKEN="21001c00-32be-418f-ab28-c70f3bfad516";
	//final String X_CLIENT_ID ="WEBEMR011000005";
	//final String AUTHORIZATION_TOKEN="19a876f4-be0e-469a-bd3e-c30ac195934d";
	//05 for beta and 03 for sbx hip bridge posting 
	final String X_HIP_ID="emrsbxtest01";
	final String X_HIU_ID="emrsbxtest02";
	//final String X_HIP_ID="EMRWEB-01";
	//final String X_HIU_ID="EMRWEB-01";
		
	//final String X_DATA_PUSH_URL="http://d570f392a1a6.ngrok.io/hip-bridge/v0.5/health-information/transfer";
	final String X_DATA_PUSH_URL="https://emrsbx.ndhm.gov.in/hip-bridge/v0.5/health-information/transfer";
}


