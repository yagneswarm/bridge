package org.nha.emr.web.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "hip_request")
public class HipRequest extends AuditModel{

	private static final long serialVersionUID = 1L;
	
	@Id
    private String requestId;
	
	@Column(name = "request_timestamp")
	private String requestTimestanmp;
	
	@Column(name = "transaction_id")
	private String transactionId;
	
	@Column(name = "request_type")
	private String requestType;
	
	
	@Column(name = "request_body",columnDefinition = "TEXT",nullable = true)
	private String requestBody;
	
	@Column(name = "request_served",nullable = true)
	private String requestServed;
	
	@Column(name = "authoriszation",nullable = true)
	private String authoriszation;
	
	@Column(name = "hosp_reg_id",nullable = true)
	private String hospRegId;
	
	
	
	
	public HipRequest() {
		// TODO Auto-generated constructor stub
	}

	
	
	public String getAuthoriszation() {
		return authoriszation;
	}



	public void setAuthoriszation(String authoriszation) {
		this.authoriszation = authoriszation;
	}



	public String getHospRegId() {
		return hospRegId;
	}



	public void setHospRegId(String hospRegId) {
		this.hospRegId = hospRegId;
	}



	public String getRequestId() {
		return requestId;
	}

	public void setRequestId(String requestId) {
		this.requestId = requestId;
	}

	public String getRequestTimestanmp() {
		return requestTimestanmp;
	}

	public void setRequestTimestanmp(String requestTimestanmp) {
		this.requestTimestanmp = requestTimestanmp;
	}

	public String getTransactionId() {
		return transactionId;
	}

	public void setTransactionId(String transactionId) {
		this.transactionId = transactionId;
	}

	public String getRequestBody() {
		return requestBody;
	}

	public void setRequestBody(String requestBody) {
		this.requestBody = requestBody;
	}

	public String getRequestServed() {
		return requestServed;
	}

	public void setRequestServed(String requestServed) {
		this.requestServed = requestServed;
	}

	public String getRequestType() {
		return requestType;
	}

	public void setRequestType(String requestType) {
		this.requestType = requestType;
	}

	
}
