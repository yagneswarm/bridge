package org.nha.emr.web.hip.api;


import org.nha.emr.web.entities.Patient;
import org.nha.emr.web.entities.PatientVisitDetails;
import org.nha.emr.web.repositories.PatientRepository;
import org.nha.emr.web.repositories.PatientVisitRepository;
import org.nha.emr.web.service.FhirService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class FhirController {

    @Autowired
    private FhirService fhirService;
    @Autowired
    private PatientRepository patientRepository;

    @Autowired
    private PatientVisitRepository patientVisitRepository;

    
    @GetMapping("/paient/{patientId}")
    public String getPatientFhirObject(@PathVariable Long patientId) {
    	
    	Patient patient = patientRepository.findBypatientId(patientId);
    	String fhirObject = fhirService.createFhirResource("patient", patient,null,null);
        return fhirObject;
    }

    @GetMapping("/patient/encounter/{visitId}")
    public String getEncounterFhirObject(@PathVariable Long visitId) {
    	
    	PatientVisitDetails patientVisitDtls = patientVisitRepository.findWithVisitId(visitId);
    	String fhirObject = fhirService.createFhirResource("encounter", patientVisitDtls,null,null);
        return fhirObject;
    }
    
    
    @GetMapping("/patient/medication/{visitId}")
    public String getMedicationFhirObject(@PathVariable Long visitId) {
    	
    	PatientVisitDetails patientVisitDtls = patientVisitRepository.findWithVisitId(visitId);
    	String fhirObject = fhirService.createFhirResource("medication", patientVisitDtls,null,null);
        return fhirObject;
    }
    
    @GetMapping("/patient/diagnosticreport/{visitId}")
    public String getDianosticFhirObject(@PathVariable Long visitId) {
    	
    	PatientVisitDetails patientVisitDtls = patientVisitRepository.findWithVisitId(visitId);
    	String fhirObject = fhirService.createFhirResource("diagnostic", patientVisitDtls,null,null);
        return fhirObject;
    }
    @GetMapping("/patient/opconsultion/{visitId}")
    public String getOpFhirObject(@PathVariable Long visitId) {
    	
    	PatientVisitDetails patientVisitDtls = patientVisitRepository.findWithVisitId(visitId);
    	String fhirObject = fhirService.createFhirResource("opconsultation", patientVisitDtls,null,null);
        return fhirObject;
    }
    
    @GetMapping("/patient/discharge/{visitId}")
    public String getDischargeFhirObject(@PathVariable Long visitId) {
    	
    	PatientVisitDetails patientVisitDtls = patientVisitRepository.findWithVisitId(visitId);
    	String fhirObject = fhirService.createFhirResource("dischargesummary", patientVisitDtls,null,null);
        return fhirObject;
    }
    
    
    
    }
