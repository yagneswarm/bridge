package org.nha.emr.web.entities;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.nha.emr.web.hip.model.IdentifierType;
import org.nha.emr.web.hip.model.PatientGender;

@Entity
@Table(name = "hpridcreate")
public class HidCreate extends AuditModel {

	private static final long serialVersionUID = 1L;
	
    @Column(name = "requestid")
	private String requestid;
	
	@Column(name = "timestamp")
	private String timestamp;
	
	@Id
	@Column(name = "hipcode")
	private String hipcode;
	
	@Column(name = "healthid")
	private String healthid;
	
	
	@Column(name = "healthIdnumber")
	private String healthIdnumber;
	
	@Column(name = "name")
	private String name;
	
	@Column(name = "gender")
	private String gender ;
	
	@Column(name = "addressline")
	private String addressline;
	
	@Column(name = "district")
	private String district;
	
	@Column(name = "state")
	private String state;
	
	@Column(name = "pin")
	private String pin;
	
	@Column(name = "yob")
	private String yearOfBirth;
	
	@Column(name = "dob")
	private String dayOfBirth;
	
	@Column(name = "mob")
	private String monthOfBirth;
	
	@Column(name = "iden_type")
	private String iden_type;
	
	@Column(name = "iden_value")
	private String iden_value;
	

	public String getRequestid() {
		return requestid;
	}

	public void setRequestid(String requestid) {
		this.requestid = requestid;
	}

	public String getTimestamp() {
		return timestamp;
	}

	public void setTimestamp(String timestamp) {
		this.timestamp = timestamp;
	}

	public String getHipcode() {
		return hipcode;
	}

	public void setHipcode(String hipcode) {
		this.hipcode = hipcode;
	}

	public String getHealthid() {
		return healthid;
	}

	public void setHealthid(String healthid) {
		this.healthid = healthid;
	}

	public String getHealthIdnumber() {
		return healthIdnumber;
	}

	public void setHealthIdnumber(String healthIdnumber) {
		this.healthIdnumber = healthIdnumber;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getAddressline() {
		return addressline;
	}

	public void setAddressline(String addressline) {
		this.addressline = addressline;
	}

	public String getDistrict() {
		return district;
	}

	public void setDistrict(String district) {
		this.district = district;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getPin() {
		return pin;
	}

	public void setPin(String pin) {
		this.pin = pin;
	}

	public String getYearOfBirth() {
		return yearOfBirth;
	}

	public void setYearOfBirth(String yearOfBirth) {
		this.yearOfBirth = yearOfBirth;
	}

	public String getDayOfBirth() {
		return dayOfBirth;
	}

	public void setDayOfBirth(String dayOfBirth) {
		this.dayOfBirth = dayOfBirth;
	}

	public String getMonthOfBirth() {
		return monthOfBirth;
	}

	public void setMonthOfBirth(String monthOfBirth) {
		this.monthOfBirth = monthOfBirth;
	}

	public String getIden_type() {
		return iden_type;
	}

	public void setIden_type(String idenType) {
		this.iden_type = idenType;
	}

	public String getIden_value() {
		return iden_value;
	}

	public void setIden_value(String iden_value) {
		this.iden_value = iden_value;
	}
	
	
	
}
