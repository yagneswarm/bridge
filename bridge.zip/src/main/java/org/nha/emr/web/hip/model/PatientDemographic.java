package org.nha.emr.web.hip.model;

import java.util.Objects;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;

import org.springframework.validation.annotation.Validated;

import com.fasterxml.jackson.annotation.JsonProperty;

import io.swagger.annotations.ApiModelProperty;

/**
 * Demographic details are only required for demographic auth at this point. Demographic details must be same as registered
 */
@Validated


public class PatientDemographic   {
  @JsonProperty("name")
  private String name = null;

  @JsonProperty("gender")
  private PatientGender gender = null;

  @JsonProperty("dateOfBirth")
  private String dateOfBirth = null;

  @JsonProperty("identifier")
  private Identifier identifier = null;

  public PatientDemographic name(String name) {
    this.name = name;
    return this;
  }

  /**
   * Get name
   * @return name
  **/
  @ApiModelProperty(example = "janki das", required = true, value = "")
      @NotNull

    public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }

  public PatientDemographic gender(PatientGender gender) {
    this.gender = gender;
    return this;
  }

  /**
   * Get gender
   * @return gender
  **/
  @ApiModelProperty(required = true, value = "")
      @NotNull

    @Valid
    public PatientGender getGender() {
    return gender;
  }

  public void setGender(PatientGender gender) {
    this.gender = gender;
  }

  public PatientDemographic dateOfBirth(String dateOfBirth) {
    this.dateOfBirth = dateOfBirth;
    return this;
  }

  /**
   * date of birth in YYYY-MM-DD format.
   * @return dateOfBirth
  **/
  @ApiModelProperty(example = "1972-02-29", required = true, value = "date of birth in YYYY-MM-DD format.")
      @NotNull

    public String getDateOfBirth() {
    return dateOfBirth;
  }

  public void setDateOfBirth(String dateOfBirth) {
    this.dateOfBirth = dateOfBirth;
  }

  public PatientDemographic identifier(Identifier identifier) {
    this.identifier = identifier;
    return this;
  }

  /**
   * Get identifier
   * @return identifier
  **/
  @ApiModelProperty(value = "")
  
    @Valid
    public Identifier getIdentifier() {
    return identifier;
  }

  public void setIdentifier(Identifier identifier) {
    this.identifier = identifier;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    PatientDemographic patientDemographic = (PatientDemographic) o;
    return Objects.equals(this.name, patientDemographic.name) &&
        Objects.equals(this.gender, patientDemographic.gender) &&
        Objects.equals(this.dateOfBirth, patientDemographic.dateOfBirth) &&
        Objects.equals(this.identifier, patientDemographic.identifier);
  }

  @Override
  public int hashCode() {
    return Objects.hash(name, gender, dateOfBirth, identifier);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class PatientDemographic {\n");
    
    sb.append("    name: ").append(toIndentedString(name)).append("\n");
    sb.append("    gender: ").append(toIndentedString(gender)).append("\n");
    sb.append("    dateOfBirth: ").append(toIndentedString(dateOfBirth)).append("\n");
    sb.append("    identifier: ").append(toIndentedString(identifier)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
