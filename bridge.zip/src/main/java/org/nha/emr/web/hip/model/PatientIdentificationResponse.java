package org.nha.emr.web.hip.model;

import java.time.LocalDateTime;
import java.util.Objects;
import java.util.UUID;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;

import org.springframework.validation.annotation.Validated;

import com.fasterxml.jackson.annotation.JsonProperty;


/**
 * PatientIdentificationResponse
 */
@Validated

public class PatientIdentificationResponse   {
  @JsonProperty("requestId")
  private UUID requestId = null;

  @JsonProperty("timestamp")
  private LocalDateTime timestamp = null;

  @JsonProperty("patient")
  private PatientIdentificationResponsePatient patient = null;

  @JsonProperty("error")
  private Error error = null;

  @JsonProperty("resp")
  private RequestReference resp = null;

  public PatientIdentificationResponse requestId(UUID requestId) {
    this.requestId = requestId;
    return this;
  }

  /**
   * a nonce, unique for each HTTP request
   * @return requestId
  **/
      @NotNull

    @Valid
    public UUID getRequestId() {
    return requestId;
  }

  public void setRequestId(UUID requestId) {
    this.requestId = requestId;
  }

  public PatientIdentificationResponse timestamp(LocalDateTime timestamp) {
    this.timestamp = timestamp;
    return this;
  }

  /**
   * Get timestamp
   * @return timestamp
  **/
      @NotNull

    @Valid
    public LocalDateTime getTimestamp() {
    return timestamp;
  }

  public void setTimestamp(LocalDateTime timestamp) {
    this.timestamp = timestamp;
  }

  public PatientIdentificationResponse patient(PatientIdentificationResponsePatient patient) {
    this.patient = patient;
    return this;
  }

  /**
   * Get patient
   * @return patient
  **/
  
    @Valid
    public PatientIdentificationResponsePatient getPatient() {
    return patient;
  }

  public void setPatient(PatientIdentificationResponsePatient patient) {
    this.patient = patient;
  }

  public PatientIdentificationResponse error(Error error) {
    this.error = error;
    return this;
  }

  /**
   * Get error
   * @return error
  **/
  
    @Valid
    public Error getError() {
    return error;
  }

  public void setError(Error error) {
    this.error = error;
  }

  public PatientIdentificationResponse resp(RequestReference resp) {
    this.resp = resp;
    return this;
  }

  /**
   * Get resp
   * @return resp
  **/
      @NotNull

    @Valid
    public RequestReference getResp() {
    return resp;
  }

  public void setResp(RequestReference resp) {
    this.resp = resp;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    PatientIdentificationResponse patientIdentificationResponse = (PatientIdentificationResponse) o;
    return Objects.equals(this.requestId, patientIdentificationResponse.requestId) &&
        Objects.equals(this.timestamp, patientIdentificationResponse.timestamp) &&
        Objects.equals(this.patient, patientIdentificationResponse.patient) &&
        Objects.equals(this.error, patientIdentificationResponse.error) &&
        Objects.equals(this.resp, patientIdentificationResponse.resp);
  }

  @Override
  public int hashCode() {
    return Objects.hash(requestId, timestamp, patient, error, resp);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class PatientIdentificationResponse {\n");
    
    sb.append("    requestId: ").append(toIndentedString(requestId)).append("\n");
    sb.append("    timestamp: ").append(toIndentedString(timestamp)).append("\n");
    sb.append("    patient: ").append(toIndentedString(patient)).append("\n");
    sb.append("    error: ").append(toIndentedString(error)).append("\n");
    sb.append("    resp: ").append(toIndentedString(resp)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
