package org.nha.emr.web.hip.model;

import java.util.Objects;
import java.util.UUID;

import javax.validation.Valid;

import org.springframework.validation.annotation.Validated;

import com.fasterxml.jackson.annotation.JsonProperty;

import io.swagger.annotations.ApiModelProperty;

/**
 * PatientDiscoveryRequest
 */
@Validated

public class PatientDiscoveryRequest   {
  @JsonProperty("requestId")
  private UUID requestId = null;

  @JsonProperty("timestamp")
  private String timestamp = null;

  @JsonProperty("transactionId")
  private UUID transactionId = null;

  @JsonProperty("patient")
  private PatientDiscoveryRequestPatient patient = null;

  public PatientDiscoveryRequest requestId(UUID requestId) {
    this.requestId = requestId;
    return this;
  }

  /**
   * a nonce, unique for each HTTP request.
   * @return requestId
  **/
  @ApiModelProperty(example = "499a5a4a-7dda-4f20-9b67-e24589627061", value = "a nonce, unique for each HTTP request.")
  
    @Valid
    public UUID getRequestId() {
    return requestId;
  }

  public void setRequestId(UUID requestId) {
    this.requestId = requestId;
  }

  public PatientDiscoveryRequest timestamp(String timestamp) {
    this.timestamp = timestamp;
    return this;
  }

  /**
   * Get timestamp
   * @return timestamp
  **/
  @ApiModelProperty(value = "")
  
    @Valid
    public String getTimestamp() {
    return timestamp;
  }

  public void setTimestamp(String timestamp) {
    this.timestamp = timestamp;
  }

  public PatientDiscoveryRequest transactionId(UUID transactionId) {
    this.transactionId = transactionId;
    return this;
  }

  /**
   * correlation-Id for patient discovery and subsequent care context linkage
   * @return transactionId
  **/
  @ApiModelProperty(value = "correlation-Id for patient discovery and subsequent care context linkage")
  
    @Valid
    public UUID getTransactionId() {
    return transactionId;
  }

  public void setTransactionId(UUID transactionId) {
    this.transactionId = transactionId;
  }

  public PatientDiscoveryRequest patient(PatientDiscoveryRequestPatient patient) {
    this.patient = patient;
    return this;
  }

  /**
   * Get patient
   * @return patient
  **/
  @ApiModelProperty(value = "")
  
    @Valid
    public PatientDiscoveryRequestPatient getPatient() {
    return patient;
  }

  public void setPatient(PatientDiscoveryRequestPatient patient) {
    this.patient = patient;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    PatientDiscoveryRequest patientDiscoveryRequest = (PatientDiscoveryRequest) o;
    return Objects.equals(this.requestId, patientDiscoveryRequest.requestId) &&
        Objects.equals(this.timestamp, patientDiscoveryRequest.timestamp) &&
        Objects.equals(this.transactionId, patientDiscoveryRequest.transactionId) &&
        Objects.equals(this.patient, patientDiscoveryRequest.patient);
  }

  @Override
  public int hashCode() {
    return Objects.hash(requestId, timestamp, transactionId, patient);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class PatientDiscoveryRequest {\n");
    
    sb.append("    requestId: ").append(toIndentedString(requestId)).append("\n");
    sb.append("    timestamp: ").append(toIndentedString(timestamp)).append("\n");
    sb.append("    transactionId: ").append(toIndentedString(transactionId)).append("\n");
    sb.append("    patient: ").append(toIndentedString(patient)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
