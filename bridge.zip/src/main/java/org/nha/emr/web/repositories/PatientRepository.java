package org.nha.emr.web.repositories;

import java.util.List;

import org.nha.emr.web.entities.Patient;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;

@Repository
@Component
public interface PatientRepository extends JpaRepository<Patient, Long> {
	
	@Query("select a from Patient a where TO_CHAR(a.lastVisitDt,'dd/MM/yyyy') =:lastVisitDt")
	List<Patient> findAllWithCreationDate(
		      @Param("lastVisitDt") String lastVisitDt);

	@Query("select a from Patient a where a.firstName like ?1 or a.lastName like ?2")
	List<Patient> findAllWithName(
		      String firstName,String lastName);
	
	@Query("select a from Patient a where a.patientId = ?1")
	Patient findBypatientId(Long patientId);

	@Query("select a from Patient a where a.swasthyaId = ?1")
	Patient findBypatientHealthId(String swasthyaId);
	
	
	//select TO_CHAR(MYDATE,'YYYY-MM-DD')from Event e
}
