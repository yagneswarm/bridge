package org.nha.emr.web.hip.model;

import java.util.Objects;
import java.util.UUID;

import javax.validation.Valid;

import org.springframework.validation.annotation.Validated;

import com.fasterxml.jackson.annotation.JsonProperty;

import io.swagger.annotations.ApiModelProperty;

/**
 * HealthInformationNotificationNotification
 */
@Validated



public class HealthInformationNotificationNotification   {
  @JsonProperty("consentId")
  private UUID consentId = null;

  @JsonProperty("transactionId")
  private UUID transactionId = null;

  @JsonProperty("doneAt")
  private String doneAt = null;

  @JsonProperty("notifier")
  private HealthInformationNotificationNotificationNotifier notifier = null;

  @JsonProperty("statusNotification")
  private HealthInformationNotificationNotificationStatusNotification statusNotification = null;

  public HealthInformationNotificationNotification consentId(UUID consentId) {
    this.consentId = consentId;
    return this;
  }

  /**
   * Get consentId
   * @return consentId
  **/
  @ApiModelProperty(value = "")
  
    @Valid
    public UUID getConsentId() {
    return consentId;
  }

  public void setConsentId(UUID consentId) {
    this.consentId = consentId;
  }

  public HealthInformationNotificationNotification transactionId(UUID transactionId) {
    this.transactionId = transactionId;
    return this;
  }

  /**
   * Get transactionId
   * @return transactionId
  **/
  @ApiModelProperty(value = "")
  
    @Valid
    public UUID getTransactionId() {
    return transactionId;
  }

  public void setTransactionId(UUID transactionId) {
    this.transactionId = transactionId;
  }

  public HealthInformationNotificationNotification doneAt(String doneAt) {
    this.doneAt = doneAt;
    return this;
  }

  /**
   * Get doneAt
   * @return doneAt
  **/
  @ApiModelProperty(value = "")
  
    @Valid
    public String getDoneAt() {
    return doneAt;
  }

  public void setDoneAt(String doneAt) {
    this.doneAt = doneAt;
  }

  public HealthInformationNotificationNotification notifier(HealthInformationNotificationNotificationNotifier notifier) {
    this.notifier = notifier;
    return this;
  }

  /**
   * Get notifier
   * @return notifier
  **/
  @ApiModelProperty(value = "")
  
    @Valid
    public HealthInformationNotificationNotificationNotifier getNotifier() {
    return notifier;
  }

  public void setNotifier(HealthInformationNotificationNotificationNotifier notifier) {
    this.notifier = notifier;
  }

  public HealthInformationNotificationNotification statusNotification(HealthInformationNotificationNotificationStatusNotification statusNotification) {
    this.statusNotification = statusNotification;
    return this;
  }

  /**
   * Get statusNotification
   * @return statusNotification
  **/
  @ApiModelProperty(value = "")
  
    @Valid
    public HealthInformationNotificationNotificationStatusNotification getStatusNotification() {
    return statusNotification;
  }

  public void setStatusNotification(HealthInformationNotificationNotificationStatusNotification statusNotification) {
    this.statusNotification = statusNotification;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    HealthInformationNotificationNotification healthInformationNotificationNotification = (HealthInformationNotificationNotification) o;
    return Objects.equals(this.consentId, healthInformationNotificationNotification.consentId) &&
        Objects.equals(this.transactionId, healthInformationNotificationNotification.transactionId) &&
        Objects.equals(this.doneAt, healthInformationNotificationNotification.doneAt) &&
        Objects.equals(this.notifier, healthInformationNotificationNotification.notifier) &&
        Objects.equals(this.statusNotification, healthInformationNotificationNotification.statusNotification);
  }

  @Override
  public int hashCode() {
    return Objects.hash(consentId, transactionId, doneAt, notifier, statusNotification);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class HealthInformationNotificationNotification {\n");
    
    sb.append("    consentId: ").append(toIndentedString(consentId)).append("\n");
    sb.append("    transactionId: ").append(toIndentedString(transactionId)).append("\n");
    sb.append("    doneAt: ").append(toIndentedString(doneAt)).append("\n");
    sb.append("    notifier: ").append(toIndentedString(notifier)).append("\n");
    sb.append("    statusNotification: ").append(toIndentedString(statusNotification)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
