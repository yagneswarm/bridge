package org.nha.emr.web.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "hip_health_info_request")
public class HIPHealthInfoRequest extends AuditModel{

	private static final long serialVersionUID = 1L;
	
	@Id
    private String consentId;
	
	@Column(name = "date_range_from")
	private String dateRangeFrom;
	
	@Column(name = "date_range_to")
	private String dateRangeTo;
	
	@Column(name = "data_push_url")
	private String dataPushUrl;
	
	@Column(name = "crypto_alg")
	private String cryptoAlg;
	
	@Column(name = "curve")
	private String curve;
	
	@Column(name = "public_key_expiry")
	private String publicKeyExpiry;
	
	@Column(name = "public_key_param")
	private String publicKeyParam;
	
	@Column(name = "public_key_value")
	private String publicKeyValue;
	
	@Column(name = "nonce")
	private String nonce;
	
	

	public HIPHealthInfoRequest() {
		// TODO Auto-generated constructor stub
	}

	public String getConsentId() {
		return consentId;
	}

	public void setConsentId(String consentId) {
		this.consentId = consentId;
	}

	public String getDateRangeFrom() {
		return dateRangeFrom;
	}

	public void setDateRangeFrom(String dateRangeFrom) {
		this.dateRangeFrom = dateRangeFrom;
	}

	public String getDateRangeTo() {
		return dateRangeTo;
	}

	public void setDateRangeTo(String dateRangeTo) {
		this.dateRangeTo = dateRangeTo;
	}

	public String getDataPushUrl() {
		return dataPushUrl;
	}

	public void setDataPushUrl(String dataPushUrl) {
		this.dataPushUrl = dataPushUrl;
	}

	public String getCryptoAlg() {
		return cryptoAlg;
	}

	public void setCryptoAlg(String cryptoAlg) {
		this.cryptoAlg = cryptoAlg;
	}

	public String getCurve() {
		return curve;
	}

	public void setCurve(String curve) {
		this.curve = curve;
	}

	public String getPublicKeyExpiry() {
		return publicKeyExpiry;
	}

	public void setPublicKeyExpiry(String publicKeyExpiry) {
		this.publicKeyExpiry = publicKeyExpiry;
	}

	public String getPublicKeyParam() {
		return publicKeyParam;
	}

	public void setPublicKeyParam(String publicKeyParam) {
		this.publicKeyParam = publicKeyParam;
	}

	public String getPublicKeyValue() {
		return publicKeyValue;
	}

	public void setPublicKeyValue(String publicKeyValue) {
		this.publicKeyValue = publicKeyValue;
	}

	public String getNonce() {
		return nonce;
	}

	public void setNonce(String nonce) {
		this.nonce = nonce;
	}

		
	
}
