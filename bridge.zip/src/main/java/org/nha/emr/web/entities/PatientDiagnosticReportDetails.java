package org.nha.emr.web.entities;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;

import org.hibernate.annotations.OnDelete;
import org.hibernate.annotations.OnDeleteAction;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name = "patient_diagnostic_report_dtls")
public class PatientDiagnosticReportDetails extends AuditModel {
    public Long getId() {
		return id;
	}




	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
    @GeneratedValue(generator = "patient_diagnostic_report_generator")
    @SequenceGenerator(
            name = "patient_diagnostic_report_generator",
            sequenceName = "patient_diagnostic_report_sequence",
            initialValue = 1
    )
    private Long id;
   
    @NotBlank
    @Size(min = 3, max = 100)
    @Column(name = "status")
    private String status;
   
    
    @Column(name = "report_category")
    private String reportCategory;
    
    @Column(name = "report_category_value")
    private String reportCategoryValue;
    
    
	@Size(min = 0, max = 100)
    @Column(name = "service_category")
    private String serviceCategory;
    
    @Size(min = 0, max = 100)
    @Column(name = "test_code")
    private String testCode;
    
    @Size(min = 0, max = 100)
    @Column(name = "test_code_value")
    private String testCodeValue;
    
    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "report_dt", nullable = false)
    private Date reportDt;
    
    @Size(min = 0, max = 100)
    @Column(name = "performing_org", nullable = false)
    private String performingOrd;
    
    @Size(min = 0, max = 100)
    @Column(name = "reported_by", nullable = true)
    private String reportedBy;
    
    @Size(min = 0, max = 100000	)
    @Column(name = "report_conclusion", nullable = true)
    private String reportConclusion;
    
    @Size(min = 0, max = 100	)
    @Column(name = "report_file_type", nullable = true)
    private String reportFileType;
    
    @Size(min = 0, max = 1000)
    @Column(name = "report_file_path", nullable = true)
    private String reportFilePath;
    
    
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "visit_id", nullable = false)
    @OnDelete(action = OnDeleteAction.CASCADE)
    @JsonIgnore
    private PatientVisitDetails patientVisitDetails;


    
	public PatientDiagnosticReportDetails() {
		// TODO Auto-generated constructor stub
	}



	
	public String getReportCategoryValue() {
		return reportCategoryValue;
	}




	public void setReportCategoryValue(String reportCategoryValue) {
		this.reportCategoryValue = reportCategoryValue;
	}




	public String getTestCodeValue() {
		return testCodeValue;
	}




	public void setTestCodeValue(String testCodeValue) {
		this.testCodeValue = testCodeValue;
	}




	public void setId(Long id) {
		this.id = id;
	}



	public String getStatus() {
		return status;
	}



	public void setStatus(String status) {
		this.status = status;
	}



	public String getServiceCategory() {
		return serviceCategory;
	}



	public void setServiceCategory(String serviceCategory) {
		this.serviceCategory = serviceCategory;
	}



	public String getTestCode() {
		return testCode;
	}



	public void setTestCode(String testCode) {
		this.testCode = testCode;
	}



	public Date getReportDt() {
		return reportDt;
	}



	public void setReportDt(Date reportDt) {
		this.reportDt = reportDt;
	}



	public String getPerformingOrd() {
		return performingOrd;
	}



	public void setPerformingOrd(String performingOrd) {
		this.performingOrd = performingOrd;
	}



	public String getReportedBy() {
		return reportedBy;
	}



	public void setReportedBy(String reportedBy) {
		this.reportedBy = reportedBy;
	}



	public String getReportConclusion() {
		return reportConclusion;
	}



	public void setReportConclusion(String reportConclusion) {
		this.reportConclusion = reportConclusion;
	}



	public String getReportFileType() {
		return reportFileType;
	}



	public void setReportFileType(String reportFileType) {
		this.reportFileType = reportFileType;
	}



	public String getReportFilePath() {
		return reportFilePath;
	}



	public void setReportFilePath(String reportFilePath) {
		this.reportFilePath = reportFilePath;
	}



	public PatientVisitDetails getPatientVisitDetails() {
		return patientVisitDetails;
	}



	public void setPatientVisitDetails(PatientVisitDetails patientVisitDetails) {
		this.patientVisitDetails = patientVisitDetails;
	}
	
	 public String getReportCategory() {
			return reportCategory;
		}




		public void setReportCategory(String reportCategory) {
			this.reportCategory = reportCategory;
		}

	        
    }
