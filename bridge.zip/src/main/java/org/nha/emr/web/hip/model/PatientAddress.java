package org.nha.emr.web.hip.model;

import java.util.Objects;

import org.springframework.validation.annotation.Validated;

import com.fasterxml.jackson.annotation.JsonProperty;

import io.swagger.annotations.ApiModelProperty;

/**
 * PatientAddress
 */
@Validated

public class PatientAddress   {
  @JsonProperty("line")
  private String line = null;

  @JsonProperty("district")
  private String district = null;

  @JsonProperty("state")
  private String state = null;

  @JsonProperty("pincode")
  private String pincode = null;

  public PatientAddress line(String line) {
    this.line = line;
    return this;
  }

  /**
   * Get line
   * @return line
  **/
  @ApiModelProperty(value = "")
  
    public String getLine() {
    return line;
  }

  public void setLine(String line) {
    this.line = line;
  }

  public PatientAddress district(String district) {
    this.district = district;
    return this;
  }

  /**
   * Get district
   * @return district
  **/
  @ApiModelProperty(value = "")
  
    public String getDistrict() {
    return district;
  }

  public void setDistrict(String district) {
    this.district = district;
  }

  public PatientAddress state(String state) {
    this.state = state;
    return this;
  }

  /**
   * Get state
   * @return state
  **/
  @ApiModelProperty(value = "")
  
    public String getState() {
    return state;
  }

  public void setState(String state) {
    this.state = state;
  }

  public PatientAddress pincode(String pincode) {
    this.pincode = pincode;
    return this;
  }

  /**
   * Get pincode
   * @return pincode
  **/
  @ApiModelProperty(value = "")
  
    public String getPincode() {
    return pincode;
  }

  public void setPincode(String pincode) {
    this.pincode = pincode;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    PatientAddress patientAddress = (PatientAddress) o;
    return Objects.equals(this.line, patientAddress.line) &&
        Objects.equals(this.district, patientAddress.district) &&
        Objects.equals(this.state, patientAddress.state) &&
        Objects.equals(this.pincode, patientAddress.pincode);
  }

  @Override
  public int hashCode() {
    return Objects.hash(line, district, state, pincode);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class PatientAddress {\n");
    
    sb.append("    line: ").append(toIndentedString(line)).append("\n");
    sb.append("    district: ").append(toIndentedString(district)).append("\n");
    sb.append("    state: ").append(toIndentedString(state)).append("\n");
    sb.append("    pincode: ").append(toIndentedString(pincode)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
