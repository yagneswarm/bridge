package org.nha.emr.web.vo;

public class DrugVO {
	
	private String drugName;
	private String drugInstructions;
	private String quantity;
	private String duration;
	private String durationUnit;
	private String drugId;
	private String drugInstructionsId;
	
	public String getDrugId() {
		return drugId;
	}
	public void setDrugId(String drugId) {
		this.drugId = drugId;
	}
	public String getDrugInstructionsId() {
		return drugInstructionsId;
	}
	public void setDrugInstructionsId(String drugInstructionsId) {
		this.drugInstructionsId = drugInstructionsId;
	}
	public String getDrugName() {
		return drugName;
	}
	public void setDrugName(String drugName) {
		this.drugName = drugName;
	}
	public String getDrugInstructions() {
		return drugInstructions;
	}
	public void setDrugInstructions(String drugInstructions) {
		this.drugInstructions = drugInstructions;
	}
	public String getQuantity() {
		return quantity;
	}
	public void setQuantity(String quantity) {
		this.quantity = quantity;
	}
	public String getDuration() {
		return duration;
	}
	public void setDuration(String duration) {
		this.duration = duration;
	}
	public String getDurationUnit() {
		return durationUnit;
	}
	public void setDurationUnit(String durationUnit) {
		this.durationUnit = durationUnit;
	}
	
	

}
