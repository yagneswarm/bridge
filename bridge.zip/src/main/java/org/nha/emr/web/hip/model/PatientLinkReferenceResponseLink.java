package org.nha.emr.web.hip.model;

import java.util.Objects;

import javax.validation.Valid;

import org.springframework.validation.annotation.Validated;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonValue;

import io.swagger.annotations.ApiModelProperty;

/**
 * PatientLinkReferenceResponseLink
 */
@Validated

public class PatientLinkReferenceResponseLink   {
  @JsonProperty("referenceNumber")
  private String referenceNumber = null;

  /**
   * Gets or Sets authenticationType
   */
  public enum AuthenticationTypeEnum {
    DIRECT("DIRECT"),
    
    MEDIATED("MEDIATED");

    private String value;

    AuthenticationTypeEnum(String value) {
      this.value = value;
    }

    @Override
    @JsonValue
    public String toString() {
      return String.valueOf(value);
    }

    @JsonCreator
    public static AuthenticationTypeEnum fromValue(String text) {
      for (AuthenticationTypeEnum b : AuthenticationTypeEnum.values()) {
        if (String.valueOf(b.value).equals(text)) {
          return b;
        }
      }
      return null;
    }
  }
  @JsonProperty("authenticationType")
  private AuthenticationTypeEnum authenticationType = null;

  @JsonProperty("meta")
  private Meta meta = null;

  public PatientLinkReferenceResponseLink referenceNumber(String referenceNumber) {
    this.referenceNumber = referenceNumber;
    return this;
  }

  /**
   * Get referenceNumber
   * @return referenceNumber
  **/
  @ApiModelProperty(value = "")
  
    public String getReferenceNumber() {
    return referenceNumber;
  }

  public void setReferenceNumber(String referenceNumber) {
    this.referenceNumber = referenceNumber;
  }

  public PatientLinkReferenceResponseLink authenticationType(AuthenticationTypeEnum authenticationType) {
    this.authenticationType = authenticationType;
    return this;
  }

  /**
   * Get authenticationType
   * @return authenticationType
  **/
  @ApiModelProperty(value = "")
  
    public AuthenticationTypeEnum getAuthenticationType() {
    return authenticationType;
  }

  public void setAuthenticationType(AuthenticationTypeEnum authenticationType) {
    this.authenticationType = authenticationType;
  }

  public PatientLinkReferenceResponseLink meta(Meta meta) {
    this.meta = meta;
    return this;
  }

  /**
   * Get meta
   * @return meta
  **/
  @ApiModelProperty(value = "")
  
    @Valid
    public Meta getMeta() {
    return meta;
  }

  public void setMeta(Meta meta) {
    this.meta = meta;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    PatientLinkReferenceResponseLink patientLinkReferenceResponseLink = (PatientLinkReferenceResponseLink) o;
    return Objects.equals(this.referenceNumber, patientLinkReferenceResponseLink.referenceNumber) &&
        Objects.equals(this.authenticationType, patientLinkReferenceResponseLink.authenticationType) &&
        Objects.equals(this.meta, patientLinkReferenceResponseLink.meta);
  }

  @Override
  public int hashCode() {
    return Objects.hash(referenceNumber, authenticationType, meta);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class PatientLinkReferenceResponseLink {\n");
    
    sb.append("    referenceNumber: ").append(toIndentedString(referenceNumber)).append("\n");
    sb.append("    authenticationType: ").append(toIndentedString(authenticationType)).append("\n");
    sb.append("    meta: ").append(toIndentedString(meta)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
