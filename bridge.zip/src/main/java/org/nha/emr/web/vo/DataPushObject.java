package org.nha.emr.web.vo;

import java.util.List;

import org.nha.emr.web.hip.model.AnyOfDataNotificationEntriesItems;
import org.nha.emr.web.hip.model.EntryContent;
import org.nha.emr.web.hip.model.KeyMaterial;

public class DataPushObject {
	EntryContent entryContent;
	KeyMaterial keyMaterial;
	List<AnyOfDataNotificationEntriesItems> entries;
	
	public List<AnyOfDataNotificationEntriesItems> getEntries() {
		return entries;
	}
	public void setEntries(List<AnyOfDataNotificationEntriesItems> entries) {
		this.entries = entries;
	}
	public DataPushObject() {
		// TODO Auto-generated constructor stub
	}
	public EntryContent getEntryContent() {
		return entryContent;
	}
	public void setEntryContent(EntryContent entryContent) {
		this.entryContent = entryContent;
	}
	public KeyMaterial getKeyMaterial() {
		return keyMaterial;
	}
	public void setKeyMaterial(KeyMaterial keyMaterial) {
		this.keyMaterial = keyMaterial;
	}
	
}
