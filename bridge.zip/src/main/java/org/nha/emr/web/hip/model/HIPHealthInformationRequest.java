package org.nha.emr.web.hip.model;

import java.util.Objects;
import java.util.UUID;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;

import org.springframework.validation.annotation.Validated;

import com.fasterxml.jackson.annotation.JsonProperty;

import io.swagger.annotations.ApiModelProperty;

/**
 * HIPHealthInformationRequest
 */
@Validated



public class HIPHealthInformationRequest   {
  @JsonProperty("requestId")
  private UUID requestId = null;

  @JsonProperty("timestamp")
  private String timestamp = null;

  @JsonProperty("transactionId")
  private UUID transactionId = null;

  @JsonProperty("hiRequest")
  private HIPHealthInformationRequestHiRequest hiRequest = null;

  public HIPHealthInformationRequest requestId(UUID requestId) {
    this.requestId = requestId;
    return this;
  }

  /**
   * Get requestId
   * @return requestId
  **/
  @ApiModelProperty(required = true, value = "")
      @NotNull

    @Valid
    public UUID getRequestId() {
    return requestId;
  }

  public void setRequestId(UUID requestId) {
    this.requestId = requestId;
  }

  public HIPHealthInformationRequest timestamp(String timestamp) {
    this.timestamp = timestamp;
    return this;
  }

  /**
   * Get timestamp
   * @return timestamp
  **/
  @ApiModelProperty(required = true, value = "")
      @NotNull

    @Valid
    public String getTimestamp() {
    return timestamp;
  }

  public void setTimestamp(String timestamp) {
    this.timestamp = timestamp;
  }

  public HIPHealthInformationRequest transactionId(UUID transactionId) {
    this.transactionId = transactionId;
    return this;
  }

  /**
   * Get transactionId
   * @return transactionId
  **/
  @ApiModelProperty(required = true, value = "")
      @NotNull

    @Valid
    public UUID getTransactionId() {
    return transactionId;
  }

  public void setTransactionId(UUID transactionId) {
    this.transactionId = transactionId;
  }

  public HIPHealthInformationRequest hiRequest(HIPHealthInformationRequestHiRequest hiRequest) {
    this.hiRequest = hiRequest;
    return this;
  }

  /**
   * Get hiRequest
   * @return hiRequest
  **/
  @ApiModelProperty(required = true, value = "")
      @NotNull

    @Valid
    public HIPHealthInformationRequestHiRequest getHiRequest() {
    return hiRequest;
  }

  public void setHiRequest(HIPHealthInformationRequestHiRequest hiRequest) {
    this.hiRequest = hiRequest;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    HIPHealthInformationRequest hiPHealthInformationRequest = (HIPHealthInformationRequest) o;
    return Objects.equals(this.requestId, hiPHealthInformationRequest.requestId) &&
        Objects.equals(this.timestamp, hiPHealthInformationRequest.timestamp) &&
        Objects.equals(this.transactionId, hiPHealthInformationRequest.transactionId) &&
        Objects.equals(this.hiRequest, hiPHealthInformationRequest.hiRequest);
  }

  @Override
  public int hashCode() {
    return Objects.hash(requestId, timestamp, transactionId, hiRequest);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class HIPHealthInformationRequest {\n");
    
    sb.append("    requestId: ").append(toIndentedString(requestId)).append("\n");
    sb.append("    timestamp: ").append(toIndentedString(timestamp)).append("\n");
    sb.append("    transactionId: ").append(toIndentedString(transactionId)).append("\n");
    sb.append("    hiRequest: ").append(toIndentedString(hiRequest)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
