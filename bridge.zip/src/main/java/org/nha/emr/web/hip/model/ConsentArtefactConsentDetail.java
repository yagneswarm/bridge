package org.nha.emr.web.hip.model;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.UUID;

import javax.validation.Valid;

import org.springframework.validation.annotation.Validated;

import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * ConsentArtefactConsentDetail
 */
@Validated

public class ConsentArtefactConsentDetail   {
  @JsonProperty("schemaVersion")
  private String schemaVersion = null;

  @JsonProperty("consentId")
  private UUID consentId = null;

  @JsonProperty("createdAt")
  private String createdAt = null;

  @JsonProperty("patient")
  private ConsentManagerPatientID patient = null;

  @JsonProperty("careContexts")
  @Valid
  private List<HIPConsentNotificationNotificationConsentDetailCareContexts> careContexts = null;

  @JsonProperty("purpose")
  private UsePurpose purpose = null;

  @JsonProperty("hip")
  private AllOfConsentArtefactConsentDetailHip hip = null;

  @JsonProperty("consentManager")
  private AllOfConsentArtefactConsentDetailConsentManager consentManager = null;

  @JsonProperty("hiTypes")
  @Valid
  private List<HITypeEnum> hiTypes = null;

  @JsonProperty("permission")
  private Permission permission = null;

  @JsonProperty("signature")
  private String signature = null;

  public ConsentArtefactConsentDetail schemaVersion(String schemaVersion) {
    this.schemaVersion = schemaVersion;
    return this;
  }

  /**
   * Get schemaVersion
   * @return schemaVersion
  **/
  
    public String getSchemaVersion() {
    return schemaVersion;
  }

  public void setSchemaVersion(String schemaVersion) {
    this.schemaVersion = schemaVersion;
  }

  public ConsentArtefactConsentDetail consentId(UUID consentId) {
    this.consentId = consentId;
    return this;
  }

  /**
   * Get consentId
   * @return consentId
  **/
  
    @Valid
    public UUID getConsentId() {
    return consentId;
  }

  public void setConsentId(UUID consentId) {
    this.consentId = consentId;
  }

  public ConsentArtefactConsentDetail createdAt(String createdAt) {
    this.createdAt = createdAt;
    return this;
  }

  /**
   * Get createdAt
   * @return createdAt
  **/
  
    @Valid
    public String getCreatedAt() {
    return createdAt;
  }

  public void setCreatedAt(String createdAt) {
    this.createdAt = createdAt;
  }

  public ConsentArtefactConsentDetail patient(ConsentManagerPatientID patient) {
    this.patient = patient;
    return this;
  }

  /**
   * Get patient
   * @return patient
  **/
  
    @Valid
    public ConsentManagerPatientID getPatient() {
    return patient;
  }

  public void setPatient(ConsentManagerPatientID patient) {
    this.patient = patient;
  }

  public ConsentArtefactConsentDetail careContexts(List<HIPConsentNotificationNotificationConsentDetailCareContexts> careContexts) {
    this.careContexts = careContexts;
    return this;
  }

  public ConsentArtefactConsentDetail addCareContextsItem(HIPConsentNotificationNotificationConsentDetailCareContexts careContextsItem) {
    if (this.careContexts == null) {
      this.careContexts = new ArrayList<HIPConsentNotificationNotificationConsentDetailCareContexts>();
    }
    this.careContexts.add(careContextsItem);
    return this;
  }

  /**
   * Get careContexts
   * @return careContexts
  **/
      @Valid
    public List<HIPConsentNotificationNotificationConsentDetailCareContexts> getCareContexts() {
    return careContexts;
  }

  public void setCareContexts(List<HIPConsentNotificationNotificationConsentDetailCareContexts> careContexts) {
    this.careContexts = careContexts;
  }

  public ConsentArtefactConsentDetail purpose(UsePurpose purpose) {
    this.purpose = purpose;
    return this;
  }

  /**
   * Get purpose
   * @return purpose
  **/
  
    @Valid
    public UsePurpose getPurpose() {
    return purpose;
  }

  public void setPurpose(UsePurpose purpose) {
    this.purpose = purpose;
  }

  public ConsentArtefactConsentDetail hip(AllOfConsentArtefactConsentDetailHip hip) {
    this.hip = hip;
    return this;
  }

  /**
   * Get hip
   * @return hip
  **/
  
    public AllOfConsentArtefactConsentDetailHip getHip() {
    return hip;
  }

  public void setHip(AllOfConsentArtefactConsentDetailHip hip) {
    this.hip = hip;
  }

  public ConsentArtefactConsentDetail consentManager(AllOfConsentArtefactConsentDetailConsentManager consentManager) {
    this.consentManager = consentManager;
    return this;
  }

  /**
   * Get consentManager
   * @return consentManager
  **/
  
    public AllOfConsentArtefactConsentDetailConsentManager getConsentManager() {
    return consentManager;
  }

  public void setConsentManager(AllOfConsentArtefactConsentDetailConsentManager consentManager) {
    this.consentManager = consentManager;
  }

  public ConsentArtefactConsentDetail hiTypes(List<HITypeEnum> hiTypes) {
    this.hiTypes = hiTypes;
    return this;
  }

  public ConsentArtefactConsentDetail addHiTypesItem(HITypeEnum hiTypesItem) {
    if (this.hiTypes == null) {
      this.hiTypes = new ArrayList<HITypeEnum>();
    }
    this.hiTypes.add(hiTypesItem);
    return this;
  }

  /**
   * Get hiTypes
   * @return hiTypes
  **/
      @Valid
    public List<HITypeEnum> getHiTypes() {
    return hiTypes;
  }

  public void setHiTypes(List<HITypeEnum> hiTypes) {
    this.hiTypes = hiTypes;
  }

  public ConsentArtefactConsentDetail permission(Permission permission) {
    this.permission = permission;
    return this;
  }

  /**
   * Get permission
   * @return permission
  **/
  
    @Valid
    public Permission getPermission() {
    return permission;
  }

  public void setPermission(Permission permission) {
    this.permission = permission;
  }

  public ConsentArtefactConsentDetail signature(String signature) {
    this.signature = signature;
    return this;
  }

  /**
   * Get signature
   * @return signature
  **/
  
    public String getSignature() {
    return signature;
  }

  public void setSignature(String signature) {
    this.signature = signature;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    ConsentArtefactConsentDetail consentArtefactConsentDetail = (ConsentArtefactConsentDetail) o;
    return Objects.equals(this.schemaVersion, consentArtefactConsentDetail.schemaVersion) &&
        Objects.equals(this.consentId, consentArtefactConsentDetail.consentId) &&
        Objects.equals(this.createdAt, consentArtefactConsentDetail.createdAt) &&
        Objects.equals(this.patient, consentArtefactConsentDetail.patient) &&
        Objects.equals(this.careContexts, consentArtefactConsentDetail.careContexts) &&
        Objects.equals(this.purpose, consentArtefactConsentDetail.purpose) &&
        Objects.equals(this.hip, consentArtefactConsentDetail.hip) &&
        Objects.equals(this.consentManager, consentArtefactConsentDetail.consentManager) &&
        Objects.equals(this.hiTypes, consentArtefactConsentDetail.hiTypes) &&
        Objects.equals(this.permission, consentArtefactConsentDetail.permission) &&
        Objects.equals(this.signature, consentArtefactConsentDetail.signature);
  }

  @Override
  public int hashCode() {
    return Objects.hash(schemaVersion, consentId, createdAt, patient, careContexts, purpose, hip, consentManager, hiTypes, permission, signature);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ConsentArtefactConsentDetail {\n");
    
    sb.append("    schemaVersion: ").append(toIndentedString(schemaVersion)).append("\n");
    sb.append("    consentId: ").append(toIndentedString(consentId)).append("\n");
    sb.append("    createdAt: ").append(toIndentedString(createdAt)).append("\n");
    sb.append("    patient: ").append(toIndentedString(patient)).append("\n");
    sb.append("    careContexts: ").append(toIndentedString(careContexts)).append("\n");
    sb.append("    purpose: ").append(toIndentedString(purpose)).append("\n");
    sb.append("    hip: ").append(toIndentedString(hip)).append("\n");
    sb.append("    consentManager: ").append(toIndentedString(consentManager)).append("\n");
    sb.append("    hiTypes: ").append(toIndentedString(hiTypes)).append("\n");
    sb.append("    permission: ").append(toIndentedString(permission)).append("\n");
    sb.append("    signature: ").append(toIndentedString(signature)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
