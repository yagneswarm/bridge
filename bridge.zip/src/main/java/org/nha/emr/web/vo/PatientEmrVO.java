package org.nha.emr.web.vo;

import org.nha.emr.web.entities.Patient;

public class PatientEmrVO {

	public Patient patient;

	public Patient getPatient() {
		return patient;
	}

	public void setPatient(Patient patient) {
		this.patient = patient;
	}
	
	
}
