package org.nha.emr.web.hip.model;

import java.util.Objects;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;

import org.springframework.validation.annotation.Validated;

import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * ConsentArtefactResponseConsent
 */
@Validated


public class ConsentArtefactResponseConsent   {
  @JsonProperty("status")
  private ConsentStatus status = null;

  @JsonProperty("consentDetail")
  private ConsentArtefactResponseConsentConsentDetail consentDetail = null;

  @JsonProperty("signature")
  private String signature = null;

  public ConsentArtefactResponseConsent status(ConsentStatus status) {
    this.status = status;
    return this;
  }

  /**
   * Get status
   * @return status
  **/
      @NotNull

    @Valid
    public ConsentStatus getStatus() {
    return status;
  }

  public void setStatus(ConsentStatus status) {
    this.status = status;
  }

  public ConsentArtefactResponseConsent consentDetail(ConsentArtefactResponseConsentConsentDetail consentDetail) {
    this.consentDetail = consentDetail;
    return this;
  }

  /**
   * Get consentDetail
   * @return consentDetail
  **/
      @NotNull

    @Valid
    public ConsentArtefactResponseConsentConsentDetail getConsentDetail() {
    return consentDetail;
  }

  public void setConsentDetail(ConsentArtefactResponseConsentConsentDetail consentDetail) {
    this.consentDetail = consentDetail;
  }

  public ConsentArtefactResponseConsent signature(String signature) {
    this.signature = signature;
    return this;
  }

  /**
   * Get signature
   * @return signature
  **/
      @NotNull

    public String getSignature() {
    return signature;
  }

  public void setSignature(String signature) {
    this.signature = signature;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    ConsentArtefactResponseConsent consentArtefactResponseConsent = (ConsentArtefactResponseConsent) o;
    return Objects.equals(this.status, consentArtefactResponseConsent.status) &&
        Objects.equals(this.consentDetail, consentArtefactResponseConsent.consentDetail) &&
        Objects.equals(this.signature, consentArtefactResponseConsent.signature);
  }

  @Override
  public int hashCode() {
    return Objects.hash(status, consentDetail, signature);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ConsentArtefactResponseConsent {\n");
    
    sb.append("    status: ").append(toIndentedString(status)).append("\n");
    sb.append("    consentDetail: ").append(toIndentedString(consentDetail)).append("\n");
    sb.append("    signature: ").append(toIndentedString(signature)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
