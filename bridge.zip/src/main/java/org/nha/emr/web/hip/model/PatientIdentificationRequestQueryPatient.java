package org.nha.emr.web.hip.model;

import java.util.Objects;

import org.springframework.validation.annotation.Validated;

import com.fasterxml.jackson.annotation.JsonProperty;


/**
 * PatientIdentificationRequestQueryPatient
 */
@Validated

public class PatientIdentificationRequestQueryPatient   {
  @JsonProperty("id")
  private String id = null;

  public PatientIdentificationRequestQueryPatient id(String id) {
    this.id = id;
    return this;
  }

  /**
   * Get id
   * @return id
  **/
  
    public String getId() {
    return id;
  }

  public void setId(String id) {
    this.id = id;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    PatientIdentificationRequestQueryPatient patientIdentificationRequestQueryPatient = (PatientIdentificationRequestQueryPatient) o;
    return Objects.equals(this.id, patientIdentificationRequestQueryPatient.id);
  }

  @Override
  public int hashCode() {
    return Objects.hash(id);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class PatientIdentificationRequestQueryPatient {\n");
    
    sb.append("    id: ").append(toIndentedString(id)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
