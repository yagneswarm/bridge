package org.nha.emr.web.hip.model;

import java.util.Objects;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;

import org.springframework.validation.annotation.Validated;

import com.fasterxml.jackson.annotation.JsonProperty;

import io.swagger.annotations.ApiModelProperty;

/**
 * PatientAuthModeQueryRequestQuery
 */
@Validated

public class PatientAuthModeQueryRequestQuery   {
  @JsonProperty("id")
  private String id = null;

  @JsonProperty("purpose")
  private PatientAuthPurpose purpose = null;

  @JsonProperty("requester")
  private PatientAuthModeQueryRequestQueryRequester requester = null;

  public PatientAuthModeQueryRequestQuery id(String id) {
    this.id = id;
    return this;
  }

  /**
   * Get id
   * @return id
  **/
  @ApiModelProperty(example = "hinapatel79@ndhm", required = true, value = "")
      @NotNull

    public String getId() {
    return id;
  }

  public void setId(String id) {
    this.id = id;
  }

  public PatientAuthModeQueryRequestQuery purpose(PatientAuthPurpose purpose) {
    this.purpose = purpose;
    return this;
  }

  /**
   * Get purpose
   * @return purpose
  **/
  @ApiModelProperty(required = true, value = "")
      @NotNull

    @Valid
    public PatientAuthPurpose getPurpose() {
    return purpose;
  }

  public void setPurpose(PatientAuthPurpose purpose) {
    this.purpose = purpose;
  }

  public PatientAuthModeQueryRequestQuery requester(PatientAuthModeQueryRequestQueryRequester requester) {
    this.requester = requester;
    return this;
  }

  /**
   * Get requester
   * @return requester
  **/
  @ApiModelProperty(required = true, value = "")
      @NotNull

    @Valid
    public PatientAuthModeQueryRequestQueryRequester getRequester() {
    return requester;
  }

  public void setRequester(PatientAuthModeQueryRequestQueryRequester requester) {
    this.requester = requester;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    PatientAuthModeQueryRequestQuery patientAuthModeQueryRequestQuery = (PatientAuthModeQueryRequestQuery) o;
    return Objects.equals(this.id, patientAuthModeQueryRequestQuery.id) &&
        Objects.equals(this.purpose, patientAuthModeQueryRequestQuery.purpose) &&
        Objects.equals(this.requester, patientAuthModeQueryRequestQuery.requester);
  }

  @Override
  public int hashCode() {
    return Objects.hash(id, purpose, requester);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class PatientAuthModeQueryRequestQuery {\n");
    
    sb.append("    id: ").append(toIndentedString(id)).append("\n");
    sb.append("    purpose: ").append(toIndentedString(purpose)).append("\n");
    sb.append("    requester: ").append(toIndentedString(requester)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
