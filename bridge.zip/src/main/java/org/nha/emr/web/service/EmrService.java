package org.nha.emr.web.service;

import java.util.List;

import org.nha.emr.web.vo.PatientSearchVO;
import org.nha.emr.web.vo.PatientVO;
import org.springframework.stereotype.Component;

@Component
public interface EmrService {

	public List<PatientVO> getPatientList(PatientSearchVO patientSearchVO);
	public List<PatientVO> getPatientListById(PatientSearchVO patientSearchVO);
	public PatientVO getPatientDetailsById(PatientSearchVO patientSearchVO);
	
}
