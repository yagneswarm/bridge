package org.nha.emr.web.hip.model;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import javax.validation.Valid;

import org.springframework.validation.annotation.Validated;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonValue;

import io.swagger.annotations.ApiModelProperty;

/**
 * PatientDiscoveryRequestPatient
 */
@Validated



public class PatientDiscoveryRequestPatient   {
  @JsonProperty("id")
  private String id = null;

  @JsonProperty("verifiedIdentifiers")
  @Valid
  private List<Identifier> verifiedIdentifiers = null;

  @JsonProperty("unverifiedIdentifiers")
  @Valid
  private List<Identifier> unverifiedIdentifiers = null;

  @JsonProperty("name")
  private String name = null;

  /**
   * Gets or Sets gender
   */
  public enum GenderEnum {
    M("M"),
    
    F("F"),
    
    O("O");

    private String value;

    GenderEnum(String value) {
      this.value = value;
    }

    @Override
    @JsonValue
    public String toString() {
      return String.valueOf(value);
    }

    @JsonCreator
    public static GenderEnum fromValue(String text) {
      for (GenderEnum b : GenderEnum.values()) {
        if (String.valueOf(b.value).equals(text)) {
          return b;
        }
      }
      return null;
    }
  }
  @JsonProperty("gender")
  private GenderEnum gender = null;

  @JsonProperty("yearOfBirth")
  private Integer yearOfBirth = null;

  public PatientDiscoveryRequestPatient id(String id) {
    this.id = id;
    return this;
  }

  /**
   * Identifier of patient at consent manager
   * @return id
  **/
  @ApiModelProperty(example = "<patient-id>@<consent-manager-id>", value = "Identifier of patient at consent manager")
  
    public String getId() {
    return id;
  }

  public void setId(String id) {
    this.id = id;
  }

  public PatientDiscoveryRequestPatient verifiedIdentifiers(List<Identifier> verifiedIdentifiers) {
    this.verifiedIdentifiers = verifiedIdentifiers;
    return this;
  }

  public PatientDiscoveryRequestPatient addVerifiedIdentifiersItem(Identifier verifiedIdentifiersItem) {
    if (this.verifiedIdentifiers == null) {
      this.verifiedIdentifiers = new ArrayList<Identifier>();
    }
    this.verifiedIdentifiers.add(verifiedIdentifiersItem);
    return this;
  }

  /**
   * Get verifiedIdentifiers
   * @return verifiedIdentifiers
  **/
  @ApiModelProperty(value = "")
      @Valid
    public List<Identifier> getVerifiedIdentifiers() {
    return verifiedIdentifiers;
  }

  public void setVerifiedIdentifiers(List<Identifier> verifiedIdentifiers) {
    this.verifiedIdentifiers = verifiedIdentifiers;
  }

  public PatientDiscoveryRequestPatient unverifiedIdentifiers(List<Identifier> unverifiedIdentifiers) {
    this.unverifiedIdentifiers = unverifiedIdentifiers;
    return this;
  }

  public PatientDiscoveryRequestPatient addUnverifiedIdentifiersItem(Identifier unverifiedIdentifiersItem) {
    if (this.unverifiedIdentifiers == null) {
      this.unverifiedIdentifiers = new ArrayList<Identifier>();
    }
    this.unverifiedIdentifiers.add(unverifiedIdentifiersItem);
    return this;
  }

  /**
   * Get unverifiedIdentifiers
   * @return unverifiedIdentifiers
  **/
  @ApiModelProperty(value = "")
      @Valid
    public List<Identifier> getUnverifiedIdentifiers() {
    return unverifiedIdentifiers;
  }

  public void setUnverifiedIdentifiers(List<Identifier> unverifiedIdentifiers) {
    this.unverifiedIdentifiers = unverifiedIdentifiers;
  }

  public PatientDiscoveryRequestPatient name(String name) {
    this.name = name;
    return this;
  }

  /**
   * Get name
   * @return name
  **/
  @ApiModelProperty(example = "chandler bing", value = "")
  
    public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }

  public PatientDiscoveryRequestPatient gender(GenderEnum gender) {
    this.gender = gender;
    return this;
  }

  /**
   * Get gender
   * @return gender
  **/
  @ApiModelProperty(value = "")
  
    public GenderEnum getGender() {
    return gender;
  }

  public void setGender(GenderEnum gender) {
    this.gender = gender;
  }

  public PatientDiscoveryRequestPatient yearOfBirth(Integer yearOfBirth) {
    this.yearOfBirth = yearOfBirth;
    return this;
  }

  /**
   * Get yearOfBirth
   * @return yearOfBirth
  **/
  @ApiModelProperty(example = "2000", value = "")
  
    public Integer getYearOfBirth() {
    return yearOfBirth;
  }

  public void setYearOfBirth(Integer yearOfBirth) {
    this.yearOfBirth = yearOfBirth;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    PatientDiscoveryRequestPatient patientDiscoveryRequestPatient = (PatientDiscoveryRequestPatient) o;
    return Objects.equals(this.id, patientDiscoveryRequestPatient.id) &&
        Objects.equals(this.verifiedIdentifiers, patientDiscoveryRequestPatient.verifiedIdentifiers) &&
        Objects.equals(this.unverifiedIdentifiers, patientDiscoveryRequestPatient.unverifiedIdentifiers) &&
        Objects.equals(this.name, patientDiscoveryRequestPatient.name) &&
        Objects.equals(this.gender, patientDiscoveryRequestPatient.gender) &&
        Objects.equals(this.yearOfBirth, patientDiscoveryRequestPatient.yearOfBirth);
  }

  @Override
  public int hashCode() {
    return Objects.hash(id, verifiedIdentifiers, unverifiedIdentifiers, name, gender, yearOfBirth);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class PatientDiscoveryRequestPatient {\n");
    
    sb.append("    id: ").append(toIndentedString(id)).append("\n");
    sb.append("    verifiedIdentifiers: ").append(toIndentedString(verifiedIdentifiers)).append("\n");
    sb.append("    unverifiedIdentifiers: ").append(toIndentedString(unverifiedIdentifiers)).append("\n");
    sb.append("    name: ").append(toIndentedString(name)).append("\n");
    sb.append("    gender: ").append(toIndentedString(gender)).append("\n");
    sb.append("    yearOfBirth: ").append(toIndentedString(yearOfBirth)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
